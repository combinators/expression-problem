package trivially;

public interface NegEquals extends ExpEquals, NegAstreeIdz {

    ExpEquals getInner();

    default Boolean equals(ExpEquals that) {
        return this.astree().same(that.astree());
    }
}
