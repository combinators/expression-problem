package algebra.oo;

public class Add extends Exp {

    public Add(Exp left, Exp right) {
        this.left = left;
        this.right = right;
    }

    private Exp left;

    private Exp right;

    public algebra.CombinedExpAlg.Combined convert(algebra.CombinedExpAlg algebra) {
        return algebra.add(left.convert(algebra), right.convert(algebra));
    }
}
