package trivially;

public interface Exp {

    public tree.Tree astree();
}
