package visitor;

public class FindPower extends FindSqrt implements VisitorPower<Integer> {

    public FindPower(Double target) {
        super(target);
        this.target = target;
    }

    Double target;

    public Integer visit(Power e) {
        return e.getLeft().accept(makeFind(target)) + e.getRight().accept(makeFind(target));
    }

    FindPower makeFind(Double target) {
        return new FindPower(target);
    }
}
