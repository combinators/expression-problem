package algebra;

public class AstreeDivdMultNegExpAlg implements DivdMultNegExpAlg<Astree> {

    public Astree neg(final Astree inner) {
        return () -> {
            return new tree.Node(java.util.Arrays.asList(inner.astree()), new IdzPowerExpAlg().neg(null).idz());
        };
    }

    public Astree mult(final Astree left, final Astree right) {
        return () -> {
            return new tree.Node(java.util.Arrays.asList(left.astree(), right.astree()), new IdzPowerExpAlg().mult(null, null).idz());
        };
    }

    public Astree divd(final Astree left, final Astree right) {
        return () -> {
            return new tree.Node(java.util.Arrays.asList(left.astree(), right.astree()), new IdzPowerExpAlg().divd(null, null).idz());
        };
    }

    public Astree sub(final Astree left, final Astree right) {
        return () -> {
            return new tree.Node(java.util.Arrays.asList(left.astree(), right.astree()), new IdzPowerExpAlg().sub(null, null).idz());
        };
    }

    public Astree lit(final Double value) {
        return () -> {
            return new tree.Leaf(value);
        };
    }

    public Astree add(final Astree left, final Astree right) {
        return () -> {
            return new tree.Node(java.util.Arrays.asList(left.astree(), right.astree()), new IdzPowerExpAlg().add(null, null).idz());
        };
    }
}
