package algebra.oo;

public class Lit extends Exp {

    public Lit(Double value) {
        this.value = value;
    }

    private Double value;

    public algebra.CombinedExpAlg.Combined convert(algebra.CombinedExpAlg algebra) {
        return algebra.lit(value);
    }
}
