package trivially;

public interface AddAstreeIdz extends ExpAstreeIdz, AddCollectSimplify {

    ExpAstreeIdz getLeft();

    ExpAstreeIdz getRight();

    default tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getLeft().astree(), getRight().astree()), this.idz());
    }

    default Integer idz() {
        return 65665;
    }
}
