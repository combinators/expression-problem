package oo;

public class Add extends Exp {

    public Add(Exp left, Exp right) {
        this.left = left;
        this.right = right;
    }

    private Exp left;

    private Exp right;

    public Exp simplify() {
        double leftVal = left.eval();
        double rightVal = right.eval();
        if ((leftVal == 0 && rightVal == 0) || (leftVal + rightVal == 0)) {
            return new Lit(0.0);
        } else if (leftVal == 0) {
            return right.simplify();
        } else if (rightVal == 0) {
            return left.simplify();
        } else {
            return new Add(left.simplify(), right.simplify());
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> list = left.collect();
        list.addAll(right.collect());
        return list;
    }

    public String print() {
        return "(" + left.print() + "+" + right.print() + ")";
    }

    public Double eval() {
        return left.eval() + right.eval();
    }
}
