package trivially;

public interface SqrtAstreeIdz extends ExpAstreeIdz, SqrtCollectSimplify {

    ExpAstreeIdz getInner();

    default tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getInner().astree()), this.idz());
    }

    default Integer idz() {
        return 2584896;
    }
}
