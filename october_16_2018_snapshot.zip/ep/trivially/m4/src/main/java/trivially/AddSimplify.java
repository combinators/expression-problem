package trivially;

public interface AddSimplify extends ExpSimplify, AddPrettyp {

    ExpSimplify getLeft();

    ExpSimplify getRight();

    default ExpSimplify simplify() {
        double leftVal = getLeft().eval();
        double rightVal = getRight().eval();
        if ((leftVal == 0 && rightVal == 0) || (leftVal + rightVal == 0)) {
            return new Lit(0.0);
        } else if (leftVal == 0) {
            return getRight().simplify();
        } else if (rightVal == 0) {
            return getLeft().simplify();
        } else {
            return new Add((FinalI) (getLeft().simplify()), (FinalI) (getRight().simplify()));
        }
    }
}
