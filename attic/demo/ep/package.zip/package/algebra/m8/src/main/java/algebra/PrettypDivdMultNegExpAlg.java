package algebra;

public class PrettypDivdMultNegExpAlg extends PrettypSubExpAlg implements DivdMultNegExpAlg<Prettyp> {

    public Prettyp neg(final Prettyp inner) {
        return () -> {
            return "-" + inner.prettyp();
        };
    }

    public Prettyp mult(final Prettyp left, final Prettyp right) {
        return () -> {
            return "(" + left.prettyp() + "*" + right.prettyp() + ")";
        };
    }

    public Prettyp divd(final Prettyp left, final Prettyp right) {
        return () -> {
            return "(" + left.prettyp() + "/" + right.prettyp() + ")";
        };
    }
}
