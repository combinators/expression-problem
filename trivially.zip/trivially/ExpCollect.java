package trivially;

public interface ExpCollect extends ExpPrint {

    public java.util.List<Double> collect();
}
