package algebra;

interface PowerExpAlg<E> extends SqrtExpAlg<E> {

    E power(final E left, final E right);
}
