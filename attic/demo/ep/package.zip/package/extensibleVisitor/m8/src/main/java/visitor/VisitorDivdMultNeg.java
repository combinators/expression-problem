package visitor;

public interface VisitorDivdMultNeg<R> extends VisitorSub<R> {

    public R visit(Neg exp);

    public R visit(Mult exp);

    public R visit(Divd exp);
}
