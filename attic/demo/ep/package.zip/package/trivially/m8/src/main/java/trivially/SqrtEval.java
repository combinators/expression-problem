package trivially;

public interface SqrtEval extends ExpEval {

    ExpEval getInner();

    default Double eval() {
        return Math.sqrt(getInner().eval());
    }
}
