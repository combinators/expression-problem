package trivially;

public interface AddId extends ExpId {

    ExpId getLeft();

    ExpId getRight();

    default Integer id() {
        return 65665;
    }
}
