package trivially;

public interface FinalI extends ExpPrettyp {
}
