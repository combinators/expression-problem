package trivially;

public interface SubPrint extends ExpPrint, SubEval {

    ExpPrint getLeft();

    ExpPrint getRight();

    default String print() {
        return "(" + getLeft().print() + "-" + getRight().print() + ")";
    }
}
