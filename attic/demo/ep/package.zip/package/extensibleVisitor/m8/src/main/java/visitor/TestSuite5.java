package visitor;

import junit.framework.TestCase;

public class TestSuite5 extends TestCase {

    public void test() {
        assertEquals("(5.0+7.0)", new Add(new Add(new Lit(new Double(5.0)), new Lit(new Double(0.0))), new Add(new Lit(new Double(0.0)), new Lit(new Double(7.0)))).accept(makeSimplify()).accept(makePrettyp()));
        assertEquals("(5.0/7.0)", new Divd(new Divd(new Lit(new Double(5.0)), new Lit(new Double(7.0))), new Sub(new Lit(new Double(7.0)), new Mult(new Lit(new Double(2.0)), new Lit(new Double(3.0))))).accept(makeSimplify()).accept(makePrettyp()));
        assertEquals(new Double(0.0), new Neg(new Lit(new Double(0.0))).accept(makeSimplify()).accept(makeEval()));
        assertEquals(new Double(5.0), new Add(new Lit(new Double(5.0)), new Lit(new Double(0.0))).accept(makeSimplify()).accept(makeEval()));
        assertEquals(new Double(7.0), new Add(new Lit(new Double(0.0)), new Lit(new Double(7.0))).accept(makeSimplify()).accept(makeEval()));
        assertEquals(new Double(13.0), new Mult(new Lit(new Double(13.0)), new Lit(new Double(1.0))).accept(makeSimplify()).accept(makeEval()));
        assertEquals(new Double(12.0), new Mult(new Lit(new Double(1.0)), new Lit(new Double(12.0))).accept(makeSimplify()).accept(makeEval()));
        assertEquals(new Double(0.0), new Sub(new Lit(new Double(7.0)), new Lit(new Double(7.0))).accept(makeSimplify()).accept(makeEval()));
        assertEquals(new Double(-1.0), new Divd(new Lit(new Double(5.0)), new Lit(new Double(-5.0))).accept(makeSimplify()).accept(makeEval()));
        assertEquals(new Double(1.0), new Divd(new Lit(new Double(-5.0)), new Lit(new Double(-5.0))).accept(makeSimplify()).accept(makeEval()));
        assertEquals(new Double(0.0), new Divd(new Lit(new Double(0.0)), new Lit(new Double(-5.0))).accept(makeSimplify()).accept(makeEval()));
    }

    CopyPower makeCopy() {
        return new CopyPower();
    }

    FindPower makeFind(Double target) {
        return new FindPower(target);
    }

    EqualsPower makeEquals(Exp that) {
        return new EqualsPower(that);
    }

    AstreePower makeAstree() {
        return new AstreePower();
    }

    IdzPower makeIdz() {
        return new IdzPower();
    }

    SimplifyPower makeSimplify() {
        return new SimplifyPower();
    }

    CollectPower makeCollect() {
        return new CollectPower();
    }

    PrettypPower makePrettyp() {
        return new PrettypPower();
    }

    EvalPower makeEval() {
        return new EvalPower();
    }
}
