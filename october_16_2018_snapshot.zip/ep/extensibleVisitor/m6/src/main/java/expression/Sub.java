package expression;

public class Sub extends Exp {

    public Sub(Exp left, Exp right) {
        this.left = left;
        this.right = right;
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(left.astree(), right.astree()), 83488);
    }

    private Exp left;

    private Exp right;

    public Exp getLeft() {
        return this.left;
    }

    public Exp getRight() {
        return this.right;
    }

    public <R> R accept(Visitor<R> v) {
        if (v instanceof VisitorSub) {
            return ((VisitorSub<R>) v).visit(this);
        }
        throw new RuntimeException("Older visitor used with newer datatype variant.");
    }
}
