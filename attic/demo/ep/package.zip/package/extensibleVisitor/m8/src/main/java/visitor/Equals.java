package visitor;

public class Equals implements VisitorDivdMultNeg<Boolean> {

    public Boolean visit(Neg e) {
        return e.accept(makeAstree()).same(that.accept(makeAstree()));
    }

    public Boolean visit(Mult e) {
        return e.accept(makeAstree()).same(that.accept(makeAstree()));
    }

    public Boolean visit(Divd e) {
        return e.accept(makeAstree()).same(that.accept(makeAstree()));
    }

    public Boolean visit(Sub e) {
        return e.accept(makeAstree()).same(that.accept(makeAstree()));
    }

    public Boolean visit(Lit e) {
        return e.accept(makeAstree()).same(that.accept(makeAstree()));
    }

    public Boolean visit(Add e) {
        return e.accept(makeAstree()).same(that.accept(makeAstree()));
    }

    public Equals(Exp that) {
        this.that = that;
    }

    Exp that;

    Equals makeEquals(Exp that) {
        return new Equals(that);
    }

    Astree makeAstree() {
        return new Astree();
    }
}
