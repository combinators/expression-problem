package trivially;

public interface AddAstree extends ExpAstree, AddSimplify, AddCollect {

    ExpAstree getLeft();

    ExpAstree getRight();

    default tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getLeft().astree(), getRight().astree()), this.id());
    }
}
