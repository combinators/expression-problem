package visitor;

public class PrettypSqrt extends PrettypDivdMultNeg implements VisitorSqrt<String> {

    public String visit(Sqrt e) {
        return "Sqrt(" + e.getInner().accept(makePrettyp()) + ")";
    }

    PrettypSqrt makePrettyp() {
        return new PrettypSqrt();
    }
}
