package expression;

public class Collect implements VisitorDivdMultNeg<java.util.List<Double>> {

    public java.util.List<Double> visit(Neg e) {
        java.util.List<Double> list = new java.util.ArrayList<Double>();
        list.addAll(e.getInner().accept(makeCollect()));
        return list;
    }

    public java.util.List<Double> visit(Mult e) {
        java.util.List<Double> list = e.getLeft().accept(makeCollect());
        list.addAll(e.getRight().accept(makeCollect()));
        return list;
    }

    public java.util.List<Double> visit(Divd e) {
        java.util.List<Double> list = e.getLeft().accept(makeCollect());
        list.addAll(e.getRight().accept(makeCollect()));
        return list;
    }

    public java.util.List<Double> visit(Sub e) {
        java.util.List<Double> list = e.getLeft().accept(makeCollect());
        list.addAll(e.getRight().accept(makeCollect()));
        return list;
    }

    public java.util.List<Double> visit(Lit e) {
        java.util.List<Double> list = new java.util.ArrayList<Double>();
        list.add(e.getValue());
        return list;
    }

    public java.util.List<Double> visit(Add e) {
        java.util.List<Double> list = e.getLeft().accept(makeCollect());
        list.addAll(e.getRight().accept(makeCollect()));
        return list;
    }

    Collect makeCollect() {
        return new Collect();
    }
}
