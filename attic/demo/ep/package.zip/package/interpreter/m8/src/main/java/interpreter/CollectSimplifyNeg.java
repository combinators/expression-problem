package interpreter;

import static interpreter.CollectSimplifyExpFactory.*;

public class CollectSimplifyNeg extends PrettypNeg implements CollectSimplifyExp {

    public CollectSimplifyNeg(CollectSimplifyExp inner) {
        super(inner);
    }

    public CollectSimplifyExp getInner() {
        return (CollectSimplifyExp) this.inner;
    }

    public CollectSimplifyExp simplify() {
        if (getInner().eval() == 0) {
            return Lit(0.0);
        } else {
            return Neg(getInner().simplify());
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList2 = new java.util.ArrayList<>();
        tmpList2.addAll(getInner().collect());
        return tmpList2;
    }

    @Override
    public <R> R accept(KnownDataTypes<R> from) {
        return from.convert(this);
    }
}
