package algebra;

interface Prettyp {

    String prettyp();
}
