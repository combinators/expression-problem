package interpreter;

public interface CollectSimplifyExp extends PrettypExp {

    public CollectSimplifyExp simplify();

    public java.util.List<Double> collect();
}
