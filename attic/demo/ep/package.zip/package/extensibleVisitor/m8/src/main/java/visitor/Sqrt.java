package visitor;

public class Sqrt extends Exp {

    public Sqrt(Exp inner) {
        this.inner = inner;
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(inner.astree()), 2584896);
    }

    private Exp inner;

    public Exp getInner() {
        return this.inner;
    }

    public <R> R accept(Visitor<R> v) {
        if (v instanceof VisitorSqrt) {
            return ((VisitorSqrt<R>) v).visit(this);
        }
        throw new RuntimeException("Older visitor used with newer datatype variant.");
    }
}
