package interpreter;

public class EvalAdd implements EvalExp {

    EvalExp Lit(Double value) {
        return new EvalLit(value);
    }

    EvalExp Add(EvalExp left, EvalExp right) {
        return new EvalAdd(left, right);
    }

    public EvalAdd(EvalExp left, EvalExp right) {
        this.left = left;
        this.right = right;
    }

    public EvalExp getLeft() {
        return this.left;
    }

    public EvalExp getRight() {
        return this.right;
    }

    EvalExp left;

    EvalExp right;

    public Double eval() {
        return getLeft().eval() + getRight().eval();
    }
}
