package trivially;

public interface LitEval extends ExpEval {

    Double getValue();

    default Double eval() {
        return getValue();
    }
}
