package interpreter;

import static interpreter.CollectSimplifyExpFactory.*;

public class CollectSimplifyMult extends PrettypMult implements CollectSimplifyExp {

    public CollectSimplifyMult(CollectSimplifyExp left, CollectSimplifyExp right) {
        super(left, right);
    }

    public CollectSimplifyExp getLeft() {
        return (CollectSimplifyExp) this.left;
    }

    public CollectSimplifyExp getRight() {
        return (CollectSimplifyExp) this.right;
    }

    public CollectSimplifyExp simplify() {
        double leftVal = getLeft().eval();
        double rightVal = getRight().eval();
        if (leftVal == 0 || rightVal == 0) {
            return Lit(0.0);
        } else if (leftVal == 1) {
            return getRight().simplify();
        } else if (rightVal == 1) {
            return getLeft().simplify();
        } else {
            return Mult(getLeft().simplify(), getRight().simplify());
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList3 = new java.util.ArrayList<>();
        tmpList3.addAll(getLeft().collect());
        tmpList3.addAll(getRight().collect());
        return tmpList3;
    }

    @Override
    public <R> R accept(KnownDataTypes<R> from) {
        return from.convert(this);
    }
}
