package trivially;

public interface DivdCollect extends ExpCollect, DivdPrint {

    ExpCollect getLeft();

    ExpCollect getRight();

    default java.util.List<Double> collect() {
        java.util.List<Double> list = getLeft().collect();
        list.addAll(getRight().collect());
        return list;
    }
}
