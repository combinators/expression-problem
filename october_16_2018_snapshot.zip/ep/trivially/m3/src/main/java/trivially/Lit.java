package trivially;

public class Lit implements FinalI, LitPrettyp {

    public Lit(Double value) {
        this.value = value;
    }

    public Double getValue() {
        return this.value;
    }

    private Double value;
}
