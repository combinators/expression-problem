
#ifndef _Add_
#define _Add_

#include "visitor.h" 
#include "Exp.h" 
#include "ExpVisitor.h" 

class Add : public Exp {
public:
  const Exp* getLeft() const { return left_; }
  const Exp* getRight() const { return right_; }
  Add (const Exp* left,const Exp* right) : left_(left),right_(right) {}
  void Accept(ExpVisitor* visitor) const;

private:
  const Exp* left_;
  const Exp* right_;
};
#endif /* _Add_ */
       