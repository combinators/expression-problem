package interpreter;

import junit.framework.TestCase;

public class TestSuite2 extends TestCase {

    public void test() {
        assertEquals(-1.0, new EvalIdSub(new EvalIdLit(1.0), new EvalIdLit(2.0)).eval());
    }
}
