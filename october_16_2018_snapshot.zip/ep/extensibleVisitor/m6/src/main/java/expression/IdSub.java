package expression;

public class IdSub extends Id implements VisitorSub<Integer> {

    public Integer visit(Sub e) {
        return 83488;
    }

    Id makeId() {
        return new IdSub();
    }
}
