package algebra;

public class FindPowerExpAlg extends FindSqrtExpAlg implements PowerExpAlg<Find> {

    public Find power(final Find left, final Find right) {
        return (Double target) -> {
            return left.find(target) + right.find(target);
        };
    }
}
