package trivially;

public interface FinalI extends ExpEquals {
}
