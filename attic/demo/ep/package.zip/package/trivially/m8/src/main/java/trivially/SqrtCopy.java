package trivially;

public interface SqrtCopy extends ExpCopy, SqrtFind {

    ExpCopy getInner();

    default ExpCopy copy() {
        return new Sqrt((FinalI) (getInner().copy()));
    }
}
