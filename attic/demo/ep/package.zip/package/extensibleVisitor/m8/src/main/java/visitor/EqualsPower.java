package visitor;

public class EqualsPower extends EqualsSqrt implements VisitorPower<Boolean> {

    public EqualsPower(Exp that) {
        super(that);
        this.that = that;
    }

    Exp that;

    public Boolean visit(Power e) {
        return e.accept(makeAstree()).same(that.accept(makeAstree()));
    }

    EqualsPower makeEquals(Exp that) {
        return new EqualsPower(that);
    }
}
