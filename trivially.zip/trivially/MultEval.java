package trivially;

public interface MultEval extends ExpEval {

    ExpEval getLeft();

    ExpEval getRight();

    default Double eval() {
        return getLeft().eval() * getRight().eval();
    }
}
