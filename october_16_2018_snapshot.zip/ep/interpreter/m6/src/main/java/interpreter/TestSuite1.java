package interpreter;

import junit.framework.TestCase;

public class TestSuite1 extends TestCase {

    public void test() {
        assertEquals(3.0, new EqualsAdd(new EqualsLit(1.0), new EqualsLit(2.0)).eval());
        assertEquals(5.0, new EqualsLit(5.0).eval());
    }
}
