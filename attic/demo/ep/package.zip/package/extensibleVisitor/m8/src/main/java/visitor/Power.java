package visitor;

public class Power extends Exp {

    public Power(Exp left, Exp right) {
        this.left = left;
        this.right = right;
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(left.astree(), right.astree()), 77306085);
    }

    private Exp left;

    private Exp right;

    public Exp getLeft() {
        return this.left;
    }

    public Exp getRight() {
        return this.right;
    }

    public <R> R accept(Visitor<R> v) {
        if (v instanceof VisitorPower) {
            return ((VisitorPower<R>) v).visit(this);
        }
        throw new RuntimeException("Older visitor used with newer datatype variant.");
    }
}
