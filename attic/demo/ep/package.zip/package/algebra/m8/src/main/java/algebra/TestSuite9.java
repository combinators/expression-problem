package algebra;

import junit.framework.TestCase;

public class TestSuite9 extends TestCase {

    EqualsPowerExpAlg algebraEquals = new EqualsPowerExpAlg();

    AstreePowerExpAlg algebraAstree = new AstreePowerExpAlg();

    FindPowerExpAlg algebraFind = new FindPowerExpAlg();

    CollectPowerExpAlg algebraCollect = new CollectPowerExpAlg();

    EvalPowerExpAlg algebraEval = new EvalPowerExpAlg();

    PrettypPowerExpAlg algebraPrettyp = new PrettypPowerExpAlg();

    IdzPowerExpAlg algebraIdz = new IdzPowerExpAlg();

    CombinedExpAlg algebra = new CombinedExpAlg(algebraAstree, algebraCollect, algebraEquals, algebraEval, algebraFind, algebraIdz, algebraPrettyp);

    public void test() {
        assertEquals(new Double(36.0), algebra.power(algebra.lit(new Double(6.0)), algebra.lit(new Double(2.0))).eval());
        assertEquals("Power(25.0,-0.5)", algebra.power(algebra.lit(new Double(25.0)), algebra.lit(new Double(-0.5))).prettyp());
        assertEquals(new Double(1.0), algebra.power(algebra.lit(new Double(10.0)), algebra.lit(new Double(0.0))).eval());
        assertEquals("1.0", algebra.power(algebra.lit(new Double(10.0)), algebra.lit(new Double(0.0))).simplify().prettyp());
        java.util.ArrayList<tree.Tree> list25 = new java.util.ArrayList<>();
        tree.Tree leaf27 = new tree.Leaf(2.0);
        list25.add(leaf27);
        java.util.ArrayList<tree.Tree> list28 = new java.util.ArrayList<>();
        tree.Tree leaf30 = new tree.Leaf(7.0);
        list28.add(leaf30);
        tree.Node node29 = new tree.Node(list28, 2584896);
        list25.add(node29);
        tree.Node node26 = new tree.Node(list25, 2409808);
        assertEquals(node26, algebra.mult(algebra.lit(new Double(2.0)), algebra.sqrt(algebra.lit(new Double(7.0)))).copy().astree());
    }
}
