package interpreter;

public class EvalNeg implements EvalExp {

    public EvalNeg(EvalExp inner) {
        this.inner = inner;
    }

    public EvalExp getInner() {
        return this.inner;
    }

    EvalExp inner;

    public Double eval() {
        return -getInner().eval();
    }
}
