package interpreter;

public class EvalIdSub implements EvalIdExp {

    EvalIdExp Sub(EvalIdExp left, EvalIdExp right) {
        return new EvalIdSub(left, right);
    }

    public EvalIdSub(EvalIdExp left, EvalIdExp right) {
        this.left = left;
        this.right = right;
    }

    public EvalIdExp getLeft() {
        return this.left;
    }

    public EvalIdExp getRight() {
        return this.right;
    }

    EvalIdExp left;

    EvalIdExp right;

    public Double eval() {
        return getLeft().eval() - getRight().eval();
    }

    public Integer id() {
        return 83488;
    }
}
