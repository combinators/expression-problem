package interpreter;

import junit.framework.TestCase;

public class TestSuite1 extends TestCase {

    public void test() {
        assertEquals(3.0, new EvalIdAdd(new EvalIdLit(1.0), new EvalIdLit(2.0)).eval());
        assertEquals(5.0, new EvalIdLit(5.0).eval());
    }
}
