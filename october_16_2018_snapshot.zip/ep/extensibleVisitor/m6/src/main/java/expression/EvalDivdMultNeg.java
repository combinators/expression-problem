package expression;

public class EvalDivdMultNeg extends EvalSub implements VisitorDivdMultNeg<Double> {

    public Double visit(Neg e) {
        return -e.getInner().accept(makeEval());
    }

    public Double visit(Mult e) {
        return e.getLeft().accept(makeEval()) * e.getRight().accept(makeEval());
    }

    public Double visit(Divd e) {
        return e.getLeft().accept(makeEval()) / e.getRight().accept(makeEval());
    }

    Eval makeEval() {
        return new EvalDivdMultNeg();
    }
}
