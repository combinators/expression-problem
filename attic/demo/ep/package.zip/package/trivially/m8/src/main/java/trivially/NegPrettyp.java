package trivially;

public interface NegPrettyp extends ExpPrettyp, NegEval {

    ExpPrettyp getInner();

    default String prettyp() {
        return "-" + getInner().prettyp();
    }
}
