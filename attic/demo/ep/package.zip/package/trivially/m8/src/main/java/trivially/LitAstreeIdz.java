package trivially;

public interface LitAstreeIdz extends ExpAstreeIdz, LitCollectSimplify {

    Double getValue();

    default tree.Tree astree() {
        return new tree.Leaf(getValue());
    }

    default Integer idz() {
        return 76407;
    }
}
