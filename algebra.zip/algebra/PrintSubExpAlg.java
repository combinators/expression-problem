package algebra;

public class PrintSubExpAlg implements SubExpAlg<Print> {

    public Print sub(final Print left, final Print right) {
        return new Print() {

            public String print() {
                return "(" + left.print() + "-" + right.print() + ")";
            }
        };
    }

    public Print lit(final Double value) {
        return new Print() {

            public String print() {
                return "" + value + "";
            }
        };
    }

    public Print add(final Print left, final Print right) {
        return new Print() {

            public String print() {
                return "(" + left.print() + "+" + right.print() + ")";
            }
        };
    }
}
