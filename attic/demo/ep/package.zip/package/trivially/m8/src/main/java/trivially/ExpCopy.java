package trivially;

public interface ExpCopy extends ExpFind {

    public ExpCopy copy();
}
