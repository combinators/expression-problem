package expression;

import junit.framework.TestCase;

public class TestSuite5 extends TestCase {

    public void test() {
        // Handle collect checks
        java.util.List<Double> list1 = new Divd(new Divd(new Lit(5.0), new Lit(7.0)), new Sub(new Lit(7.0), new Mult(new Lit(2.0), new Lit(3.0)))).accept(makeCollect());
        java.util.List<Double> result = new java.util.ArrayList<Double>();
        result.add(5.0);
        result.add(7.0);
        result.add(7.0);
        result.add(2.0);
        result.add(3.0);
        assertEquals(list1, result);
    }

    Equals makeEquals(Exp that) {
        return new Equals(that);
    }

    Astree makeAstree() {
        return new Astree();
    }

    Simplify makeSimplify() {
        return new Simplify();
    }

    Collect makeCollect() {
        return new Collect();
    }

    Prettyp makePrettyp() {
        return new PrettypDivdMultNeg();
    }

    Eval makeEval() {
        return new EvalDivdMultNeg();
    }

    Id makeId() {
        return new IdDivdMultNeg();
    }
}
