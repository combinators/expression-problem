package visitor;

public class Find extends Visitor<Integer> {

    public Find(Double target) {
        this.target = target;
    }

    Double target;

    public Integer visit(Power e) {
        return e.getLeft().accept(new Find(target)) + e.getRight().accept(new Find(target));
    }

    public Integer visit(Sqrt e) {
        return e.getInner().accept(new Find(target));
    }

    public Integer visit(Neg e) {
        return e.getInner().accept(new Find(target));
    }

    public Integer visit(Mult e) {
        return e.getLeft().accept(new Find(target)) + e.getRight().accept(new Find(target));
    }

    public Integer visit(Divd e) {
        return e.getLeft().accept(new Find(target)) + e.getRight().accept(new Find(target));
    }

    public Integer visit(Sub e) {
        return e.getLeft().accept(new Find(target)) + e.getRight().accept(new Find(target));
    }

    public Integer visit(Lit e) {
        double _litEval = e.getValue();
        if (_litEval == target) {
            return 1;
        } else {
            return 0;
        }
    }

    public Integer visit(Add e) {
        return e.getLeft().accept(new Find(target)) + e.getRight().accept(new Find(target));
    }
}
