package expression;

public class Eval extends Visitor<Double> {

    public Double visit(Neg e) {
        return -e.getInner().accept(new Eval());
    }

    public Double visit(Mult e) {
        return e.getLeft().accept(new Eval()) * e.getRight().accept(new Eval());
    }

    public Double visit(Divd e) {
        return e.getLeft().accept(new Eval()) / e.getRight().accept(new Eval());
    }

    public Double visit(Sub e) {
        return e.getLeft().accept(new Eval()) - e.getRight().accept(new Eval());
    }

    public Double visit(Lit e) {
        return e.getValue();
    }

    public Double visit(Add e) {
        return e.getLeft().accept(new Eval()) + e.getRight().accept(new Eval());
    }
}
