package algebra;

// generated from all algebras
public class CombinedExpAlg implements PowerExpAlg<CombinedExpAlg.Combined> {

    // combine together
    public interface Combined extends Copy, Find, Equals, Astree, Idz, Simplify, Collect, Prettyp, Eval {

        // Convert from Algebra into OO straw-man implementation
        algebra.oo.Exp convert();
    }

    // individual algebras, followed by combined one
    EqualsPowerExpAlg algebraEquals;

    AstreePowerExpAlg algebraAstree;

    FindPowerExpAlg algebraFind;

    CollectPowerExpAlg algebraCollect;

    EvalPowerExpAlg algebraEval;

    PrettypPowerExpAlg algebraPrettyp;

    IdzPowerExpAlg algebraIdz;

    // producer method algebras are instantiated here, since that is all that is needed.
    CopyPowerExpAlg algebraCopy;

    SimplifyPowerExpAlg algebraSimplify;

    CombinedExpAlg(AstreePowerExpAlg algebraAstree, CollectPowerExpAlg algebraCollect, EqualsPowerExpAlg algebraEquals, EvalPowerExpAlg algebraEval, FindPowerExpAlg algebraFind, IdzPowerExpAlg algebraIdz, PrettypPowerExpAlg algebraPrettyp) {
        this.algebraEquals = algebraEquals;
        this.algebraAstree = algebraAstree;
        this.algebraFind = algebraFind;
        this.algebraCollect = algebraCollect;
        this.algebraEval = algebraEval;
        this.algebraPrettyp = algebraPrettyp;
        this.algebraIdz = algebraIdz;
        this.algebraCopy = new CopyPowerExpAlg(this);
        this.algebraSimplify = new SimplifyPowerExpAlg(this);
    }

    public Combined power(Combined left, Combined right) {
        return new Combined() {

            public algebra.oo.Exp convert() {
                return new algebra.oo.Power(left.convert(), right.convert());
            }

            public Combined copy() {
                return algebraCopy.power(left, right).copy();
            }

            public Integer find(Double target) {
                return algebraFind.power(left, right).find(target);
            }

            public Boolean equals(Equals that) {
                return algebraEquals.power(left, right).equals(that);
            }

            public tree.Tree astree() {
                return algebraAstree.power(left, right).astree();
            }

            public Integer idz() {
                return algebraIdz.power(left, right).idz();
            }

            public Combined simplify() {
                return algebraSimplify.power(left, right).simplify();
            }

            public java.util.List<Double> collect() {
                return algebraCollect.power(left, right).collect();
            }

            public String prettyp() {
                return algebraPrettyp.power(left, right).prettyp();
            }

            public Double eval() {
                return algebraEval.power(left, right).eval();
            }
        };
    }

    public Combined sqrt(Combined inner) {
        return new Combined() {

            public algebra.oo.Exp convert() {
                return new algebra.oo.Sqrt(inner.convert());
            }

            public Combined copy() {
                return algebraCopy.sqrt(inner).copy();
            }

            public Integer find(Double target) {
                return algebraFind.sqrt(inner).find(target);
            }

            public Boolean equals(Equals that) {
                return algebraEquals.sqrt(inner).equals(that);
            }

            public tree.Tree astree() {
                return algebraAstree.sqrt(inner).astree();
            }

            public Integer idz() {
                return algebraIdz.sqrt(inner).idz();
            }

            public Combined simplify() {
                return algebraSimplify.sqrt(inner).simplify();
            }

            public java.util.List<Double> collect() {
                return algebraCollect.sqrt(inner).collect();
            }

            public String prettyp() {
                return algebraPrettyp.sqrt(inner).prettyp();
            }

            public Double eval() {
                return algebraEval.sqrt(inner).eval();
            }
        };
    }

    public Combined neg(Combined inner) {
        return new Combined() {

            public algebra.oo.Exp convert() {
                return new algebra.oo.Neg(inner.convert());
            }

            public Combined copy() {
                return algebraCopy.neg(inner).copy();
            }

            public Integer find(Double target) {
                return algebraFind.neg(inner).find(target);
            }

            public Boolean equals(Equals that) {
                return algebraEquals.neg(inner).equals(that);
            }

            public tree.Tree astree() {
                return algebraAstree.neg(inner).astree();
            }

            public Integer idz() {
                return algebraIdz.neg(inner).idz();
            }

            public Combined simplify() {
                return algebraSimplify.neg(inner).simplify();
            }

            public java.util.List<Double> collect() {
                return algebraCollect.neg(inner).collect();
            }

            public String prettyp() {
                return algebraPrettyp.neg(inner).prettyp();
            }

            public Double eval() {
                return algebraEval.neg(inner).eval();
            }
        };
    }

    public Combined mult(Combined left, Combined right) {
        return new Combined() {

            public algebra.oo.Exp convert() {
                return new algebra.oo.Mult(left.convert(), right.convert());
            }

            public Combined copy() {
                return algebraCopy.mult(left, right).copy();
            }

            public Integer find(Double target) {
                return algebraFind.mult(left, right).find(target);
            }

            public Boolean equals(Equals that) {
                return algebraEquals.mult(left, right).equals(that);
            }

            public tree.Tree astree() {
                return algebraAstree.mult(left, right).astree();
            }

            public Integer idz() {
                return algebraIdz.mult(left, right).idz();
            }

            public Combined simplify() {
                return algebraSimplify.mult(left, right).simplify();
            }

            public java.util.List<Double> collect() {
                return algebraCollect.mult(left, right).collect();
            }

            public String prettyp() {
                return algebraPrettyp.mult(left, right).prettyp();
            }

            public Double eval() {
                return algebraEval.mult(left, right).eval();
            }
        };
    }

    public Combined divd(Combined left, Combined right) {
        return new Combined() {

            public algebra.oo.Exp convert() {
                return new algebra.oo.Divd(left.convert(), right.convert());
            }

            public Combined copy() {
                return algebraCopy.divd(left, right).copy();
            }

            public Integer find(Double target) {
                return algebraFind.divd(left, right).find(target);
            }

            public Boolean equals(Equals that) {
                return algebraEquals.divd(left, right).equals(that);
            }

            public tree.Tree astree() {
                return algebraAstree.divd(left, right).astree();
            }

            public Integer idz() {
                return algebraIdz.divd(left, right).idz();
            }

            public Combined simplify() {
                return algebraSimplify.divd(left, right).simplify();
            }

            public java.util.List<Double> collect() {
                return algebraCollect.divd(left, right).collect();
            }

            public String prettyp() {
                return algebraPrettyp.divd(left, right).prettyp();
            }

            public Double eval() {
                return algebraEval.divd(left, right).eval();
            }
        };
    }

    public Combined sub(Combined left, Combined right) {
        return new Combined() {

            public algebra.oo.Exp convert() {
                return new algebra.oo.Sub(left.convert(), right.convert());
            }

            public Combined copy() {
                return algebraCopy.sub(left, right).copy();
            }

            public Integer find(Double target) {
                return algebraFind.sub(left, right).find(target);
            }

            public Boolean equals(Equals that) {
                return algebraEquals.sub(left, right).equals(that);
            }

            public tree.Tree astree() {
                return algebraAstree.sub(left, right).astree();
            }

            public Integer idz() {
                return algebraIdz.sub(left, right).idz();
            }

            public Combined simplify() {
                return algebraSimplify.sub(left, right).simplify();
            }

            public java.util.List<Double> collect() {
                return algebraCollect.sub(left, right).collect();
            }

            public String prettyp() {
                return algebraPrettyp.sub(left, right).prettyp();
            }

            public Double eval() {
                return algebraEval.sub(left, right).eval();
            }
        };
    }

    public Combined lit(Double value) {
        return new Combined() {

            public algebra.oo.Exp convert() {
                return new algebra.oo.Lit(value);
            }

            public Combined copy() {
                return algebraCopy.lit(value).copy();
            }

            public Integer find(Double target) {
                return algebraFind.lit(value).find(target);
            }

            public Boolean equals(Equals that) {
                return algebraEquals.lit(value).equals(that);
            }

            public tree.Tree astree() {
                return algebraAstree.lit(value).astree();
            }

            public Integer idz() {
                return algebraIdz.lit(value).idz();
            }

            public Combined simplify() {
                return algebraSimplify.lit(value).simplify();
            }

            public java.util.List<Double> collect() {
                return algebraCollect.lit(value).collect();
            }

            public String prettyp() {
                return algebraPrettyp.lit(value).prettyp();
            }

            public Double eval() {
                return algebraEval.lit(value).eval();
            }
        };
    }

    public Combined add(Combined left, Combined right) {
        return new Combined() {

            public algebra.oo.Exp convert() {
                return new algebra.oo.Add(left.convert(), right.convert());
            }

            public Combined copy() {
                return algebraCopy.add(left, right).copy();
            }

            public Integer find(Double target) {
                return algebraFind.add(left, right).find(target);
            }

            public Boolean equals(Equals that) {
                return algebraEquals.add(left, right).equals(that);
            }

            public tree.Tree astree() {
                return algebraAstree.add(left, right).astree();
            }

            public Integer idz() {
                return algebraIdz.add(left, right).idz();
            }

            public Combined simplify() {
                return algebraSimplify.add(left, right).simplify();
            }

            public java.util.List<Double> collect() {
                return algebraCollect.add(left, right).collect();
            }

            public String prettyp() {
                return algebraPrettyp.add(left, right).prettyp();
            }

            public Double eval() {
                return algebraEval.add(left, right).eval();
            }
        };
    }
}
