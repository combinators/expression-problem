package interpreter;

public class EvalIdAdd implements EvalIdExp {

    EvalIdExp Lit(Double value) {
        return new EvalIdLit(value);
    }

    EvalIdExp Add(EvalIdExp left, EvalIdExp right) {
        return new EvalIdAdd(left, right);
    }

    public EvalIdAdd(EvalIdExp left, EvalIdExp right) {
        this.left = left;
        this.right = right;
    }

    public EvalIdExp getLeft() {
        return this.left;
    }

    public EvalIdExp getRight() {
        return this.right;
    }

    EvalIdExp left;

    EvalIdExp right;

    public Double eval() {
        return getLeft().eval() + getRight().eval();
    }

    public Integer id() {
        return 65665;
    }
}
