package algebra;

interface Copy {

    algebra.CombinedExpAlg.Combined copy();
}
