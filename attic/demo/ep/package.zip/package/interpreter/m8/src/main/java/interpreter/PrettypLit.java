package interpreter;

public class PrettypLit extends EvalLit implements PrettypExp {

    public PrettypLit(Double value) {
        super(value);
    }

    public Double getValue() {
        return this.value;
    }

    public String prettyp() {
        return "" + getValue();
    }
}
