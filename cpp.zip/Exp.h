
#ifndef _Exp_
#define _Exp_

#include "visitor.h" 
class ExpVisitor;

class Exp  {
public:
  virtual void Accept(ExpVisitor* visitor) const = 0;

private:

};
#endif /* _Exp_ */
       