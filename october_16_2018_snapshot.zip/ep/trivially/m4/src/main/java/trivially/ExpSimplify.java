package trivially;

public interface ExpSimplify extends ExpPrettyp {

    public ExpSimplify simplify();
}
