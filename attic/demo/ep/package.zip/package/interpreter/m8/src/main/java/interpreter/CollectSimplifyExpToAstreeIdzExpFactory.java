package interpreter;

public class CollectSimplifyExpToAstreeIdzExpFactory implements AstreeIdzExp.KnownDataTypes<AstreeIdzExp> {

    @Override
    public AstreeIdzNeg convert(CollectSimplifyNeg from) {
        return new AstreeIdzNeg(from.getInner().accept(this));
    }

    @Override
    public AstreeIdzMult convert(CollectSimplifyMult from) {
        return new AstreeIdzMult(from.getLeft().accept(this), from.getRight().accept(this));
    }

    @Override
    public AstreeIdzDivd convert(CollectSimplifyDivd from) {
        return new AstreeIdzDivd(from.getLeft().accept(this), from.getRight().accept(this));
    }

    @Override
    public AstreeIdzSub convert(CollectSimplifySub from) {
        return new AstreeIdzSub(from.getLeft().accept(this), from.getRight().accept(this));
    }

    @Override
    public AstreeIdzLit convert(CollectSimplifyLit from) {
        return new AstreeIdzLit(from.getValue());
    }

    @Override
    public AstreeIdzAdd convert(CollectSimplifyAdd from) {
        return new AstreeIdzAdd(from.getLeft().accept(this), from.getRight().accept(this));
    }
}
