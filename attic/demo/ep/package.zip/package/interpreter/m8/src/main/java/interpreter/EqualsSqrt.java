package interpreter;

import static interpreter.EqualsExpFactory.*;

public class EqualsSqrt extends AstreeIdzSqrt implements EqualsExp {

    public EqualsSqrt(EqualsExp inner) {
        super(inner);
    }

    public EqualsExp getInner() {
        return (EqualsExp) this.inner;
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getInner().astree()), this.idz());
    }

    public Integer idz() {
        return 2584896;
    }

    public EqualsExp simplify() {
        return Sqrt(getInner().simplify().accept(new CollectSimplifyExpToEqualsExpFactory()));
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList11 = new java.util.ArrayList<>();
        tmpList11.addAll(getInner().collect());
        return tmpList11;
    }

    public String prettyp() {
        return "Sqrt(" + getInner().prettyp() + ")";
    }

    public Double eval() {
        return Math.sqrt(getInner().eval());
    }

    public Boolean equals(EqualsExp that) {
        return this.astree().same(that.astree());
    }
}
