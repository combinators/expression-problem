package algebra.oo;

public abstract class Exp {

    // Converts from OO solution back to Algebra
    public abstract algebra.CombinedExpAlg.Combined convert(algebra.CombinedExpAlg algebra);
}
