package trivially;

public interface FinalI extends ExpHeight {
}
