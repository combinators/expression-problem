package algebra;

interface Collect {

    java.util.List<Double> collect();
}
