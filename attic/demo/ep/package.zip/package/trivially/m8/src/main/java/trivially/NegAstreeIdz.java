package trivially;

public interface NegAstreeIdz extends ExpAstreeIdz, NegCollectSimplify {

    ExpAstreeIdz getInner();

    default tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getInner().astree()), this.idz());
    }

    default Integer idz() {
        return 78192;
    }
}
