package trivially;

public interface ExpEval extends Exp {

    public Double eval();
}
