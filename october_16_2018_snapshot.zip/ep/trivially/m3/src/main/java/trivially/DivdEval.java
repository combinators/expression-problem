package trivially;

public interface DivdEval extends ExpEval {

    ExpEval getLeft();

    ExpEval getRight();

    default Double eval() {
        return getLeft().eval() / getRight().eval();
    }
}
