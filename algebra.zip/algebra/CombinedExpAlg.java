package algebra;

// generated from all algebras
public class CombinedExpAlg implements DivdMultNegExpAlg<CombinedExpAlg.Combined> {

    // combine together
    interface Combined extends Collect, Print, Eval {
    }

    // individual algebras, followed by combined one
    CollectDivdMultNegExpAlg algebraCollect;

    PrintDivdMultNegExpAlg algebraPrint;

    EvalDivdMultNegExpAlg algebraEval;

    CombinedExpAlg(CollectDivdMultNegExpAlg algebraCollect, EvalDivdMultNegExpAlg algebraEval, PrintDivdMultNegExpAlg algebraPrint) {
        this.algebraCollect = algebraCollect;
        this.algebraPrint = algebraPrint;
        this.algebraEval = algebraEval;
    }

    public Combined neg(Combined inner) {
        return new Combined() {

            public java.util.List<Double> collect() {
                return algebraCollect.neg(inner).collect();
            }

            public String print() {
                return algebraPrint.neg(inner).print();
            }

            public Double eval() {
                return algebraEval.neg(inner).eval();
            }
        };
    }

    public Combined mult(Combined left, Combined right) {
        return new Combined() {

            public java.util.List<Double> collect() {
                return algebraCollect.mult(left, right).collect();
            }

            public String print() {
                return algebraPrint.mult(left, right).print();
            }

            public Double eval() {
                return algebraEval.mult(left, right).eval();
            }
        };
    }

    public Combined divd(Combined left, Combined right) {
        return new Combined() {

            public java.util.List<Double> collect() {
                return algebraCollect.divd(left, right).collect();
            }

            public String print() {
                return algebraPrint.divd(left, right).print();
            }

            public Double eval() {
                return algebraEval.divd(left, right).eval();
            }
        };
    }

    public Combined sub(Combined left, Combined right) {
        return new Combined() {

            public java.util.List<Double> collect() {
                return algebraCollect.sub(left, right).collect();
            }

            public String print() {
                return algebraPrint.sub(left, right).print();
            }

            public Double eval() {
                return algebraEval.sub(left, right).eval();
            }
        };
    }

    public Combined lit(Double value) {
        return new Combined() {

            public java.util.List<Double> collect() {
                return algebraCollect.lit(value).collect();
            }

            public String print() {
                return algebraPrint.lit(value).print();
            }

            public Double eval() {
                return algebraEval.lit(value).eval();
            }
        };
    }

    public Combined add(Combined left, Combined right) {
        return new Combined() {

            public java.util.List<Double> collect() {
                return algebraCollect.add(left, right).collect();
            }

            public String print() {
                return algebraPrint.add(left, right).print();
            }

            public Double eval() {
                return algebraEval.add(left, right).eval();
            }
        };
    }
}
