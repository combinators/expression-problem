package oo;

public abstract class Exp {

    public abstract Exp simplify();

    public abstract java.util.List<Double> collect();

    public abstract String print();

    public abstract Double eval();
}
