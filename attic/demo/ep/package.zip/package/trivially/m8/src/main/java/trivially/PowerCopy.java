package trivially;

public interface PowerCopy extends ExpCopy, PowerFind {

    ExpCopy getLeft();

    ExpCopy getRight();

    default ExpCopy copy() {
        return new Power((FinalI) (getLeft().copy()), (FinalI) (getRight().copy()));
    }
}
