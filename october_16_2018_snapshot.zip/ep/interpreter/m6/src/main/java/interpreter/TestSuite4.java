package interpreter;

import junit.framework.TestCase;

public class TestSuite4 extends TestCase {

    public void test() {
        assertEquals("-1.0", new EqualsNeg(new EqualsLit(1.0)).prettyp());
        assertEquals(-1.0, new EqualsNeg(new EqualsLit(1.0)).eval());
        assertEquals("((5.0/2.0)*4.0)", new EqualsMult(new EqualsDivd(new EqualsLit(5.0), new EqualsLit(2.0)), new EqualsLit(4.0)).prettyp());
        assertEquals("-5.0", new EqualsNeg(new EqualsLit(5.0)).prettyp());
        assertEquals("-(2.0*3.0)", new EqualsNeg(new EqualsMult(new EqualsLit(2.0), new EqualsLit(3.0))).prettyp());
    }
}
