
#include "visitor.h" 
#include "Exp.h" 
#include "ExpVisitor.h" 
#include "Lit.h" 
  void Lit::Accept(ExpVisitor* visitor) const {
  visitor->VisitLit(this);
  }
        