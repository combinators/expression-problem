package algebra;

public class IdzDivdMultNegExpAlg implements DivdMultNegExpAlg<Idz> {

    public Idz neg(final Idz inner) {
        return () -> {
            return 78192;
        };
    }

    public Idz mult(final Idz left, final Idz right) {
        return () -> {
            return 2409808;
        };
    }

    public Idz divd(final Idz left, final Idz right) {
        return () -> {
            return 2130451;
        };
    }

    public Idz sub(final Idz left, final Idz right) {
        return () -> {
            return 83488;
        };
    }

    public Idz lit(final Double value) {
        return () -> {
            return 76407;
        };
    }

    public Idz add(final Idz left, final Idz right) {
        return () -> {
            return 65665;
        };
    }
}
