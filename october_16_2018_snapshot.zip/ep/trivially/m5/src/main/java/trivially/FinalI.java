package trivially;

public interface FinalI extends ExpAstree {
}
