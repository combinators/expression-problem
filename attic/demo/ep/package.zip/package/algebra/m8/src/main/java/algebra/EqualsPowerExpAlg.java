package algebra;

public class EqualsPowerExpAlg extends EqualsSqrtExpAlg implements PowerExpAlg<Equals> {

    AstreePowerExpAlg asTree = new AstreePowerExpAlg();

    public Equals power(final Equals left, final Equals right) {
        return new Equals() {

            public tree.Tree astree() {
                return asTree.power(left, right).astree();
            }

            public Boolean equals(Equals that) {
                // was NAME
                return astree().same(that.astree());
            }
        };
    }
}
