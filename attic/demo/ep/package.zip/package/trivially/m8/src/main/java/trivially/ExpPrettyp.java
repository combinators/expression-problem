package trivially;

public interface ExpPrettyp extends ExpEval {

    public String prettyp();
}
