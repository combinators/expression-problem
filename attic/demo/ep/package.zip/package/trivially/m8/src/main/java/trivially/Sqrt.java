package trivially;

public class Sqrt implements FinalI, SqrtCopy {

    public Sqrt(FinalI inner) {
        this.inner = inner;
    }

    public FinalI getInner() {
        return this.inner;
    }

    private FinalI inner;
}
