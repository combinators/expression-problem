package trivially;

public interface SubFind extends ExpFind, SubEquals {

    ExpFind getLeft();

    ExpFind getRight();

    default Integer find(Double target) {
        return getLeft().find(target) + getRight().find(target);
    }
}
