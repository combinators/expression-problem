package trivially;

import junit.framework.TestCase;

public class TestSuite8 extends TestCase {

    public void test() {
        assertEquals(new Double(5.0), new Sqrt((FinalI) (new Lit(new Double(25.0)))).eval());
        assertEquals(new Integer(2), new Add((FinalI) (new Add((FinalI) (new Lit(new Double(1.0))), (FinalI) (new Lit(new Double(2.0))))), (FinalI) (new Add((FinalI) (new Lit(new Double(1.0))), (FinalI) (new Lit(new Double(2.0)))))).find(new Double(1.0)));
    }
}
