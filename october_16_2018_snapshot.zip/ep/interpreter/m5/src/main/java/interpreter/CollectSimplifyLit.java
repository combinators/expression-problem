package interpreter;

public class CollectSimplifyLit extends PrettypLit implements CollectSimplifyExp {

    CollectSimplifyExp Neg(CollectSimplifyExp inner) {
        return new CollectSimplifyNeg(inner);
    }

    CollectSimplifyExp Mult(CollectSimplifyExp left, CollectSimplifyExp right) {
        return new CollectSimplifyMult(left, right);
    }

    CollectSimplifyExp Divd(CollectSimplifyExp left, CollectSimplifyExp right) {
        return new CollectSimplifyDivd(left, right);
    }

    CollectSimplifyExp Sub(CollectSimplifyExp left, CollectSimplifyExp right) {
        return new CollectSimplifySub(left, right);
    }

    CollectSimplifyExp Lit(Double value) {
        return new CollectSimplifyLit(value);
    }

    CollectSimplifyExp Add(CollectSimplifyExp left, CollectSimplifyExp right) {
        return new CollectSimplifyAdd(left, right);
    }

    public CollectSimplifyLit(Double value) {
        super(value);
    }

    public Double getValue() {
        return this.value;
    }

    public CollectSimplifyExp simplify() {
        return Lit(getValue());
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> list = new java.util.ArrayList<Double>();
        list.add(getValue());
        return list;
    }
}
