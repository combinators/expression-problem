package interpreter;

public class EvalIdLit implements EvalIdExp {

    EvalIdExp Lit(Double value) {
        return new EvalIdLit(value);
    }

    EvalIdExp Add(EvalIdExp left, EvalIdExp right) {
        return new EvalIdAdd(left, right);
    }

    public EvalIdLit(Double value) {
        this.value = value;
    }

    public Double getValue() {
        return this.value;
    }

    Double value;

    public Double eval() {
        return getValue();
    }

    public Integer id() {
        return 76407;
    }
}
