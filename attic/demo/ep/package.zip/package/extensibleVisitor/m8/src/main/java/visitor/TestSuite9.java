package visitor;

import junit.framework.TestCase;

public class TestSuite9 extends TestCase {

    public void test() {
        assertEquals(new Double(36.0), new Power(new Lit(new Double(6.0)), new Lit(new Double(2.0))).accept(makeEval()));
        assertEquals("Power(25.0,-0.5)", new Power(new Lit(new Double(25.0)), new Lit(new Double(-0.5))).accept(makePrettyp()));
        assertEquals(new Double(1.0), new Power(new Lit(new Double(10.0)), new Lit(new Double(0.0))).accept(makeEval()));
        assertEquals("1.0", new Power(new Lit(new Double(10.0)), new Lit(new Double(0.0))).accept(makeSimplify()).accept(makePrettyp()));
        java.util.ArrayList<tree.Tree> list25 = new java.util.ArrayList<>();
        tree.Tree leaf27 = new tree.Leaf(2.0);
        list25.add(leaf27);
        java.util.ArrayList<tree.Tree> list28 = new java.util.ArrayList<>();
        tree.Tree leaf30 = new tree.Leaf(7.0);
        list28.add(leaf30);
        tree.Node node29 = new tree.Node(list28, 2584896);
        list25.add(node29);
        tree.Node node26 = new tree.Node(list25, 2409808);
        assertEquals(node26, new Mult(new Lit(new Double(2.0)), new Sqrt(new Lit(new Double(7.0)))).accept(makeCopy()).accept(makeAstree()));
    }

    CopyPower makeCopy() {
        return new CopyPower();
    }

    FindPower makeFind(Double target) {
        return new FindPower(target);
    }

    EqualsPower makeEquals(Exp that) {
        return new EqualsPower(that);
    }

    AstreePower makeAstree() {
        return new AstreePower();
    }

    IdzPower makeIdz() {
        return new IdzPower();
    }

    SimplifyPower makeSimplify() {
        return new SimplifyPower();
    }

    CollectPower makeCollect() {
        return new CollectPower();
    }

    PrettypPower makePrettyp() {
        return new PrettypPower();
    }

    EvalPower makeEval() {
        return new EvalPower();
    }
}
