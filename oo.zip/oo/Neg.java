package oo;

public class Neg extends Exp {

    public Neg(Exp inner) {
        this.inner = inner;
    }

    private Exp inner;

    public Exp simplify() {
        if (inner.eval() == 0) {
            return new Lit(0.0);
        } else {
            return new Neg(inner.simplify());
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> list = new java.util.ArrayList<Double>();
        list.addAll(inner.collect());
        return list;
    }

    public String print() {
        return "-" + inner.print();
    }

    public Double eval() {
        return -inner.eval();
    }
}
