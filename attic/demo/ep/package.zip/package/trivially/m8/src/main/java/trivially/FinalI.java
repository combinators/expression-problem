package trivially;

public interface FinalI extends ExpCopy {
}
