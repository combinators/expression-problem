package trivially;

public interface InvEval extends ExpEval {

    ExpEval getInner();

    default Double eval() {
        return 1 / getInner().eval();
    }
}
