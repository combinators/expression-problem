package trivially;

import junit.framework.TestCase;

public class TestSuite7 extends TestCase {

    public void test() {
        assertEquals("(1.0/(1.0-2.0))", new Inv(new Sub(new Lit(1.0), new Lit(2.0))).prettyp());
        assertEquals(new Divd(new Lit(1.0), new Sub(new Lit(1.0), new Lit(2.0))).prettyp(), new Inv(new Sub(new Lit(1.0), new Lit(2.0))).prettyp());
    }
}
