package trivially;

public interface LitPrettyp extends ExpPrettyp, LitEval {

    Double getValue();

    default String prettyp() {
        return "" + getValue();
    }
}
