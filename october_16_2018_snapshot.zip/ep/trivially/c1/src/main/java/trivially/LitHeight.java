package trivially;

public interface LitHeight extends ExpHeight, LitPrettyp {

    Double getValue();

    default Integer height(Integer height) {
        return height;
    }
}
