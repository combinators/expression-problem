package trivially;

public interface SubEquals extends ExpEquals, SubAstreeIdz {

    ExpEquals getLeft();

    ExpEquals getRight();

    default Boolean equals(ExpEquals that) {
        return this.astree().same(that.astree());
    }
}
