package trivially;

import junit.framework.TestCase;

public class TestSuite1 extends TestCase {

    public void test() {
        assertEquals(new Double(-1.0), new Sub((FinalI) (new Lit(new Double(1.0))), (FinalI) (new Lit(new Double(2.0)))).eval());
    }
}
