package visitor;

public interface Visitor<R> {

    public R visit(Lit exp);

    public R visit(Add exp);
}
