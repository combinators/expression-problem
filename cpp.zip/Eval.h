
#ifndef _Eval_
#define _Eval_

#include "ExpVisitor.h"
#include "visitor.h" 

class Eval : public ExpVisitor {
public:
    double getValue(const Exp& e) {
  return value_map_[&e];
  }
    void VisitNeg(const Neg* e) {
  value_map_[e] = - value_map_[e->getExp()];
  }
    void VisitMult(const Mult* e) {
  value_map_[e] = value_map_[e->getLeft()] * value_map_[e->getRight()];
  }
    void VisitDivd(const Divd* e) {
  value_map_[e] = value_map_[e->getLeft()] / value_map_[e->getRight()];
  }
    void VisitSub(const Sub* e) {
  value_map_[e] = value_map_[e->getLeft()] - value_map_[e->getRight()];
  }
    void VisitLit(const Lit* e) {
  value_map_[e] = *e->getValue();
  }
    void VisitAdd(const Add* e) {
  value_map_[e] = value_map_[e->getLeft()] + value_map_[e->getRight()];
  }

private:
  std::map<const Exp*, double  > value_map_;
};
#endif /* _Eval_ */
       