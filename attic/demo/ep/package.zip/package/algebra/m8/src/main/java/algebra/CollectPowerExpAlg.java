package algebra;

public class CollectPowerExpAlg extends CollectSqrtExpAlg implements PowerExpAlg<Collect> {

    public Collect power(final Collect left, final Collect right) {
        return () -> {
            java.util.List<Double> tmpList7 = new java.util.ArrayList<>();
            tmpList7.addAll(left.collect());
            tmpList7.addAll(right.collect());
            return tmpList7;
        };
    }
}
