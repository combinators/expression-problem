package trivially;

public interface FinalI extends ExpSimplify, ExpCollect {
}
