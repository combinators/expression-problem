package interpreter;

public class AstreeNeg extends CollectSimplifyNeg implements AstreeExp {

    AstreeExp Neg(AstreeExp inner) {
        return new AstreeNeg(inner);
    }

    AstreeExp Mult(AstreeExp left, AstreeExp right) {
        return new AstreeMult(left, right);
    }

    AstreeExp Divd(AstreeExp left, AstreeExp right) {
        return new AstreeDivd(left, right);
    }

    AstreeExp Sub(AstreeExp left, AstreeExp right) {
        return new AstreeSub(left, right);
    }

    AstreeExp Lit(Double value) {
        return new AstreeLit(value);
    }

    AstreeExp Add(AstreeExp left, AstreeExp right) {
        return new AstreeAdd(left, right);
    }

    public AstreeNeg(AstreeExp inner) {
        super(inner);
    }

    public AstreeExp getInner() {
        return (AstreeExp) this.inner;
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getInner().astree()), this.id());
    }
}
