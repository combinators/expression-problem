package algebra;

public class CollectDivdMultNegExpAlg implements DivdMultNegExpAlg<Collect> {

    public Collect neg(final Collect inner) {
        return () -> {
            java.util.List<Double> tmpList0 = new java.util.ArrayList<>();
            tmpList0.addAll(inner.collect());
            return tmpList0;
        };
    }

    public Collect mult(final Collect left, final Collect right) {
        return () -> {
            java.util.List<Double> tmpList1 = new java.util.ArrayList<>();
            tmpList1.addAll(left.collect());
            tmpList1.addAll(right.collect());
            return tmpList1;
        };
    }

    public Collect divd(final Collect left, final Collect right) {
        return () -> {
            java.util.List<Double> tmpList2 = new java.util.ArrayList<>();
            tmpList2.addAll(left.collect());
            tmpList2.addAll(right.collect());
            return tmpList2;
        };
    }

    public Collect sub(final Collect left, final Collect right) {
        return () -> {
            java.util.List<Double> tmpList3 = new java.util.ArrayList<>();
            tmpList3.addAll(left.collect());
            tmpList3.addAll(right.collect());
            return tmpList3;
        };
    }

    public Collect lit(final Double value) {
        return () -> {
            java.util.List<Double> tmpList4 = new java.util.ArrayList<>();
            tmpList4.add(value);
            return tmpList4;
        };
    }

    public Collect add(final Collect left, final Collect right) {
        return () -> {
            java.util.List<Double> tmpList5 = new java.util.ArrayList<>();
            tmpList5.addAll(left.collect());
            tmpList5.addAll(right.collect());
            return tmpList5;
        };
    }
}
