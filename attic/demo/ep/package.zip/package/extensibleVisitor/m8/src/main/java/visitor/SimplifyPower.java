package visitor;

public class SimplifyPower extends SimplifySqrt implements VisitorPower<Exp> {

    public Exp visit(Power e) {
        double leftVal = e.getLeft().accept(makeEval());
        double rightVal = e.getRight().accept(makeEval());
        if (leftVal == 0) {
            return new Lit(0.0);
        } else if (rightVal == 0) {
            return new Lit(1.0);
        } else if (rightVal == 1) {
            return e.getLeft().accept(makeSimplify());
        } else {
            return new Power(e.getLeft().accept(makeSimplify()), e.getRight().accept(makeSimplify()));
        }
    }

    SimplifyPower makeSimplify() {
        return new SimplifyPower();
    }
}
