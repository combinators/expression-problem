
#ifndef _PrettyP_
#define _PrettyP_

#include "ExpVisitor.h"
#include "visitor.h" 

class PrettyP : public ExpVisitor {
public:
    std::string getValue(const Exp& e) {
  return value_map_[&e];
  }
    void VisitNeg(const Neg* e) {
  value_map_[e] = "(" + value_map_[e->getExp()] + ")";
  }
    void VisitMult(const Mult* e) {
  value_map_[e] = "(" + value_map_[e->getLeft()] + "*" + value_map_[e->getRight()] + ")";
  }
    void VisitDivd(const Divd* e) {
  value_map_[e] = "(" + value_map_[e->getLeft()] + "/" + value_map_[e->getRight()] + ")";
  }
    void VisitSub(const Sub* e) {
  value_map_[e] = "(" + value_map_[e->getLeft()] + "-" + value_map_[e->getRight()] + ")";
  }
    void VisitLit(const Lit* e) {
  std::ostringstream ss;
  double val = *e->getValue();
  int ival = (int) val;
  ss << *e->getValue();
  if (val == ival) { ss << ".0"; }  // add trailing .0 for int-value doubles
  value_map_[e] = ss.str();
  }
    void VisitAdd(const Add* e) {
  value_map_[e] = "(" + value_map_[e->getLeft()] + "+" + value_map_[e->getRight()] + ")";
  }

private:
  std::map<const Exp*, std::string  > value_map_;
};
#endif /* _PrettyP_ */
       