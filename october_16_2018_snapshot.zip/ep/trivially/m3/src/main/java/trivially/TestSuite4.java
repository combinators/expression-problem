package trivially;

import junit.framework.TestCase;

public class TestSuite4 extends TestCase {

    public void test() {
        assertEquals("-1.0", new Neg(new Lit(1.0)).prettyp());
        assertEquals(-1.0, new Neg(new Lit(1.0)).eval());
        assertEquals("((5.0/2.0)*4.0)", new Mult(new Divd(new Lit(5.0), new Lit(2.0)), new Lit(4.0)).prettyp());
        assertEquals("-5.0", new Neg(new Lit(5.0)).prettyp());
        assertEquals("-(2.0*3.0)", new Neg(new Mult(new Lit(2.0), new Lit(3.0))).prettyp());
    }
}
