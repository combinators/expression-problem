package interpreter;

import junit.framework.TestCase;

public class TestSuite5 extends TestCase {

    public void test() {
        // Handle collect checks
        java.util.List<Double> list1 = new CollectSimplifyDivd(new CollectSimplifyDivd(new CollectSimplifyLit(5.0), new CollectSimplifyLit(7.0)), new CollectSimplifySub(new CollectSimplifyLit(7.0), new CollectSimplifyMult(new CollectSimplifyLit(2.0), new CollectSimplifyLit(3.0)))).collect();
        java.util.List<Double> result = new java.util.ArrayList<Double>();
        result.add(5.0);
        result.add(7.0);
        result.add(7.0);
        result.add(2.0);
        result.add(3.0);
        assertEquals(list1, result);
    }
}
