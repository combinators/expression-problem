package trivially;

public interface ExpCollectSimplify extends ExpPrettyp {

    public ExpCollectSimplify simplify();

    public java.util.List<Double> collect();
}
