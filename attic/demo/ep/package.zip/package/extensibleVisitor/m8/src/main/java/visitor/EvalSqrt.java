package visitor;

public class EvalSqrt extends EvalDivdMultNeg implements VisitorSqrt<Double> {

    public Double visit(Sqrt e) {
        return Math.sqrt(e.getInner().accept(makeEval()));
    }

    EvalSqrt makeEval() {
        return new EvalSqrt();
    }
}
