package visitor;

import junit.framework.TestCase;

public class TestSuite1 extends TestCase {

    public void test() {
        assertEquals(new Double(-1.0), new Sub(new Lit(new Double(1.0)), new Lit(new Double(2.0))).accept(makeEval()));
    }

    CopyPower makeCopy() {
        return new CopyPower();
    }

    FindPower makeFind(Double target) {
        return new FindPower(target);
    }

    EqualsPower makeEquals(Exp that) {
        return new EqualsPower(that);
    }

    AstreePower makeAstree() {
        return new AstreePower();
    }

    IdzPower makeIdz() {
        return new IdzPower();
    }

    SimplifyPower makeSimplify() {
        return new SimplifyPower();
    }

    CollectPower makeCollect() {
        return new CollectPower();
    }

    PrettypPower makePrettyp() {
        return new PrettypPower();
    }

    EvalPower makeEval() {
        return new EvalPower();
    }
}
