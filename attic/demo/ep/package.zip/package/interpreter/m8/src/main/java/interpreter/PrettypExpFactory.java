package interpreter;

public class PrettypExpFactory {

    public static PrettypExp Power(PrettypExp left, PrettypExp right) {
        return new PrettypPower(left, right);
    }

    public static PrettypExp Sqrt(PrettypExp inner) {
        return new PrettypSqrt(inner);
    }

    public static PrettypExp Neg(PrettypExp inner) {
        return new PrettypNeg(inner);
    }

    public static PrettypExp Mult(PrettypExp left, PrettypExp right) {
        return new PrettypMult(left, right);
    }

    public static PrettypExp Divd(PrettypExp left, PrettypExp right) {
        return new PrettypDivd(left, right);
    }

    public static PrettypExp Sub(PrettypExp left, PrettypExp right) {
        return new PrettypSub(left, right);
    }

    public static PrettypExp Lit(Double value) {
        return new PrettypLit(value);
    }

    public static PrettypExp Add(PrettypExp left, PrettypExp right) {
        return new PrettypAdd(left, right);
    }
}
