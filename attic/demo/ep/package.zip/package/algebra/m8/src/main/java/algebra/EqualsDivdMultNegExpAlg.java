package algebra;

public class EqualsDivdMultNegExpAlg implements DivdMultNegExpAlg<Equals> {

    AstreeDivdMultNegExpAlg asTree = new AstreeDivdMultNegExpAlg();

    public Equals neg(final Equals inner) {
        return new Equals() {

            public tree.Tree astree() {
                return asTree.neg(inner).astree();
            }

            public Boolean equals(Equals that) {
                // was NAME
                return astree().same(that.astree());
            }
        };
    }

    public Equals mult(final Equals left, final Equals right) {
        return new Equals() {

            public tree.Tree astree() {
                return asTree.mult(left, right).astree();
            }

            public Boolean equals(Equals that) {
                // was NAME
                return astree().same(that.astree());
            }
        };
    }

    public Equals divd(final Equals left, final Equals right) {
        return new Equals() {

            public tree.Tree astree() {
                return asTree.divd(left, right).astree();
            }

            public Boolean equals(Equals that) {
                // was NAME
                return astree().same(that.astree());
            }
        };
    }

    public Equals sub(final Equals left, final Equals right) {
        return new Equals() {

            public tree.Tree astree() {
                return asTree.sub(left, right).astree();
            }

            public Boolean equals(Equals that) {
                // was NAME
                return astree().same(that.astree());
            }
        };
    }

    public Equals lit(final Double value) {
        return new Equals() {

            public tree.Tree astree() {
                return asTree.lit(value).astree();
            }

            public Boolean equals(Equals that) {
                // was NAME
                return astree().same(that.astree());
            }
        };
    }

    public Equals add(final Equals left, final Equals right) {
        return new Equals() {

            public tree.Tree astree() {
                return asTree.add(left, right).astree();
            }

            public Boolean equals(Equals that) {
                // was NAME
                return astree().same(that.astree());
            }
        };
    }
}
