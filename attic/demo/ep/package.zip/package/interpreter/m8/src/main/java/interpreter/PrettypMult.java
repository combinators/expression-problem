package interpreter;

public class PrettypMult extends EvalMult implements PrettypExp {

    public PrettypMult(PrettypExp left, PrettypExp right) {
        super(left, right);
    }

    public PrettypExp getLeft() {
        return (PrettypExp) this.left;
    }

    public PrettypExp getRight() {
        return (PrettypExp) this.right;
    }

    public Double eval() {
        return getLeft().eval() * getRight().eval();
    }

    public String prettyp() {
        return "(" + getLeft().prettyp() + "*" + getRight().prettyp() + ")";
    }
}
