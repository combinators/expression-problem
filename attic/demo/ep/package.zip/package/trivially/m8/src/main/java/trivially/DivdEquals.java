package trivially;

public interface DivdEquals extends ExpEquals, DivdAstreeIdz {

    ExpEquals getLeft();

    ExpEquals getRight();

    default Boolean equals(ExpEquals that) {
        return this.astree().same(that.astree());
    }
}
