package expression;

public class Prettyp implements VisitorSub<String> {

    public String visit(Sub e) {
        return "(" + e.getLeft().accept(makePrettyp()) + "-" + e.getRight().accept(makePrettyp()) + ")";
    }

    public String visit(Lit e) {
        return "" + e.getValue() + "";
    }

    public String visit(Add e) {
        return "(" + e.getLeft().accept(makePrettyp()) + "+" + e.getRight().accept(makePrettyp()) + ")";
    }

    Prettyp makePrettyp() {
        return new Prettyp();
    }
}
