package algebra;

public class EvalSubExpAlg extends EvalAddLitExpAlg implements SubExpAlg<Eval> {

    public Eval sub(final Eval left, final Eval right) {
        return new Eval() {

            public Double eval() {
                return left.eval() - right.eval();
            }
        };
    }
}
