package trivially;

public interface MultEquals extends ExpEquals, MultAstree {

    ExpEquals getLeft();

    ExpEquals getRight();

    default Boolean equals(Exp that) {
        return astree().same(that.astree());
    }
}
