package trivially;

public interface AddPrettyp extends ExpPrettyp, AddEval {

    ExpPrettyp getLeft();

    ExpPrettyp getRight();

    default String prettyp() {
        return "(" + getLeft().prettyp() + "+" + getRight().prettyp() + ")";
    }
}
