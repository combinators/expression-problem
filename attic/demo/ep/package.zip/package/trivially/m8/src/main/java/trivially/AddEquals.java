package trivially;

public interface AddEquals extends ExpEquals, AddAstreeIdz {

    ExpEquals getLeft();

    ExpEquals getRight();

    default Boolean equals(ExpEquals that) {
        return this.astree().same(that.astree());
    }
}
