package interpreter;

public interface EqualsExp extends AstreeIdzExp {

    public Boolean equals(EqualsExp that);
}
