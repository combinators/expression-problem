package interpreter;

import junit.framework.TestCase;

public class TestSuite3 extends TestCase {

    public void test() {
        assertEquals("(1.0-2.0)", new AstreeSub(new AstreeLit(1.0), new AstreeLit(2.0)).prettyp());
        assertEquals("((1.0-2.0)+(5.0+6.0))", new AstreeAdd(new AstreeSub(new AstreeLit(1.0), new AstreeLit(2.0)), new AstreeAdd(new AstreeLit(5.0), new AstreeLit(6.0))).prettyp());
    }
}
