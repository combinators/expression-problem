package trivially;

public interface SubAstree extends ExpAstree, SubSimplify, SubCollect {

    ExpAstree getLeft();

    ExpAstree getRight();

    default tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getLeft().astree(), getRight().astree()), this.id());
    }
}
