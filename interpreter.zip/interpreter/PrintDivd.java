package interpreter;

public class PrintDivd implements PrintExp {

    PrintExp Neg(PrintExp inner) {
        return new PrintNeg(inner);
    }

    PrintExp Mult(PrintExp left, PrintExp right) {
        return new PrintMult(left, right);
    }

    PrintExp Divd(PrintExp left, PrintExp right) {
        return new PrintDivd(left, right);
    }

    public PrintDivd(PrintExp left, PrintExp right) {
        this.left = left;
        this.right = right;
    }

    public PrintExp getLeft() {
        return this.left;
    }

    public PrintExp getRight() {
        return this.right;
    }

    PrintExp left;

    PrintExp right;

    public Double eval() {
        return getLeft().eval() / getRight().eval();
    }

    public String print() {
        return "(" + getLeft().print() + "/" + getRight().print() + ")";
    }
}
