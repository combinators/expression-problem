package algebra;

public class PrintDivdMultNegExpAlg extends PrintSubExpAlg implements DivdMultNegExpAlg<Print> {

    public Print neg(final Print inner) {
        return new Print() {

            public String print() {
                return "-" + inner.print();
            }
        };
    }

    public Print mult(final Print left, final Print right) {
        return new Print() {

            public String print() {
                return "(" + left.print() + "*" + right.print() + ")";
            }
        };
    }

    public Print divd(final Print left, final Print right) {
        return new Print() {

            public String print() {
                return "(" + left.print() + "/" + right.print() + ")";
            }
        };
    }
}
