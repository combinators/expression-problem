package interpreter;

public interface AstreeExp extends CollectSimplifyExp {

    public tree.Tree astree();
}
