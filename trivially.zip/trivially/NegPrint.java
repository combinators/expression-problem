package trivially;

public interface NegPrint extends ExpPrint, NegEval {

    ExpPrint getInner();

    default String print() {
        return "-" + getInner().print();
    }
}
