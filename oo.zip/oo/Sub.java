package oo;

public class Sub extends Exp {

    public Sub(Exp left, Exp right) {
        this.left = left;
        this.right = right;
    }

    private Exp left;

    private Exp right;

    public Exp simplify() {
        if (left.eval() == right.eval()) {
            return new Lit(0.0);
        } else {
            return new Sub(left.simplify(), right.simplify());
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> list = left.collect();
        list.addAll(right.collect());
        return list;
    }

    public String print() {
        return "(" + left.print() + "-" + right.print() + ")";
    }

    public Double eval() {
        return left.eval() - right.eval();
    }
}
