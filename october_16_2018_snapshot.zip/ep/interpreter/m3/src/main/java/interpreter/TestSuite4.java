package interpreter;

import junit.framework.TestCase;

public class TestSuite4 extends TestCase {

    public void test() {
        assertEquals("-1.0", new PrettypNeg(new PrettypLit(1.0)).prettyp());
        assertEquals(-1.0, new PrettypNeg(new PrettypLit(1.0)).eval());
        assertEquals("((5.0/2.0)*4.0)", new PrettypMult(new PrettypDivd(new PrettypLit(5.0), new PrettypLit(2.0)), new PrettypLit(4.0)).prettyp());
        assertEquals("-5.0", new PrettypNeg(new PrettypLit(5.0)).prettyp());
        assertEquals("-(2.0*3.0)", new PrettypNeg(new PrettypMult(new PrettypLit(2.0), new PrettypLit(3.0))).prettyp());
    }
}
