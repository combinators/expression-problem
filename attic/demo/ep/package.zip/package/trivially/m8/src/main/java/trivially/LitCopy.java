package trivially;

public interface LitCopy extends ExpCopy, LitFind {

    Double getValue();

    default ExpCopy copy() {
        return new Lit(getValue());
    }
}
