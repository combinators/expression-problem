package visitor;

public class Simplify extends Visitor<Exp> {

    public Exp visit(Power e) {
        double leftVal = e.getLeft().accept(new Eval());
        double rightVal = e.getRight().accept(new Eval());
        if (leftVal == 0) {
            return new Lit(0.0);
        } else if (rightVal == 0) {
            return new Lit(1.0);
        } else if (rightVal == 1) {
            return e.getLeft().accept(new Simplify());
        } else {
            return new Power(e.getLeft().accept(new Simplify()), e.getRight().accept(new Simplify()));
        }
    }

    public Exp visit(Sqrt e) {
        return new Sqrt(e.getInner().accept(new Simplify()));
    }

    public Exp visit(Neg e) {
        if (e.getInner().accept(new Eval()) == 0) {
            return new Lit(0.0);
        } else {
            return new Neg(e.getInner().accept(new Simplify()));
        }
    }

    public Exp visit(Mult e) {
        double leftVal = e.getLeft().accept(new Eval());
        double rightVal = e.getRight().accept(new Eval());
        if (leftVal == 0 || rightVal == 0) {
            return new Lit(0.0);
        } else if (leftVal == 1) {
            return e.getRight().accept(new Simplify());
        } else if (rightVal == 1) {
            return e.getLeft().accept(new Simplify());
        } else {
            return new Mult(e.getLeft().accept(new Simplify()), e.getRight().accept(new Simplify()));
        }
    }

    public Exp visit(Divd e) {
        double leftVal = e.getLeft().accept(new Eval());
        double rightVal = e.getRight().accept(new Eval());
        if (leftVal == 0) {
            return new Lit(0.0);
        } else if (rightVal == 1) {
            return e.getLeft().accept(new Simplify());
        } else if (leftVal == rightVal) {
            return new Lit(1.0);
        } else if (leftVal == -rightVal) {
            return new Lit(-1.0);
        } else {
            return new Divd(e.getLeft().accept(new Simplify()), e.getRight().accept(new Simplify()));
        }
    }

    public Exp visit(Sub e) {
        if (e.getLeft().accept(new Eval()) == e.getRight().accept(new Eval())) {
            return new Lit(0.0);
        } else {
            return new Sub(e.getLeft().accept(new Simplify()), e.getRight().accept(new Simplify()));
        }
    }

    public Exp visit(Lit e) {
        return new Lit(e.getValue());
    }

    public Exp visit(Add e) {
        double leftVal = e.getLeft().accept(new Eval());
        double rightVal = e.getRight().accept(new Eval());
        if ((leftVal == 0 && rightVal == 0) || (leftVal + rightVal == 0)) {
            return new Lit(0.0);
        } else if (leftVal == 0) {
            return e.getRight().accept(new Simplify());
        } else if (rightVal == 0) {
            return e.getLeft().accept(new Simplify());
        } else {
            return new Add(e.getLeft().accept(new Simplify()), e.getRight().accept(new Simplify()));
        }
    }
}
