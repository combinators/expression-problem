package trivially;

public class Neg implements FinalI, NegCopy {

    public Neg(FinalI inner) {
        this.inner = inner;
    }

    public FinalI getInner() {
        return this.inner;
    }

    private FinalI inner;
}
