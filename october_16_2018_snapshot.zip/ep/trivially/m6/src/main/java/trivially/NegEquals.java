package trivially;

public interface NegEquals extends ExpEquals, NegAstree {

    ExpEquals getInner();

    default Boolean equals(Exp that) {
        return astree().same(that.astree());
    }
}
