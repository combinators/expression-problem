package algebra;

public class CopyPowerExpAlg implements PowerExpAlg<Copy> {

    // Binary operations are passed in necessary algebra to work with
    CombinedExpAlg algebra;

    public CopyPowerExpAlg(CombinedExpAlg alg) {
        this.algebra = alg;
    }

    public Copy power(final Copy left, final Copy right) {
        return () -> {
            return algebra.power(left.copy(), right.copy());
        };
    }

    public Copy sqrt(final Copy inner) {
        return () -> {
            return algebra.sqrt(inner.copy());
        };
    }

    public Copy neg(final Copy inner) {
        return () -> {
            return algebra.neg(inner.copy());
        };
    }

    public Copy mult(final Copy left, final Copy right) {
        return () -> {
            return algebra.mult(left.copy(), right.copy());
        };
    }

    public Copy divd(final Copy left, final Copy right) {
        return () -> {
            return algebra.divd(left.copy(), right.copy());
        };
    }

    public Copy sub(final Copy left, final Copy right) {
        return () -> {
            return algebra.sub(left.copy(), right.copy());
        };
    }

    public Copy lit(final Double value) {
        return () -> {
            return algebra.lit(value);
        };
    }

    public Copy add(final Copy left, final Copy right) {
        return () -> {
            return algebra.add(left.copy(), right.copy());
        };
    }
}
