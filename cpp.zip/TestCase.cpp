

#include "CppUTest/TestHarness.h"
#include "CppUTest/SimpleString.h"
#include "CppUTest/PlatformSpecificFunctions.h"
#include "CppUTest/TestMemoryAllocator.h"
#include "CppUTest/MemoryLeakDetector.h"
#include "CppUTest/CommandLineTestRunner.h"

#include "Exp.h"
#include "ExpVisitor.h"
#include "PrettyP.h" 
#include "Eval.h" 
                 
TEST_GROUP(FirstTestGroup)
{
};
                                         

 TEST(FirstTestGroup, add3)
      {
        

double val1 = 1.0;
Lit  lit1 = Lit(&val1);
         

double val2 = 2.0;
Lit  lit2 = Lit(&val2);
         
Add  add3 = Add(&lit1, &lit2);
       
          Eval e4;
  add3.Accept(&e4);
  DOUBLES_EQUAL(3.0, e4.getValue(add3), 0.0);
          
  Eval e4;
  add3.Accept(&e4);
  DOUBLES_EQUAL(3.0, e4.getValue(add3), 0.0);
          
  Eval e4;
  add3.Accept(&e4);
  DOUBLES_EQUAL(3.0, e4.getValue(add3), 0.0);
          
      }
         

 TEST(FirstTestGroup, sub6)
      {
        

double val4 = 1.0;
Lit  lit4 = Lit(&val4);
         

double val5 = 2.0;
Lit  lit5 = Lit(&val5);
         
Sub  sub6 = Sub(&lit4, &lit5);
       
          Eval e4;
  sub6.Accept(&e4);
  DOUBLES_EQUAL(-1.0, e4.getValue(sub6), 0.0);
          
  Eval e4;
  sub6.Accept(&e4);
  DOUBLES_EQUAL(-1.0, e4.getValue(sub6), 0.0);
          
  Eval e4;
  sub6.Accept(&e4);
  DOUBLES_EQUAL(-1.0, e4.getValue(sub6), 0.0);
          
      }
         

 TEST(FirstTestGroup, add13)
      {
        


double val7 = 1.0;
Lit  lit7 = Lit(&val7);
         

double val8 = 2.0;
Lit  lit8 = Lit(&val8);
         
Sub  sub9 = Sub(&lit7, &lit8);
       


double val10 = 8.0;
Lit  lit10 = Lit(&val10);
         

double val11 = 2.0;
Lit  lit11 = Lit(&val11);
         
Add  add12 = Add(&lit10, &lit11);
       
Add  add13 = Add(&sub9, &add12);
       
          Eval e4;
  add13.Accept(&e4);
  DOUBLES_EQUAL(9.0, e4.getValue(add13), 0.0);
          
  PrettyP pp;
  add13.Accept(&pp);
  STRCMP_EQUAL("((1.0-2.0)+(8.0+2.0))", pp.getValue(add13).c_str());
  Eval e4;
  add13.Accept(&e4);
  DOUBLES_EQUAL(9.0, e4.getValue(add13), 0.0);
          
  PrettyP pp;
  add13.Accept(&pp);
  STRCMP_EQUAL("((1.0-2.0)+(8.0+2.0))", pp.getValue(add13).c_str());
      }
         

 TEST(FirstTestGroup, add21)
      {
        


double val14 = 5.0;
Lit  lit14 = Lit(&val14);
         

double val15 = 7.0;
Lit  lit15 = Lit(&val15);
         
Mult  mult16 = Mult(&lit14, &lit15);
       


double val17 = 18.0;
Lit  lit17 = Lit(&val17);
         
Neg  neg19 = Neg(&lit18);
Divd  divd20 = Divd(&lit17, &neg19);
       
Add  add21 = Add(&mult16, &divd20);
       
          Eval e4;
  add21.Accept(&e4);
  DOUBLES_EQUAL(33.0, e4.getValue(add21), 0.0);
          
  PrettyP pp;
  add21.Accept(&pp);
  STRCMP_EQUAL("((5.0*7.0)+(18.0/-9.0))", pp.getValue(add21).c_str());
  Eval e4;
  add21.Accept(&e4);
  DOUBLES_EQUAL(33.0, e4.getValue(add21), 0.0);
          
  PrettyP pp;
  add21.Accept(&pp);
  STRCMP_EQUAL("((5.0*7.0)+(18.0/-9.0))", pp.getValue(add21).c_str());
      }
         

int main(int ac, char** av)
{
  return CommandLineTestRunner::RunAllTests(ac, av);
}

       
        