package interpreter;

public class PrettypMult implements PrettypExp {

    PrettypExp Neg(PrettypExp inner) {
        return new PrettypNeg(inner);
    }

    PrettypExp Mult(PrettypExp left, PrettypExp right) {
        return new PrettypMult(left, right);
    }

    PrettypExp Divd(PrettypExp left, PrettypExp right) {
        return new PrettypDivd(left, right);
    }

    public PrettypMult(PrettypExp left, PrettypExp right) {
        this.left = left;
        this.right = right;
    }

    public PrettypExp getLeft() {
        return this.left;
    }

    public PrettypExp getRight() {
        return this.right;
    }

    PrettypExp left;

    PrettypExp right;

    public Double eval() {
        return getLeft().eval() * getRight().eval();
    }

    public Integer id() {
        return 2409808;
    }

    public String prettyp() {
        return "(" + getLeft().prettyp() + "*" + getRight().prettyp() + ")";
    }
}
