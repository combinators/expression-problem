package interpreter;

public class EvalSub implements EvalExp {

    EvalExp Sub(EvalExp left, EvalExp right) {
        return new EvalSub(left, right);
    }

    public EvalSub(EvalExp left, EvalExp right) {
        this.left = left;
        this.right = right;
    }

    public EvalExp getLeft() {
        return this.left;
    }

    public EvalExp getRight() {
        return this.right;
    }

    EvalExp left;

    EvalExp right;

    public Double eval() {
        return getLeft().eval() - getRight().eval();
    }
}
