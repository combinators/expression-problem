package trivially;

public interface LitEquals extends ExpEquals, LitAstreeIdz {

    Double getValue();

    default Boolean equals(ExpEquals that) {
        return this.astree().same(that.astree());
    }
}
