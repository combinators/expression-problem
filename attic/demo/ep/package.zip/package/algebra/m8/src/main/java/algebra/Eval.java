package algebra;

interface Eval {

    Double eval();
}
