package interpreter;

public interface CopyExp extends FindExp {

    // All known data types up until this evolution.s
    interface KnownDataTypes<R> extends CollectSimplifyExp.KnownDataTypes<R> {

        R convert(CollectSimplifyPower from);

        R convert(CollectSimplifySqrt from);
    }

    public CopyExp copy();
}
