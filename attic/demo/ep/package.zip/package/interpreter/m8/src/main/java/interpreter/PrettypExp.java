package interpreter;

public interface PrettypExp extends EvalExp {

    public String prettyp();
}
