package trivially;

public interface AddFind extends ExpFind, AddEquals {

    ExpFind getLeft();

    ExpFind getRight();

    default Integer find(Double target) {
        return getLeft().find(target) + getRight().find(target);
    }
}
