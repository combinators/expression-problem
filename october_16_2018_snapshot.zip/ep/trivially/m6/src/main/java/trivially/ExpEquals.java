package trivially;

public interface ExpEquals extends ExpAstree {

    public Boolean equals(Exp that);
}
