package trivially;

public interface InvHeight extends ExpHeight, InvPrettyp {

    ExpHeight getInner();

    default Integer height(Integer height) {
        return getInner().height(height + 1);
    }
}
