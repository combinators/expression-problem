package oo;

public class Divd extends Exp {

    public Divd(Exp left, Exp right) {
        this.left = left;
        this.right = right;
    }

    private Exp left;

    private Exp right;

    public Exp simplify() {
        double leftVal = left.eval();
        double rightVal = right.eval();
        if (leftVal == 0) {
            return new Lit(0.0);
        } else if (rightVal == 1) {
            return left.simplify();
        } else if (leftVal == rightVal) {
            return new Lit(1.0);
        } else if (leftVal == -rightVal) {
            return new Lit(-1.0);
        } else {
            return new Divd(left.simplify(), right.simplify());
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> list = left.collect();
        list.addAll(right.collect());
        return list;
    }

    public String print() {
        return "(" + left.print() + "/" + right.print() + ")";
    }

    public Double eval() {
        return left.eval() / right.eval();
    }
}
