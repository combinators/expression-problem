package interpreter;

public class EqualsExpFactory {

    public static EqualsExp Power(EqualsExp left, EqualsExp right) {
        return new EqualsPower(left, right);
    }

    public static EqualsExp Sqrt(EqualsExp inner) {
        return new EqualsSqrt(inner);
    }

    public static EqualsExp Neg(EqualsExp inner) {
        return new EqualsNeg(inner);
    }

    public static EqualsExp Mult(EqualsExp left, EqualsExp right) {
        return new EqualsMult(left, right);
    }

    public static EqualsExp Divd(EqualsExp left, EqualsExp right) {
        return new EqualsDivd(left, right);
    }

    public static EqualsExp Sub(EqualsExp left, EqualsExp right) {
        return new EqualsSub(left, right);
    }

    public static EqualsExp Lit(Double value) {
        return new EqualsLit(value);
    }

    public static EqualsExp Add(EqualsExp left, EqualsExp right) {
        return new EqualsAdd(left, right);
    }
}
