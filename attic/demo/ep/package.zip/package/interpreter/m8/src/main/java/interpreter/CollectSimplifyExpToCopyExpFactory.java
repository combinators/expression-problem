package interpreter;

public class CollectSimplifyExpToCopyExpFactory implements CopyExp.KnownDataTypes<CopyExp> {

    @Override
    public CopyPower convert(CollectSimplifyPower from) {
        return new CopyPower(from.getLeft().accept(this), from.getRight().accept(this));
    }

    @Override
    public CopySqrt convert(CollectSimplifySqrt from) {
        return new CopySqrt(from.getInner().accept(this));
    }

    @Override
    public CopyNeg convert(CollectSimplifyNeg from) {
        return new CopyNeg(from.getInner().accept(this));
    }

    @Override
    public CopyMult convert(CollectSimplifyMult from) {
        return new CopyMult(from.getLeft().accept(this), from.getRight().accept(this));
    }

    @Override
    public CopyDivd convert(CollectSimplifyDivd from) {
        return new CopyDivd(from.getLeft().accept(this), from.getRight().accept(this));
    }

    @Override
    public CopySub convert(CollectSimplifySub from) {
        return new CopySub(from.getLeft().accept(this), from.getRight().accept(this));
    }

    @Override
    public CopyLit convert(CollectSimplifyLit from) {
        return new CopyLit(from.getValue());
    }

    @Override
    public CopyAdd convert(CollectSimplifyAdd from) {
        return new CopyAdd(from.getLeft().accept(this), from.getRight().accept(this));
    }
}
