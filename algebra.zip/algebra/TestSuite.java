package algebra;

import junit.framework.TestCase;

public class TestSuite extends TestCase {

    CollectDivdMultNegExpAlg algebraCollect = new CollectDivdMultNegExpAlg();

    EvalDivdMultNegExpAlg algebraEval = new EvalDivdMultNegExpAlg();

    PrintDivdMultNegExpAlg algebraPrint = new PrintDivdMultNegExpAlg();

    SimplifyDivdMultNegExpAlg algebraSimplify = new SimplifyDivdMultNegExpAlg();

    CombinedExpAlg algebra = new CombinedExpAlg(algebraCollect, algebraEval, algebraPrint, algebraSimplify);

    public void test1() {
        assertEquals(3.0, algebra.add(algebra.lit(1.0), algebra.lit(2.0)).eval());
        assertEquals(5.0, algebra.lit(5.0).eval());
    }

    public void test2() {
        assertEquals(-1.0, algebra.sub(algebra.lit(1.0), algebra.lit(2.0)).eval());
    }

    public void test3() {
        assertEquals("(1.0-2.0)", algebra.sub(algebra.lit(1.0), algebra.lit(2.0)).print());
        assertEquals("((1.0-2.0)+(5.0+6.0))", algebra.add(algebra.sub(algebra.lit(1.0), algebra.lit(2.0)), algebra.add(algebra.lit(5.0), algebra.lit(6.0))).print());
    }

    public void test4() {
        assertEquals("-1.0", algebra.neg(algebra.lit(1.0)).print());
        assertEquals(-1.0, algebra.neg(algebra.lit(1.0)).eval());
        assertEquals("((5.0/2.0)*4.0)", algebra.mult(algebra.divd(algebra.lit(5.0), algebra.lit(2.0)), algebra.lit(4.0)).print());
        assertEquals("-5.0", algebra.neg(algebra.lit(5.0)).print());
        assertEquals("-(2.0*3.0)", algebra.neg(algebra.mult(algebra.lit(2.0), algebra.lit(3.0))).print());
    }

    public void test5() {
        // Handle collect checks
        java.util.List<Double> list1 = algebra.divd(algebra.divd(algebra.lit(5.0), algebra.lit(7.0)), algebra.sub(algebra.lit(7.0), algebra.mult(algebra.lit(2.0), algebra.lit(3.0)))).collect();
        java.util.List<Double> result = new java.util.ArrayList<Double>();
        result.add(5.0);
        result.add(7.0);
        result.add(7.0);
        result.add(2.0);
        result.add(3.0);
        assertEquals(list1, result);
    }
}
