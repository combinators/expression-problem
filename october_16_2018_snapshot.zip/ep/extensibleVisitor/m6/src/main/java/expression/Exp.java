package expression;

public abstract class Exp {

    public abstract tree.Tree astree();

    public abstract <R> R accept(Visitor<R> v);
}
