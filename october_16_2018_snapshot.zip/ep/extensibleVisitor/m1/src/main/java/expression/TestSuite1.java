package expression;

import junit.framework.TestCase;

public class TestSuite1 extends TestCase {

    public void test() {
        assertEquals(3.0, new Add(new Lit(1.0), new Lit(2.0)).accept(makeEval()));
        assertEquals(5.0, new Lit(5.0).accept(makeEval()));
    }

    Eval makeEval() {
        return new EvalSub();
    }

    Id makeId() {
        return new IdSub();
    }
}
