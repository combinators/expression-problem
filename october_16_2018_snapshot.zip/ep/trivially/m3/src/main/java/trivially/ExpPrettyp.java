package trivially;

public interface ExpPrettyp extends ExpEval, ExpId {

    public String prettyp();
}
