package trivially;

public interface DivdId extends ExpId {

    ExpId getLeft();

    ExpId getRight();

    default Integer id() {
        return 2130451;
    }
}
