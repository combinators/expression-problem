package interpreter;

public interface PrintExp extends EvalExp {

    public String print();
}
