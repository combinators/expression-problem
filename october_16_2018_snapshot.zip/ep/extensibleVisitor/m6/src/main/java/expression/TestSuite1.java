package expression;

import junit.framework.TestCase;

public class TestSuite1 extends TestCase {

    public void test() {
        assertEquals(3.0, new Add(new Lit(1.0), new Lit(2.0)).accept(makeEval()));
        assertEquals(5.0, new Lit(5.0).accept(makeEval()));
    }

    Equals makeEquals(Exp that) {
        return new Equals(that);
    }

    Astree makeAstree() {
        return new Astree();
    }

    Simplify makeSimplify() {
        return new Simplify();
    }

    Collect makeCollect() {
        return new Collect();
    }

    Prettyp makePrettyp() {
        return new PrettypDivdMultNeg();
    }

    Eval makeEval() {
        return new EvalDivdMultNeg();
    }

    Id makeId() {
        return new IdDivdMultNeg();
    }
}
