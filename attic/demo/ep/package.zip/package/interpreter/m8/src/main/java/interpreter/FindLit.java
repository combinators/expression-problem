package interpreter;

public class FindLit extends EqualsLit implements FindExp {

    public FindLit(Double value) {
        super(value);
    }

    public Double getValue() {
        return this.value;
    }

    public Integer find(Double target) {
        double _litEval = getValue();
        if (_litEval == target) {
            return 1;
        } else {
            return 0;
        }
    }
}
