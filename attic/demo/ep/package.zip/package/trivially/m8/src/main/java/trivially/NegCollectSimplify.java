package trivially;

public interface NegCollectSimplify extends ExpCollectSimplify, NegPrettyp {

    ExpCollectSimplify getInner();

    default ExpCollectSimplify simplify() {
        if (getInner().eval() == 0) {
            return new Lit(0.0);
        } else {
            return new Neg((FinalI) (getInner().simplify()));
        }
    }

    default java.util.List<Double> collect() {
        java.util.List<Double> tmpList2 = new java.util.ArrayList<>();
        tmpList2.addAll(getInner().collect());
        return tmpList2;
    }
}
