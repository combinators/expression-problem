package interpreter;

import static interpreter.CopyExpFactory.*;

public class CopyNeg extends FindNeg implements CopyExp {

    public CopyNeg(CopyExp inner) {
        super(inner);
    }

    public CopyExp getInner() {
        return (CopyExp) this.inner;
    }

    public CopyExp copy() {
        return Neg(getInner().copy());
    }
}
