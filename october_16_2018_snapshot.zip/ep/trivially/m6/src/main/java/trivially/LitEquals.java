package trivially;

public interface LitEquals extends ExpEquals, LitAstree {

    Double getValue();

    default Boolean equals(Exp that) {
        return astree().same(that.astree());
    }
}
