package trivially;

public interface NegAstree extends ExpAstree, NegSimplify, NegCollect {

    ExpAstree getInner();

    default tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getInner().astree()), this.id());
    }
}
