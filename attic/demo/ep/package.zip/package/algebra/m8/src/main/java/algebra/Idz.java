package algebra;

interface Idz {

    Integer idz();
}
