package trivially;

public interface MultAstreeIdz extends ExpAstreeIdz, MultCollectSimplify {

    ExpAstreeIdz getLeft();

    ExpAstreeIdz getRight();

    default tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getLeft().astree(), getRight().astree()), this.idz());
    }

    default Integer idz() {
        return 2409808;
    }
}
