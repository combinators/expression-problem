package trivially;

public interface SqrtPrettyp extends ExpPrettyp, SqrtEval {

    ExpPrettyp getInner();

    default String prettyp() {
        return "Sqrt(" + getInner().prettyp() + ")";
    }
}
