package interpreter;

import junit.framework.TestCase;
import static interpreter.CopyExpFactory.*;

public class TestSuite8 extends TestCase {

    public void test() {
        assertEquals(new Double(5.0), Sqrt(Lit(new Double(25.0))).eval());
        assertEquals(new Integer(2), Add(Add(Lit(new Double(1.0)), Lit(new Double(2.0))), Add(Lit(new Double(1.0)), Lit(new Double(2.0)))).find(new Double(1.0)));
    }
}
