package interpreter;

import junit.framework.TestCase;

public class TestSuite5 extends TestCase {

    public void test() {
        // Handle collect checks
        java.util.List<Double> list1 = new AstreeDivd(new AstreeDivd(new AstreeLit(5.0), new AstreeLit(7.0)), new AstreeSub(new AstreeLit(7.0), new AstreeMult(new AstreeLit(2.0), new AstreeLit(3.0)))).collect();
        java.util.List<Double> result = new java.util.ArrayList<Double>();
        result.add(5.0);
        result.add(7.0);
        result.add(7.0);
        result.add(2.0);
        result.add(3.0);
        assertEquals(list1, result);
    }
}
