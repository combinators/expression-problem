package interpreter;

public class PrettypLit extends EvalIdLit implements PrettypExp {

    PrettypExp Sub(PrettypExp left, PrettypExp right) {
        return new PrettypSub(left, right);
    }

    PrettypExp Lit(Double value) {
        return new PrettypLit(value);
    }

    PrettypExp Add(PrettypExp left, PrettypExp right) {
        return new PrettypAdd(left, right);
    }

    public PrettypLit(Double value) {
        super(value);
    }

    public Double getValue() {
        return this.value;
    }

    public String prettyp() {
        return "" + getValue() + "";
    }
}
