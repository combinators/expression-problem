package trivially;

public interface MultHeight extends ExpHeight, MultPrettyp {

    ExpHeight getLeft();

    ExpHeight getRight();

    default Integer height(Integer height) {
        return Math.max(getLeft().height(height + 1), getRight().height(height + 1));
    }
}
