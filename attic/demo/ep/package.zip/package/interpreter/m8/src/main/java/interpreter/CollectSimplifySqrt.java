package interpreter;

import static interpreter.CollectSimplifyExpFactory.*;

public class CollectSimplifySqrt extends PrettypSqrt implements CollectSimplifyExp {

    public CollectSimplifySqrt(CollectSimplifyExp inner) {
        super(inner);
    }

    public CollectSimplifyExp getInner() {
        return (CollectSimplifyExp) this.inner;
    }

    public String prettyp() {
        return "Sqrt(" + getInner().prettyp() + ")";
    }

    public Double eval() {
        return Math.sqrt(getInner().eval());
    }

    public CollectSimplifyExp simplify() {
        return Sqrt(getInner().simplify());
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList1 = new java.util.ArrayList<>();
        tmpList1.addAll(getInner().collect());
        return tmpList1;
    }

    @Override
    public <R> R accept(KnownDataTypes<R> from) {
        if (from instanceof FindExp.KnownDataTypes) {
            return ((FindExp.KnownDataTypes<R>) from).convert(this);
        }
        throw new IllegalArgumentException("unknown conversion.");
    }
}
