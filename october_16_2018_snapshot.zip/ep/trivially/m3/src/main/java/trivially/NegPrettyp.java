package trivially;

public interface NegPrettyp extends ExpPrettyp, NegEval, NegId {

    ExpPrettyp getInner();

    default String prettyp() {
        return "-" + getInner().prettyp();
    }
}
