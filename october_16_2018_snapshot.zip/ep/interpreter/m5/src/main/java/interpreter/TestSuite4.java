package interpreter;

import junit.framework.TestCase;

public class TestSuite4 extends TestCase {

    public void test() {
        assertEquals("-1.0", new AstreeNeg(new AstreeLit(1.0)).prettyp());
        assertEquals(-1.0, new AstreeNeg(new AstreeLit(1.0)).eval());
        assertEquals("((5.0/2.0)*4.0)", new AstreeMult(new AstreeDivd(new AstreeLit(5.0), new AstreeLit(2.0)), new AstreeLit(4.0)).prettyp());
        assertEquals("-5.0", new AstreeNeg(new AstreeLit(5.0)).prettyp());
        assertEquals("-(2.0*3.0)", new AstreeNeg(new AstreeMult(new AstreeLit(2.0), new AstreeLit(3.0))).prettyp());
    }
}
