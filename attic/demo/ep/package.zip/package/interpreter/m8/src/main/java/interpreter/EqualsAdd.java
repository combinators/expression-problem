package interpreter;

public class EqualsAdd extends AstreeIdzAdd implements EqualsExp {

    public EqualsAdd(EqualsExp left, EqualsExp right) {
        super(left, right);
    }

    public EqualsExp getLeft() {
        return (EqualsExp) this.left;
    }

    public EqualsExp getRight() {
        return (EqualsExp) this.right;
    }

    public Boolean equals(EqualsExp that) {
        return this.astree().same(that.astree());
    }
}
