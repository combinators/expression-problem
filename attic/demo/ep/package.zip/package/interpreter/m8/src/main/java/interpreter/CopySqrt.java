package interpreter;

import static interpreter.CopyExpFactory.*;

public class CopySqrt extends FindSqrt implements CopyExp {

    public CopySqrt(CopyExp inner) {
        super(inner);
    }

    public CopyExp getInner() {
        return (CopyExp) this.inner;
    }

    public CopyExp copy() {
        return Sqrt(getInner().copy());
    }
}
