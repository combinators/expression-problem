package interpreter;

import junit.framework.TestCase;

public class TestSuite extends TestCase {

    public void test1() {
        assertEquals(3.0, new CollectSimplifyAdd(new CollectSimplifyLit(1.0), new CollectSimplifyLit(2.0)).eval());
        assertEquals(5.0, new CollectSimplifyLit(5.0).eval());
    }

    public void test2() {
        assertEquals(-1.0, new CollectSimplifySub(new CollectSimplifyLit(1.0), new CollectSimplifyLit(2.0)).eval());
    }

    public void test3() {
        assertEquals("(1.0-2.0)", new CollectSimplifySub(new CollectSimplifyLit(1.0), new CollectSimplifyLit(2.0)).print());
        assertEquals("((1.0-2.0)+(5.0+6.0))", new CollectSimplifyAdd(new CollectSimplifySub(new CollectSimplifyLit(1.0), new CollectSimplifyLit(2.0)), new CollectSimplifyAdd(new CollectSimplifyLit(5.0), new CollectSimplifyLit(6.0))).print());
    }

    public void test4() {
        assertEquals("-1.0", new CollectSimplifyNeg(new CollectSimplifyLit(1.0)).print());
        assertEquals(-1.0, new CollectSimplifyNeg(new CollectSimplifyLit(1.0)).eval());
        assertEquals("((5.0/2.0)*4.0)", new CollectSimplifyMult(new CollectSimplifyDivd(new CollectSimplifyLit(5.0), new CollectSimplifyLit(2.0)), new CollectSimplifyLit(4.0)).print());
        assertEquals("-5.0", new CollectSimplifyNeg(new CollectSimplifyLit(5.0)).print());
        assertEquals("-(2.0*3.0)", new CollectSimplifyNeg(new CollectSimplifyMult(new CollectSimplifyLit(2.0), new CollectSimplifyLit(3.0))).print());
    }

    public void test5() {
        // Handle collect checks
        java.util.List<Double> list1 = new CollectSimplifyDivd(new CollectSimplifyDivd(new CollectSimplifyLit(5.0), new CollectSimplifyLit(7.0)), new CollectSimplifySub(new CollectSimplifyLit(7.0), new CollectSimplifyMult(new CollectSimplifyLit(2.0), new CollectSimplifyLit(3.0)))).collect();
        java.util.List<Double> result = new java.util.ArrayList<Double>();
        result.add(5.0);
        result.add(7.0);
        result.add(7.0);
        result.add(2.0);
        result.add(3.0);
        assertEquals(list1, result);
    }
}
