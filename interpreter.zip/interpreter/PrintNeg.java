package interpreter;

public class PrintNeg implements PrintExp {

    PrintExp Neg(PrintExp inner) {
        return new PrintNeg(inner);
    }

    PrintExp Mult(PrintExp left, PrintExp right) {
        return new PrintMult(left, right);
    }

    PrintExp Divd(PrintExp left, PrintExp right) {
        return new PrintDivd(left, right);
    }

    public PrintNeg(PrintExp inner) {
        this.inner = inner;
    }

    public PrintExp getInner() {
        return this.inner;
    }

    PrintExp inner;

    public Double eval() {
        return -getInner().eval();
    }

    public String print() {
        return "-" + getInner().print();
    }
}
