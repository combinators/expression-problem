package visitor;

public class PrettypPower extends PrettypSqrt implements VisitorPower<String> {

    public String visit(Power e) {
        return "Power(" + e.getLeft().accept(makePrettyp()) + "," + e.getRight().accept(makePrettyp()) + ")";
    }

    PrettypPower makePrettyp() {
        return new PrettypPower();
    }
}
