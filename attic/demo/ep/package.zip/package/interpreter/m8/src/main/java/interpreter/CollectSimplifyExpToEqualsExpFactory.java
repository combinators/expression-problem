package interpreter;

public class CollectSimplifyExpToEqualsExpFactory implements EqualsExp.KnownDataTypes<EqualsExp> {

    @Override
    public EqualsNeg convert(CollectSimplifyNeg from) {
        return new EqualsNeg(from.getInner().accept(this));
    }

    @Override
    public EqualsMult convert(CollectSimplifyMult from) {
        return new EqualsMult(from.getLeft().accept(this), from.getRight().accept(this));
    }

    @Override
    public EqualsDivd convert(CollectSimplifyDivd from) {
        return new EqualsDivd(from.getLeft().accept(this), from.getRight().accept(this));
    }

    @Override
    public EqualsSub convert(CollectSimplifySub from) {
        return new EqualsSub(from.getLeft().accept(this), from.getRight().accept(this));
    }

    @Override
    public EqualsLit convert(CollectSimplifyLit from) {
        return new EqualsLit(from.getValue());
    }

    @Override
    public EqualsAdd convert(CollectSimplifyAdd from) {
        return new EqualsAdd(from.getLeft().accept(this), from.getRight().accept(this));
    }
}
