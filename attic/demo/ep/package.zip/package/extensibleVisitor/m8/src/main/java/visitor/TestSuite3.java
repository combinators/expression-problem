package visitor;

import junit.framework.TestCase;

public class TestSuite3 extends TestCase {

    public void test() {
        assertEquals(new Double(-1.0), new Neg(new Lit(new Double(1.0))).accept(makeEval()));
        assertEquals("-1.0", new Neg(new Lit(new Double(1.0))).accept(makePrettyp()));
        assertEquals("((5.0/2.0)*4.0)", new Mult(new Divd(new Lit(new Double(5.0)), new Lit(new Double(2.0))), new Lit(new Double(4.0))).accept(makePrettyp()));
        assertEquals(new Double(10.0), new Mult(new Divd(new Lit(new Double(5.0)), new Lit(new Double(2.0))), new Lit(new Double(4.0))).accept(makeEval()));
        assertEquals(new Double(-5.0), new Neg(new Lit(new Double(5.0))).accept(makeEval()));
        assertEquals("-(2.0*3.0)", new Neg(new Mult(new Lit(new Double(2.0)), new Lit(new Double(3.0)))).accept(makePrettyp()));
    }

    CopyPower makeCopy() {
        return new CopyPower();
    }

    FindPower makeFind(Double target) {
        return new FindPower(target);
    }

    EqualsPower makeEquals(Exp that) {
        return new EqualsPower(that);
    }

    AstreePower makeAstree() {
        return new AstreePower();
    }

    IdzPower makeIdz() {
        return new IdzPower();
    }

    SimplifyPower makeSimplify() {
        return new SimplifyPower();
    }

    CollectPower makeCollect() {
        return new CollectPower();
    }

    PrettypPower makePrettyp() {
        return new PrettypPower();
    }

    EvalPower makeEval() {
        return new EvalPower();
    }
}
