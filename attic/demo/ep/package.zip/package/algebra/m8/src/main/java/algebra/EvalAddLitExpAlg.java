package algebra;

public class EvalAddLitExpAlg implements AddLitExpAlg<Eval> {

    public Eval lit(final Double value) {
        return () -> {
            return value;
        };
    }

    public Eval add(final Eval left, final Eval right) {
        return () -> {
            return left.eval() + right.eval();
        };
    }
}
