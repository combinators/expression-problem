package interpreter;

import static interpreter.AstreeIdzExpFactory.*;

public class AstreeIdzSqrt extends CollectSimplifySqrt implements AstreeIdzExp {

    public AstreeIdzSqrt(AstreeIdzExp inner) {
        super(inner);
    }

    public AstreeIdzExp getInner() {
        return (AstreeIdzExp) this.inner;
    }

    public AstreeIdzExp simplify() {
        return Sqrt(getInner().simplify().accept(new CollectSimplifyExpToAstreeIdzExpFactory()));
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList9 = new java.util.ArrayList<>();
        tmpList9.addAll(getInner().collect());
        return tmpList9;
    }

    public String prettyp() {
        return "Sqrt(" + getInner().prettyp() + ")";
    }

    public Double eval() {
        return Math.sqrt(getInner().eval());
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getInner().astree()), this.idz());
    }

    public Integer idz() {
        return 2584896;
    }
}
