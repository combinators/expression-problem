package visitor;

public interface VisitorSqrt<R> extends VisitorDivdMultNeg<R> {

    public R visit(Sqrt exp);
}
