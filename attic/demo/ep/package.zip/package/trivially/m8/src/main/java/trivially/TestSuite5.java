package trivially;

import junit.framework.TestCase;

public class TestSuite5 extends TestCase {

    public void test() {
        assertEquals("(5.0+7.0)", new Add((FinalI) (new Add((FinalI) (new Lit(new Double(5.0))), (FinalI) (new Lit(new Double(0.0))))), (FinalI) (new Add((FinalI) (new Lit(new Double(0.0))), (FinalI) (new Lit(new Double(7.0)))))).simplify().prettyp());
        assertEquals("(5.0/7.0)", new Divd((FinalI) (new Divd((FinalI) (new Lit(new Double(5.0))), (FinalI) (new Lit(new Double(7.0))))), (FinalI) (new Sub((FinalI) (new Lit(new Double(7.0))), (FinalI) (new Mult((FinalI) (new Lit(new Double(2.0))), (FinalI) (new Lit(new Double(3.0)))))))).simplify().prettyp());
        assertEquals(new Double(0.0), new Neg((FinalI) (new Lit(new Double(0.0)))).simplify().eval());
        assertEquals(new Double(5.0), new Add((FinalI) (new Lit(new Double(5.0))), (FinalI) (new Lit(new Double(0.0)))).simplify().eval());
        assertEquals(new Double(7.0), new Add((FinalI) (new Lit(new Double(0.0))), (FinalI) (new Lit(new Double(7.0)))).simplify().eval());
        assertEquals(new Double(13.0), new Mult((FinalI) (new Lit(new Double(13.0))), (FinalI) (new Lit(new Double(1.0)))).simplify().eval());
        assertEquals(new Double(12.0), new Mult((FinalI) (new Lit(new Double(1.0))), (FinalI) (new Lit(new Double(12.0)))).simplify().eval());
        assertEquals(new Double(0.0), new Sub((FinalI) (new Lit(new Double(7.0))), (FinalI) (new Lit(new Double(7.0)))).simplify().eval());
        assertEquals(new Double(-1.0), new Divd((FinalI) (new Lit(new Double(5.0))), (FinalI) (new Lit(new Double(-5.0)))).simplify().eval());
        assertEquals(new Double(1.0), new Divd((FinalI) (new Lit(new Double(-5.0))), (FinalI) (new Lit(new Double(-5.0)))).simplify().eval());
        assertEquals(new Double(0.0), new Divd((FinalI) (new Lit(new Double(0.0))), (FinalI) (new Lit(new Double(-5.0)))).simplify().eval());
    }
}
