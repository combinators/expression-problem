package expression;

import junit.framework.TestCase;

public class TestSuite6 extends TestCase {

    public void test() {
        assertFalse(new Sub(new Lit(1.0), new Lit(2.0)).accept(makeAstree()).same(new Sub(new Lit(9.0), new Lit(112.0)).accept(makeAstree())));
        assertTrue(new Sub(new Lit(1.0), new Lit(2.0)).accept(makeAstree()).same(new Sub(new Lit(1.0), new Lit(2.0)).accept(makeAstree())));
    }

    Equals makeEquals(Exp that) {
        return new Equals(that);
    }

    Astree makeAstree() {
        return new Astree();
    }

    Simplify makeSimplify() {
        return new Simplify();
    }

    Collect makeCollect() {
        return new Collect();
    }

    Prettyp makePrettyp() {
        return new PrettypDivdMultNeg();
    }

    Eval makeEval() {
        return new EvalDivdMultNeg();
    }

    Id makeId() {
        return new IdDivdMultNeg();
    }
}
