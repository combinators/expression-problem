package trivially;

public class Sub implements FinalI, SubHeight {

    public Sub(FinalI left, FinalI right) {
        this.left = left;
        this.right = right;
    }

    public FinalI getLeft() {
        return this.left;
    }

    public FinalI getRight() {
        return this.right;
    }

    private FinalI left;

    private FinalI right;
}
