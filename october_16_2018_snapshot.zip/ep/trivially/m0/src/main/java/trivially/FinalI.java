package trivially;

public interface FinalI extends ExpEval, ExpId {
}
