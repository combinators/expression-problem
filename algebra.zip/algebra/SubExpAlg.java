package algebra;

interface SubExpAlg<E> extends AddLitExpAlg<E> {

    E sub(final E left, final E right);
}
