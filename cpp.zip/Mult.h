
#ifndef _Mult_
#define _Mult_

#include "visitor.h" 
#include "Exp.h" 
#include "ExpVisitor.h" 

class Mult : public Exp {
public:
  const Exp* getLeft() const { return left_; }
  const Exp* getRight() const { return right_; }
  Mult (const Exp* left,const Exp* right) : left_(left),right_(right) {}
  void Accept(ExpVisitor* visitor) const;

private:
  const Exp* left_;
  const Exp* right_;
};
#endif /* _Mult_ */
       