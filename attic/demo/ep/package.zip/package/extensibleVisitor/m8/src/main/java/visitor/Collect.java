package visitor;

public class Collect implements VisitorDivdMultNeg<java.util.List<Double>> {

    public java.util.List<Double> visit(Neg e) {
        java.util.List<Double> tmpList0 = new java.util.ArrayList<>();
        tmpList0.addAll(e.getInner().accept(makeCollect()));
        return tmpList0;
    }

    public java.util.List<Double> visit(Mult e) {
        java.util.List<Double> tmpList1 = new java.util.ArrayList<>();
        tmpList1.addAll(e.getLeft().accept(makeCollect()));
        tmpList1.addAll(e.getRight().accept(makeCollect()));
        return tmpList1;
    }

    public java.util.List<Double> visit(Divd e) {
        java.util.List<Double> tmpList2 = new java.util.ArrayList<>();
        tmpList2.addAll(e.getLeft().accept(makeCollect()));
        tmpList2.addAll(e.getRight().accept(makeCollect()));
        return tmpList2;
    }

    public java.util.List<Double> visit(Sub e) {
        java.util.List<Double> tmpList3 = new java.util.ArrayList<>();
        tmpList3.addAll(e.getLeft().accept(makeCollect()));
        tmpList3.addAll(e.getRight().accept(makeCollect()));
        return tmpList3;
    }

    public java.util.List<Double> visit(Lit e) {
        java.util.List<Double> tmpList4 = new java.util.ArrayList<>();
        tmpList4.add(e.getValue());
        return tmpList4;
    }

    public java.util.List<Double> visit(Add e) {
        java.util.List<Double> tmpList5 = new java.util.ArrayList<>();
        tmpList5.addAll(e.getLeft().accept(makeCollect()));
        tmpList5.addAll(e.getRight().accept(makeCollect()));
        return tmpList5;
    }

    Collect makeCollect() {
        return new Collect();
    }
}
