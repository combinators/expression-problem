package expression;

public class Neg extends Exp {

    public Neg(Exp inner) {
        this.inner = inner;
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(inner.astree()), 78192);
    }

    private Exp inner;

    public Exp getInner() {
        return this.inner;
    }

    public <R> R accept(Visitor<R> v) {
        if (v instanceof VisitorDivdMultNeg) {
            return ((VisitorDivdMultNeg<R>) v).visit(this);
        }
        throw new RuntimeException("Older visitor used with newer datatype variant.");
    }
}
