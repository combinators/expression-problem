package trivially;

public interface PowerPrettyp extends ExpPrettyp, PowerEval {

    ExpPrettyp getLeft();

    ExpPrettyp getRight();

    default String prettyp() {
        return "Power(" + getLeft().prettyp() + "," + getRight().prettyp() + ")";
    }
}
