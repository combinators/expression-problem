package interpreter;

public interface EvalExp {

    public Double eval();
}
