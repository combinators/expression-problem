package trivially;

import junit.framework.TestCase;

public class TestSuite6 extends TestCase {

    public void test() {
        assertEquals(new Integer(1), new Inv(new Lit(2.0)).height(0));
        assertEquals(new Integer(3), new Add(new Add(new Lit(5.0), new Lit(7.0)), new Inv(new Add(new Lit(2.0), new Lit(3.0)))).height(0));
    }
}
