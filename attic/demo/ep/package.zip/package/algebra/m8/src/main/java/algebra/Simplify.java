package algebra;

interface Simplify {

    algebra.CombinedExpAlg.Combined simplify();
}
