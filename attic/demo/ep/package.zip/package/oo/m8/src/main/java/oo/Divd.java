package oo;

public class Divd extends Exp {

    public Divd(Exp left, Exp right) {
        this.left = left;
        this.right = right;
    }

    private Exp left;

    private Exp right;

    public Exp copy() {
        return new Divd(left.copy(), right.copy());
    }

    public Integer find(Double target) {
        return left.find(target) + right.find(target);
    }

    public Boolean equals(Exp that) {
        return this.astree().same(that.astree());
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(left.astree(), right.astree()), this.idz());
    }

    public Integer idz() {
        return 2130451;
    }

    public Exp simplify() {
        double leftVal = left.eval();
        double rightVal = right.eval();
        if (leftVal == 0) {
            return new Lit(0.0);
        } else if (rightVal == 1) {
            return left.simplify();
        } else if (leftVal == rightVal) {
            return new Lit(1.0);
        } else if (leftVal == -rightVal) {
            return new Lit(-1.0);
        } else {
            return new Divd(left.simplify(), right.simplify());
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList4 = new java.util.ArrayList<>();
        tmpList4.addAll(left.collect());
        tmpList4.addAll(right.collect());
        return tmpList4;
    }

    public String prettyp() {
        return "(" + left.prettyp() + "/" + right.prettyp() + ")";
    }

    public Double eval() {
        return left.eval() / right.eval();
    }
}
