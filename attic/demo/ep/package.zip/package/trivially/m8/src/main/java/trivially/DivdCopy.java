package trivially;

public interface DivdCopy extends ExpCopy, DivdFind {

    ExpCopy getLeft();

    ExpCopy getRight();

    default ExpCopy copy() {
        return new Divd((FinalI) (getLeft().copy()), (FinalI) (getRight().copy()));
    }
}
