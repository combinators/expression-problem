package interpreter;

import static interpreter.CopyExpFactory.*;

public class CopyLit extends FindLit implements CopyExp {

    public CopyLit(Double value) {
        super(value);
    }

    public Double getValue() {
        return this.value;
    }

    public CopyExp copy() {
        return Lit(getValue());
    }
}
