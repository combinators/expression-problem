package algebra;

public class EvalDivdMultNegExpAlg extends EvalSubExpAlg implements DivdMultNegExpAlg<Eval> {

    public Eval neg(final Eval inner) {
        return new Eval() {

            public Double eval() {
                return -inner.eval();
            }
        };
    }

    public Eval mult(final Eval left, final Eval right) {
        return new Eval() {

            public Double eval() {
                return left.eval() * right.eval();
            }
        };
    }

    public Eval divd(final Eval left, final Eval right) {
        return new Eval() {

            public Double eval() {
                return left.eval() / right.eval();
            }
        };
    }
}
