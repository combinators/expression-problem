package algebra;

public class PrettypPowerExpAlg extends PrettypSqrtExpAlg implements PowerExpAlg<Prettyp> {

    public Prettyp power(final Prettyp left, final Prettyp right) {
        return () -> {
            return "Power(" + left.prettyp() + "," + right.prettyp() + ")";
        };
    }
}
