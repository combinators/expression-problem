package interpreter;

public class PrettypNeg implements PrettypExp {

    PrettypExp Neg(PrettypExp inner) {
        return new PrettypNeg(inner);
    }

    PrettypExp Mult(PrettypExp left, PrettypExp right) {
        return new PrettypMult(left, right);
    }

    PrettypExp Divd(PrettypExp left, PrettypExp right) {
        return new PrettypDivd(left, right);
    }

    public PrettypNeg(PrettypExp inner) {
        this.inner = inner;
    }

    public PrettypExp getInner() {
        return this.inner;
    }

    PrettypExp inner;

    public Double eval() {
        return -getInner().eval();
    }

    public Integer id() {
        return 78192;
    }

    public String prettyp() {
        return "-" + getInner().prettyp();
    }
}
