package trivially;

public interface LitPrint extends ExpPrint, LitEval {

    Double getValue();

    default String print() {
        return "" + getValue() + "";
    }
}
