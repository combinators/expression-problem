package visitor;

public class EvalPower extends EvalSqrt implements VisitorPower<Double> {

    public Double visit(Power e) {
        return Math.pow(e.getLeft().accept(makeEval()), e.getRight().accept(makeEval()));
    }

    EvalPower makeEval() {
        return new EvalPower();
    }
}
