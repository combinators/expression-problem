package interpreter;

import static interpreter.FindExpFactory.*;

public class FindPower extends EqualsPower implements FindExp {

    public FindPower(FindExp left, FindExp right) {
        super(left, right);
    }

    public FindExp getLeft() {
        return (FindExp) this.left;
    }

    public FindExp getRight() {
        return (FindExp) this.right;
    }

    public Boolean equals(FindExp that) {
        return this.astree().same(that.astree());
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getLeft().astree(), getRight().astree()), this.idz());
    }

    public Integer idz() {
        return 77306085;
    }

    public FindExp simplify() {
        double leftVal = getLeft().eval();
        double rightVal = getRight().eval();
        if (leftVal == 0) {
            return Lit(0.0);
        } else if (rightVal == 0) {
            return Lit(1.0);
        } else if (rightVal == 1) {
            return getLeft().simplify().accept(new CollectSimplifyExpToFindExpFactory());
        } else {
            return Power(getLeft().simplify().accept(new CollectSimplifyExpToFindExpFactory()), getRight().simplify().accept(new CollectSimplifyExpToFindExpFactory()));
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList12 = new java.util.ArrayList<>();
        tmpList12.addAll(getLeft().collect());
        tmpList12.addAll(getRight().collect());
        return tmpList12;
    }

    public String prettyp() {
        return "Power(" + getLeft().prettyp() + "," + getRight().prettyp() + ")";
    }

    public Double eval() {
        return Math.pow(getLeft().eval(), getRight().eval());
    }

    public Integer find(Double target) {
        return getLeft().find(target) + getRight().find(target);
    }
}
