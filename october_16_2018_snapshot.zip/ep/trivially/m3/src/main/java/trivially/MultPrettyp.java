package trivially;

public interface MultPrettyp extends ExpPrettyp, MultEval, MultId {

    ExpPrettyp getLeft();

    ExpPrettyp getRight();

    default String prettyp() {
        return "(" + getLeft().prettyp() + "*" + getRight().prettyp() + ")";
    }
}
