package algebra;

public class CollectSqrtExpAlg extends CollectDivdMultNegExpAlg implements SqrtExpAlg<Collect> {

    public Collect sqrt(final Collect inner) {
        return () -> {
            java.util.List<Double> tmpList6 = new java.util.ArrayList<>();
            tmpList6.addAll(inner.collect());
            return tmpList6;
        };
    }
}
