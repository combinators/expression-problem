package algebra;

interface Find {

    Integer find(Double target);
}
