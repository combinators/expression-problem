package trivially;

public interface ExpAstreeIdz extends ExpCollectSimplify {

    public tree.Tree astree();

    public Integer idz();
}
