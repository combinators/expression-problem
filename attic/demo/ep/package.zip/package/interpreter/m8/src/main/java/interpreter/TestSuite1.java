package interpreter;

import junit.framework.TestCase;
import static interpreter.CopyExpFactory.*;

public class TestSuite1 extends TestCase {

    public void test() {
        assertEquals(new Double(-1.0), Sub(Lit(new Double(1.0)), Lit(new Double(2.0))).eval());
    }
}
