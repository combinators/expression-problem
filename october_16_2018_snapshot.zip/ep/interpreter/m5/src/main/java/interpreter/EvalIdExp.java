package interpreter;

public interface EvalIdExp {

    public Double eval();

    public Integer id();
}
