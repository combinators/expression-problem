package algebra;

public class EqualsSqrtExpAlg extends EqualsDivdMultNegExpAlg implements SqrtExpAlg<Equals> {

    AstreeSqrtExpAlg asTree = new AstreeSqrtExpAlg();

    public Equals sqrt(final Equals inner) {
        return new Equals() {

            public tree.Tree astree() {
                return asTree.sqrt(inner).astree();
            }

            public Boolean equals(Equals that) {
                // was NAME
                return astree().same(that.astree());
            }
        };
    }
}
