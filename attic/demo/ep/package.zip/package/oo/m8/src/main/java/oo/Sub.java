package oo;

public class Sub extends Exp {

    public Sub(Exp left, Exp right) {
        this.left = left;
        this.right = right;
    }

    private Exp left;

    private Exp right;

    public Exp copy() {
        return new Sub(left.copy(), right.copy());
    }

    public Integer find(Double target) {
        return left.find(target) + right.find(target);
    }

    public Boolean equals(Exp that) {
        return this.astree().same(that.astree());
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(left.astree(), right.astree()), this.idz());
    }

    public Integer idz() {
        return 83488;
    }

    public Exp simplify() {
        if (left.eval() == right.eval()) {
            return new Lit(0.0);
        } else {
            return new Sub(left.simplify(), right.simplify());
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList5 = new java.util.ArrayList<>();
        tmpList5.addAll(left.collect());
        tmpList5.addAll(right.collect());
        return tmpList5;
    }

    public String prettyp() {
        return "(" + left.prettyp() + "-" + right.prettyp() + ")";
    }

    public Double eval() {
        return left.eval() - right.eval();
    }
}
