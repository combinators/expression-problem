package interpreter;

import junit.framework.TestCase;

public class TestSuite5 extends TestCase {

    public void test() {
        // Handle collect checks
        java.util.List<Double> list1 = new EqualsDivd(new EqualsDivd(new EqualsLit(5.0), new EqualsLit(7.0)), new EqualsSub(new EqualsLit(7.0), new EqualsMult(new EqualsLit(2.0), new EqualsLit(3.0)))).collect();
        java.util.List<Double> result = new java.util.ArrayList<Double>();
        result.add(5.0);
        result.add(7.0);
        result.add(7.0);
        result.add(2.0);
        result.add(3.0);
        assertEquals(list1, result);
    }
}
