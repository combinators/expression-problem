package trivially;

public interface AddEquals extends ExpEquals, AddAstree {

    ExpEquals getLeft();

    ExpEquals getRight();

    default Boolean equals(Exp that) {
        return astree().same(that.astree());
    }
}
