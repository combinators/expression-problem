
#include "visitor.h" 
#include "Exp.h" 
#include "ExpVisitor.h" 
#include "Add.h" 
  void Add::Accept(ExpVisitor* visitor) const {
  left_->Accept(visitor);
  right_->Accept(visitor);
  visitor->VisitAdd(this);
  }
        