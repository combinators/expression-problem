package trivially;

public interface AddPrint extends ExpPrint, AddEval {

    ExpPrint getLeft();

    ExpPrint getRight();

    default String print() {
        return "(" + getLeft().print() + "+" + getRight().print() + ")";
    }
}
