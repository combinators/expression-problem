package trivially;

public interface DivdEquals extends ExpEquals, DivdAstree {

    ExpEquals getLeft();

    ExpEquals getRight();

    default Boolean equals(Exp that) {
        return astree().same(that.astree());
    }
}
