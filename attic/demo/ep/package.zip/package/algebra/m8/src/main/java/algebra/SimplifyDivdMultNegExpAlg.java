package algebra;

public class SimplifyDivdMultNegExpAlg implements DivdMultNegExpAlg<Simplify> {

    // Binary operations are passed in necessary algebra to work with
    CombinedExpAlg algebra;

    public SimplifyDivdMultNegExpAlg(CombinedExpAlg alg) {
        this.algebra = alg;
    }

    public Simplify neg(final Simplify inner) {
        return () -> {
            if (inner.simplify().eval() == 0) {
                return algebra.lit(0.0);
            } else {
                return algebra.neg(inner.simplify());
            }
        };
    }

    public Simplify mult(final Simplify left, final Simplify right) {
        return () -> {
            double leftVal = left.simplify().eval();
            double rightVal = right.simplify().eval();
            if (leftVal == 0 || rightVal == 0) {
                return algebra.lit(0.0);
            } else if (leftVal == 1) {
                return right.simplify();
            } else if (rightVal == 1) {
                return left.simplify();
            } else {
                return algebra.mult(left.simplify(), right.simplify());
            }
        };
    }

    public Simplify divd(final Simplify left, final Simplify right) {
        return () -> {
            double leftVal = left.simplify().eval();
            double rightVal = right.simplify().eval();
            if (leftVal == 0) {
                return algebra.lit(0.0);
            } else if (rightVal == 1) {
                return left.simplify();
            } else if (leftVal == rightVal) {
                return algebra.lit(1.0);
            } else if (leftVal == -rightVal) {
                return algebra.lit(-1.0);
            } else {
                return algebra.divd(left.simplify(), right.simplify());
            }
        };
    }

    public Simplify sub(final Simplify left, final Simplify right) {
        return () -> {
            if (left.simplify().eval() == right.simplify().eval()) {
                return algebra.lit(0.0);
            } else {
                return algebra.sub(left.simplify(), right.simplify());
            }
        };
    }

    public Simplify lit(final Double value) {
        return () -> {
            return algebra.lit(value);
        };
    }

    public Simplify add(final Simplify left, final Simplify right) {
        return () -> {
            double leftVal = left.simplify().eval();
            double rightVal = right.simplify().eval();
            if ((leftVal == 0 && rightVal == 0) || (leftVal + rightVal == 0)) {
                return algebra.lit(0.0);
            } else if (leftVal == 0) {
                return right.simplify();
            } else if (rightVal == 0) {
                return left.simplify();
            } else {
                return algebra.add(left.simplify(), right.simplify());
            }
        };
    }
}
