package trivially;

public interface NegHeight extends ExpHeight, NegPrettyp {

    ExpHeight getInner();

    default Integer height(Integer height) {
        return getInner().height(height + 1);
    }
}
