package visitor;

import junit.framework.TestCase;

public class TestSuite3 extends TestCase {

    public void test() {
        assertEquals(new Double(-1.0), new Neg(new Lit(new Double(1.0))).accept(new Eval()));
        assertEquals("-1.0", new Neg(new Lit(new Double(1.0))).accept(new Prettyp()));
        assertEquals("((5.0/2.0)*4.0)", new Mult(new Divd(new Lit(new Double(5.0)), new Lit(new Double(2.0))), new Lit(new Double(4.0))).accept(new Prettyp()));
        assertEquals(new Double(10.0), new Mult(new Divd(new Lit(new Double(5.0)), new Lit(new Double(2.0))), new Lit(new Double(4.0))).accept(new Eval()));
        assertEquals(new Double(-5.0), new Neg(new Lit(new Double(5.0))).accept(new Eval()));
        assertEquals("-(2.0*3.0)", new Neg(new Mult(new Lit(new Double(2.0)), new Lit(new Double(3.0)))).accept(new Prettyp()));
    }
}
