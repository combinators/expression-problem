package oo;

public class Sqrt extends Exp {

    public Sqrt(Exp inner) {
        this.inner = inner;
    }

    private Exp inner;

    public Exp copy() {
        return new Sqrt(inner.copy());
    }

    public Integer find(Double target) {
        return inner.find(target);
    }

    public Boolean equals(Exp that) {
        return this.astree().same(that.astree());
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(inner.astree()), this.idz());
    }

    public Integer idz() {
        return 2584896;
    }

    public Exp simplify() {
        return new Sqrt(inner.simplify());
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList1 = new java.util.ArrayList<>();
        tmpList1.addAll(inner.collect());
        return tmpList1;
    }

    public String prettyp() {
        return "Sqrt(" + inner.prettyp() + ")";
    }

    public Double eval() {
        return Math.sqrt(inner.eval());
    }
}
