package trivially;

public interface MultCollectSimplify extends ExpCollectSimplify, MultPrettyp {

    ExpCollectSimplify getLeft();

    ExpCollectSimplify getRight();

    default ExpCollectSimplify simplify() {
        double leftVal = getLeft().eval();
        double rightVal = getRight().eval();
        if (leftVal == 0 || rightVal == 0) {
            return new Lit(0.0);
        } else if (leftVal == 1) {
            return getRight().simplify();
        } else if (rightVal == 1) {
            return getLeft().simplify();
        } else {
            return new Mult((FinalI) (getLeft().simplify()), (FinalI) (getRight().simplify()));
        }
    }

    default java.util.List<Double> collect() {
        java.util.List<Double> tmpList3 = new java.util.ArrayList<>();
        tmpList3.addAll(getLeft().collect());
        tmpList3.addAll(getRight().collect());
        return tmpList3;
    }
}
