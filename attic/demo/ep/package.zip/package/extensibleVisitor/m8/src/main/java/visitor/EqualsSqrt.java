package visitor;

public class EqualsSqrt extends Equals implements VisitorSqrt<Boolean> {

    public EqualsSqrt(Exp that) {
        super(that);
        this.that = that;
    }

    Exp that;

    public Boolean visit(Sqrt e) {
        return e.accept(makeAstree()).same(that.accept(makeAstree()));
    }

    EqualsSqrt makeEquals(Exp that) {
        return new EqualsSqrt(that);
    }
}
