package interpreter;

public class AstreeLit extends CollectSimplifyLit implements AstreeExp {

    AstreeExp Neg(AstreeExp inner) {
        return new AstreeNeg(inner);
    }

    AstreeExp Mult(AstreeExp left, AstreeExp right) {
        return new AstreeMult(left, right);
    }

    AstreeExp Divd(AstreeExp left, AstreeExp right) {
        return new AstreeDivd(left, right);
    }

    AstreeExp Sub(AstreeExp left, AstreeExp right) {
        return new AstreeSub(left, right);
    }

    AstreeExp Lit(Double value) {
        return new AstreeLit(value);
    }

    AstreeExp Add(AstreeExp left, AstreeExp right) {
        return new AstreeAdd(left, right);
    }

    public AstreeLit(Double value) {
        super(value);
    }

    public Double getValue() {
        return this.value;
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(new tree.Leaf(getValue())), this.id());
    }
}
