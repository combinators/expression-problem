package interpreter;

public class AstreeIdzSub extends CollectSimplifySub implements AstreeIdzExp {

    public AstreeIdzSub(AstreeIdzExp left, AstreeIdzExp right) {
        super(left, right);
    }

    public AstreeIdzExp getLeft() {
        return (AstreeIdzExp) this.left;
    }

    public AstreeIdzExp getRight() {
        return (AstreeIdzExp) this.right;
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getLeft().astree(), getRight().astree()), this.idz());
    }

    public Integer idz() {
        return 83488;
    }
}
