package algebra.oo;

public class Sqrt extends Exp {

    public Sqrt(Exp inner) {
        this.inner = inner;
    }

    private Exp inner;

    public algebra.CombinedExpAlg.Combined convert(algebra.CombinedExpAlg algebra) {
        return algebra.sqrt(inner.convert(algebra));
    }
}
