package interpreter;

import static interpreter.EqualsExpFactory.*;

public class EqualsPower extends AstreeIdzPower implements EqualsExp {

    public EqualsPower(EqualsExp left, EqualsExp right) {
        super(left, right);
    }

    public EqualsExp getLeft() {
        return (EqualsExp) this.left;
    }

    public EqualsExp getRight() {
        return (EqualsExp) this.right;
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getLeft().astree(), getRight().astree()), this.idz());
    }

    public Integer idz() {
        return 77306085;
    }

    public EqualsExp simplify() {
        double leftVal = getLeft().eval();
        double rightVal = getRight().eval();
        if (leftVal == 0) {
            return Lit(0.0);
        } else if (rightVal == 0) {
            return Lit(1.0);
        } else if (rightVal == 1) {
            return getLeft().simplify().accept(new CollectSimplifyExpToEqualsExpFactory());
        } else {
            return Power(getLeft().simplify().accept(new CollectSimplifyExpToEqualsExpFactory()), getRight().simplify().accept(new CollectSimplifyExpToEqualsExpFactory()));
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList10 = new java.util.ArrayList<>();
        tmpList10.addAll(getLeft().collect());
        tmpList10.addAll(getRight().collect());
        return tmpList10;
    }

    public String prettyp() {
        return "Power(" + getLeft().prettyp() + "," + getRight().prettyp() + ")";
    }

    public Double eval() {
        return Math.pow(getLeft().eval(), getRight().eval());
    }

    public Boolean equals(EqualsExp that) {
        return this.astree().same(that.astree());
    }
}
