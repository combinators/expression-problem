package oo;

public class Mult extends Exp {

    public Mult(Exp left, Exp right) {
        this.left = left;
        this.right = right;
    }

    private Exp left;

    private Exp right;

    public Exp copy() {
        return new Mult(left.copy(), right.copy());
    }

    public Integer find(Double target) {
        return left.find(target) + right.find(target);
    }

    public Boolean equals(Exp that) {
        return this.astree().same(that.astree());
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(left.astree(), right.astree()), this.idz());
    }

    public Integer idz() {
        return 2409808;
    }

    public Exp simplify() {
        double leftVal = left.eval();
        double rightVal = right.eval();
        if (leftVal == 0 || rightVal == 0) {
            return new Lit(0.0);
        } else if (leftVal == 1) {
            return right.simplify();
        } else if (rightVal == 1) {
            return left.simplify();
        } else {
            return new Mult(left.simplify(), right.simplify());
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList3 = new java.util.ArrayList<>();
        tmpList3.addAll(left.collect());
        tmpList3.addAll(right.collect());
        return tmpList3;
    }

    public String prettyp() {
        return "(" + left.prettyp() + "*" + right.prettyp() + ")";
    }

    public Double eval() {
        return left.eval() * right.eval();
    }
}
