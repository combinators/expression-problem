package interpreter;

import static interpreter.AstreeIdzExpFactory.*;

public class AstreeIdzPower extends CollectSimplifyPower implements AstreeIdzExp {

    public AstreeIdzPower(AstreeIdzExp left, AstreeIdzExp right) {
        super(left, right);
    }

    public AstreeIdzExp getLeft() {
        return (AstreeIdzExp) this.left;
    }

    public AstreeIdzExp getRight() {
        return (AstreeIdzExp) this.right;
    }

    public AstreeIdzExp simplify() {
        double leftVal = getLeft().eval();
        double rightVal = getRight().eval();
        if (leftVal == 0) {
            return Lit(0.0);
        } else if (rightVal == 0) {
            return Lit(1.0);
        } else if (rightVal == 1) {
            return getLeft().simplify().accept(new CollectSimplifyExpToAstreeIdzExpFactory());
        } else {
            return Power(getLeft().simplify().accept(new CollectSimplifyExpToAstreeIdzExpFactory()), getRight().simplify().accept(new CollectSimplifyExpToAstreeIdzExpFactory()));
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList8 = new java.util.ArrayList<>();
        tmpList8.addAll(getLeft().collect());
        tmpList8.addAll(getRight().collect());
        return tmpList8;
    }

    public String prettyp() {
        return "Power(" + getLeft().prettyp() + "," + getRight().prettyp() + ")";
    }

    public Double eval() {
        return Math.pow(getLeft().eval(), getRight().eval());
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getLeft().astree(), getRight().astree()), this.idz());
    }

    public Integer idz() {
        return 77306085;
    }
}
