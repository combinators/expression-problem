package oo;

public abstract class Exp {

    public abstract Exp copy();

    public abstract Integer find(Double target);

    public abstract Boolean equals(Exp that);

    public abstract tree.Tree astree();

    public abstract Integer idz();

    public abstract Exp simplify();

    public abstract java.util.List<Double> collect();

    public abstract String prettyp();

    public abstract Double eval();
}
