package interpreter;

public class PrintLit extends EvalLit implements PrintExp {

    PrintExp Sub(PrintExp left, PrintExp right) {
        return new PrintSub(left, right);
    }

    PrintExp Lit(Double value) {
        return new PrintLit(value);
    }

    PrintExp Add(PrintExp left, PrintExp right) {
        return new PrintAdd(left, right);
    }

    public PrintLit(Double value) {
        super(value);
    }

    public Double getValue() {
        return this.value;
    }

    public Double eval() {
        return getValue();
    }

    public String print() {
        return "" + getValue() + "";
    }
}
