package trivially;

public interface AddHeight extends ExpHeight, AddPrettyp {

    ExpHeight getLeft();

    ExpHeight getRight();

    default Integer height(Integer height) {
        return Math.max(getLeft().height(height + 1), getRight().height(height + 1));
    }
}
