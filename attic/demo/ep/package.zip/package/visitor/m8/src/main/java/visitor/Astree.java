package visitor;

public class Astree extends Visitor<tree.Tree> {

    public tree.Tree visit(Power e) {
        return new tree.Node(java.util.Arrays.asList(e.getLeft().astree(), e.getRight().astree()), e.accept(new Idz()));
    }

    public tree.Tree visit(Sqrt e) {
        return new tree.Node(java.util.Arrays.asList(e.getInner().astree()), e.accept(new Idz()));
    }

    public tree.Tree visit(Neg e) {
        return new tree.Node(java.util.Arrays.asList(e.getInner().astree()), e.accept(new Idz()));
    }

    public tree.Tree visit(Mult e) {
        return new tree.Node(java.util.Arrays.asList(e.getLeft().astree(), e.getRight().astree()), e.accept(new Idz()));
    }

    public tree.Tree visit(Divd e) {
        return new tree.Node(java.util.Arrays.asList(e.getLeft().astree(), e.getRight().astree()), e.accept(new Idz()));
    }

    public tree.Tree visit(Sub e) {
        return new tree.Node(java.util.Arrays.asList(e.getLeft().astree(), e.getRight().astree()), e.accept(new Idz()));
    }

    public tree.Tree visit(Lit e) {
        return new tree.Leaf(e.getValue());
    }

    public tree.Tree visit(Add e) {
        return new tree.Node(java.util.Arrays.asList(e.getLeft().astree(), e.getRight().astree()), e.accept(new Idz()));
    }
}
