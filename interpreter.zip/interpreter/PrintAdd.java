package interpreter;

public class PrintAdd extends EvalAdd implements PrintExp {

    PrintExp Sub(PrintExp left, PrintExp right) {
        return new PrintSub(left, right);
    }

    PrintExp Lit(Double value) {
        return new PrintLit(value);
    }

    PrintExp Add(PrintExp left, PrintExp right) {
        return new PrintAdd(left, right);
    }

    public PrintAdd(PrintExp left, PrintExp right) {
        super(left, right);
    }

    public PrintExp getLeft() {
        return (PrintExp) this.left;
    }

    public PrintExp getRight() {
        return (PrintExp) this.right;
    }

    public Double eval() {
        return getLeft().eval() + getRight().eval();
    }

    public String print() {
        return "(" + getLeft().print() + "+" + getRight().print() + ")";
    }
}
