package expression;

import junit.framework.TestCase;

public class TestSuite4 extends TestCase {

    public void test() {
        assertEquals("-1.0", new Neg(new Lit(1.0)).accept(makePrettyp()));
        assertEquals(-1.0, new Neg(new Lit(1.0)).accept(makeEval()));
        assertEquals("((5.0/2.0)*4.0)", new Mult(new Divd(new Lit(5.0), new Lit(2.0)), new Lit(4.0)).accept(makePrettyp()));
        assertEquals("-5.0", new Neg(new Lit(5.0)).accept(makePrettyp()));
        assertEquals("-(2.0*3.0)", new Neg(new Mult(new Lit(2.0), new Lit(3.0))).accept(makePrettyp()));
    }

    Equals makeEquals(Exp that) {
        return new Equals(that);
    }

    Astree makeAstree() {
        return new Astree();
    }

    Simplify makeSimplify() {
        return new Simplify();
    }

    Collect makeCollect() {
        return new Collect();
    }

    Prettyp makePrettyp() {
        return new PrettypDivdMultNeg();
    }

    Eval makeEval() {
        return new EvalDivdMultNeg();
    }

    Id makeId() {
        return new IdDivdMultNeg();
    }
}
