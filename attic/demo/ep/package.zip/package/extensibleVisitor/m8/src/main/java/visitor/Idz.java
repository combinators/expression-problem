package visitor;

public class Idz implements VisitorDivdMultNeg<Integer> {

    public Integer visit(Neg e) {
        return 78192;
    }

    public Integer visit(Mult e) {
        return 2409808;
    }

    public Integer visit(Divd e) {
        return 2130451;
    }

    public Integer visit(Sub e) {
        return 83488;
    }

    public Integer visit(Lit e) {
        return 76407;
    }

    public Integer visit(Add e) {
        return 65665;
    }

    Idz makeIdz() {
        return new Idz();
    }
}
