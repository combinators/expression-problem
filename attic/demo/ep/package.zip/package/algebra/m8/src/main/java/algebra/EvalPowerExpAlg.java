package algebra;

public class EvalPowerExpAlg extends EvalSqrtExpAlg implements PowerExpAlg<Eval> {

    public Eval power(final Eval left, final Eval right) {
        return () -> {
            return Math.pow(left.eval(), right.eval());
        };
    }
}
