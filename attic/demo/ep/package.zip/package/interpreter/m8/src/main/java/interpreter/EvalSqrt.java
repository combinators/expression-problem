package interpreter;

public class EvalSqrt implements EvalExp {

    public EvalSqrt(EvalExp inner) {
        this.inner = inner;
    }

    public EvalExp getInner() {
        return this.inner;
    }

    EvalExp inner;

    public Double eval() {
        return Math.sqrt(getInner().eval());
    }
}
