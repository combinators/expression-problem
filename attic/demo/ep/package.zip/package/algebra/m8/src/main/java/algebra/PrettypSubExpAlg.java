package algebra;

public class PrettypSubExpAlg implements SubExpAlg<Prettyp> {

    public Prettyp sub(final Prettyp left, final Prettyp right) {
        return () -> {
            return "(" + left.prettyp() + "-" + right.prettyp() + ")";
        };
    }

    public Prettyp lit(final Double value) {
        return () -> {
            return "" + value;
        };
    }

    public Prettyp add(final Prettyp left, final Prettyp right) {
        return () -> {
            return "(" + left.prettyp() + "+" + right.prettyp() + ")";
        };
    }
}
