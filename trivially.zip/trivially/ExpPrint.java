package trivially;

public interface ExpPrint extends ExpEval {

    public String print();
}
