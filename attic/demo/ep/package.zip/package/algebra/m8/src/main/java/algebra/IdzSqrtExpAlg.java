package algebra;

public class IdzSqrtExpAlg extends IdzDivdMultNegExpAlg implements SqrtExpAlg<Idz> {

    public Idz sqrt(final Idz inner) {
        return () -> {
            return 2584896;
        };
    }
}
