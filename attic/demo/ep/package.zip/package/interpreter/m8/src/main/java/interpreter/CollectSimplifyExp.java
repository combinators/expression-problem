package interpreter;

public interface CollectSimplifyExp extends PrettypExp {

    // All known data types up until this evolution.s
    interface KnownDataTypes<R> {

        R convert(CollectSimplifyNeg from);

        R convert(CollectSimplifyMult from);

        R convert(CollectSimplifyDivd from);

        R convert(CollectSimplifySub from);

        R convert(CollectSimplifyLit from);

        R convert(CollectSimplifyAdd from);
    }

    <R> R accept(KnownDataTypes<R> from);

    public CollectSimplifyExp simplify();

    public java.util.List<Double> collect();
}
