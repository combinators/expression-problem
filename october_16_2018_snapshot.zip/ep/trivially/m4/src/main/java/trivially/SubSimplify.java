package trivially;

public interface SubSimplify extends ExpSimplify, SubPrettyp {

    ExpSimplify getLeft();

    ExpSimplify getRight();

    default ExpSimplify simplify() {
        if (getLeft().eval() == getRight().eval()) {
            return new Lit(0.0);
        } else {
            return new Sub((FinalI) (getLeft().simplify()), (FinalI) (getRight().simplify()));
        }
    }
}
