package algebra;

public class PrettypSqrtExpAlg extends PrettypDivdMultNegExpAlg implements SqrtExpAlg<Prettyp> {

    public Prettyp sqrt(final Prettyp inner) {
        return () -> {
            return "Sqrt(" + inner.prettyp() + ")";
        };
    }
}
