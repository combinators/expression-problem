package interpreter;

public class AstreeIdzLit extends CollectSimplifyLit implements AstreeIdzExp {

    public AstreeIdzLit(Double value) {
        super(value);
    }

    public Double getValue() {
        return this.value;
    }

    public tree.Tree astree() {
        return new tree.Leaf(getValue());
    }

    public Integer idz() {
        return 76407;
    }
}
