package interpreter;

public class PrettypPower extends EvalPower implements PrettypExp {

    public PrettypPower(PrettypExp left, PrettypExp right) {
        super(left, right);
    }

    public PrettypExp getLeft() {
        return (PrettypExp) this.left;
    }

    public PrettypExp getRight() {
        return (PrettypExp) this.right;
    }

    public Double eval() {
        return Math.pow(getLeft().eval(), getRight().eval());
    }

    public String prettyp() {
        return "Power(" + getLeft().prettyp() + "," + getRight().prettyp() + ")";
    }
}
