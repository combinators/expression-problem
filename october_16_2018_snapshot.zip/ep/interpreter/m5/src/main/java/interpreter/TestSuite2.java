package interpreter;

import junit.framework.TestCase;

public class TestSuite2 extends TestCase {

    public void test() {
        assertEquals(-1.0, new AstreeSub(new AstreeLit(1.0), new AstreeLit(2.0)).eval());
    }
}
