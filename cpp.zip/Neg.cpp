
#include "visitor.h" 
#include "Exp.h" 
#include "ExpVisitor.h" 
#include "Neg.h" 
  void Neg::Accept(ExpVisitor* visitor) const {
  exp_->Accept(visitor);
  visitor->VisitNeg(this);
  }
        