package algebra;

interface AddLitExpAlg<E> {

    E lit(final Double value);

    E add(final E left, final E right);
}
