package expression;

/**
 * A concrete visitor describes a concrete operation on expressions. There is one visit
 * method per type in the class hierarchy.
 */
public interface Visitor<R> {

    public R visit(Lit exp);

    public R visit(Add exp);
}
