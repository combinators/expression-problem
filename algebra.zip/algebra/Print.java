package algebra;

interface Print {

    String print();
}
