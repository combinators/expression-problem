package trivially;

public interface NegId extends ExpId {

    ExpId getInner();

    default Integer id() {
        return 78192;
    }
}
