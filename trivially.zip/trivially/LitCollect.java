package trivially;

public interface LitCollect extends ExpCollect, LitPrint {

    Double getValue();

    default java.util.List<Double> collect() {
        java.util.List<Double> list = new java.util.ArrayList<Double>();
        list.add(getValue());
        return list;
    }
}
