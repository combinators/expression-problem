package visitor;

public class IdzPower extends IdzSqrt implements VisitorPower<Integer> {

    public Integer visit(Power e) {
        return 77306085;
    }

    IdzPower makeIdz() {
        return new IdzPower();
    }
}
