package trivially;

public interface SubCopy extends ExpCopy, SubFind {

    ExpCopy getLeft();

    ExpCopy getRight();

    default ExpCopy copy() {
        return new Sub((FinalI) (getLeft().copy()), (FinalI) (getRight().copy()));
    }
}
