package interpreter;

public interface CollectSimplifyExp extends PrintExp {

    public CollectSimplifyExp simplify();

    public java.util.List<Double> collect();
}
