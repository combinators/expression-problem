package trivially;

public interface NegSimplify extends ExpSimplify, NegPrettyp {

    ExpSimplify getInner();

    default ExpSimplify simplify() {
        if (getInner().eval() == 0) {
            return new Lit(0.0);
        } else {
            return new Neg((FinalI) (getInner().simplify()));
        }
    }
}
