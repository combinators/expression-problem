package trivially;

public class Neg implements FinalI, NegSimplify, NegCollect {

    public Neg(FinalI inner) {
        this.inner = inner;
    }

    public FinalI getInner() {
        return this.inner;
    }

    private FinalI inner;
}
