package trivially;

public interface LitPrettyp extends ExpPrettyp, LitEval, LitId {

    Double getValue();

    default String prettyp() {
        return "" + getValue() + "";
    }
}
