package interpreter;

import static interpreter.CopyExpFactory.*;

public class CopyDivd extends FindDivd implements CopyExp {

    public CopyDivd(CopyExp left, CopyExp right) {
        super(left, right);
    }

    public CopyExp getLeft() {
        return (CopyExp) this.left;
    }

    public CopyExp getRight() {
        return (CopyExp) this.right;
    }

    public CopyExp copy() {
        return Divd(getLeft().copy(), getRight().copy());
    }
}
