package interpreter;

public interface FindExp extends EqualsExp {

    // All known data types up until this evolution.s
    interface KnownDataTypes<R> extends CollectSimplifyExp.KnownDataTypes<R> {

        R convert(CollectSimplifySqrt from);
    }

    public Integer find(Double target);
}
