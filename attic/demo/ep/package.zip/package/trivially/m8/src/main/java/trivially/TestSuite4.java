package trivially;

import junit.framework.TestCase;

public class TestSuite4 extends TestCase {

    public void test() {
        java.util.List<Double> tmpList8 = new java.util.ArrayList<>();
        tmpList8.add(new Double(5.0));
        tmpList8.add(new Double(7.0));
        tmpList8.add(new Double(7.0));
        tmpList8.add(new Double(2.0));
        tmpList8.add(new Double(3.0));
        assertEquals(tmpList8, new Divd((FinalI) (new Divd((FinalI) (new Lit(new Double(5.0))), (FinalI) (new Lit(new Double(7.0))))), (FinalI) (new Sub((FinalI) (new Lit(new Double(7.0))), (FinalI) (new Mult((FinalI) (new Lit(new Double(2.0))), (FinalI) (new Lit(new Double(3.0)))))))).collect());
        java.util.List<Double> tmpList9 = new java.util.ArrayList<>();
        tmpList9.add(new Double(0.0));
        tmpList9.add(new Double(0.0));
        assertEquals(tmpList9, new Add((FinalI) (new Lit(new Double(0.0))), (FinalI) (new Lit(new Double(0.0)))).collect());
        java.util.List<Double> tmpList10 = new java.util.ArrayList<>();
        tmpList10.add(new Double(0.0));
        assertEquals(tmpList10, new Neg((FinalI) (new Lit(new Double(0.0)))).collect());
        java.util.List<Double> tmpList11 = new java.util.ArrayList<>();
        tmpList11.add(new Double(1.0));
        tmpList11.add(new Double(12.0));
        assertEquals(tmpList11, new Mult((FinalI) (new Lit(new Double(1.0))), (FinalI) (new Lit(new Double(12.0)))).collect());
        java.util.List<Double> tmpList12 = new java.util.ArrayList<>();
        tmpList12.add(new Double(13.0));
        tmpList12.add(new Double(1.0));
        assertEquals(tmpList12, new Mult((FinalI) (new Lit(new Double(13.0))), (FinalI) (new Lit(new Double(1.0)))).collect());
        assertEquals("-1.0", new Neg((FinalI) (new Lit(new Double(1.0)))).prettyp());
        assertEquals("((5.0/2.0)*4.0)", new Mult((FinalI) (new Divd((FinalI) (new Lit(new Double(5.0))), (FinalI) (new Lit(new Double(2.0))))), (FinalI) (new Lit(new Double(4.0)))).prettyp());
        assertEquals(new Double(10.0), new Mult((FinalI) (new Divd((FinalI) (new Lit(new Double(5.0))), (FinalI) (new Lit(new Double(2.0))))), (FinalI) (new Lit(new Double(4.0)))).eval());
    }
}
