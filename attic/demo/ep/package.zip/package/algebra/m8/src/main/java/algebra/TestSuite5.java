package algebra;

import junit.framework.TestCase;

public class TestSuite5 extends TestCase {

    EqualsPowerExpAlg algebraEquals = new EqualsPowerExpAlg();

    AstreePowerExpAlg algebraAstree = new AstreePowerExpAlg();

    FindPowerExpAlg algebraFind = new FindPowerExpAlg();

    CollectPowerExpAlg algebraCollect = new CollectPowerExpAlg();

    EvalPowerExpAlg algebraEval = new EvalPowerExpAlg();

    PrettypPowerExpAlg algebraPrettyp = new PrettypPowerExpAlg();

    IdzPowerExpAlg algebraIdz = new IdzPowerExpAlg();

    CombinedExpAlg algebra = new CombinedExpAlg(algebraAstree, algebraCollect, algebraEquals, algebraEval, algebraFind, algebraIdz, algebraPrettyp);

    public void test() {
        assertEquals("(5.0+7.0)", algebra.add(algebra.add(algebra.lit(new Double(5.0)), algebra.lit(new Double(0.0))), algebra.add(algebra.lit(new Double(0.0)), algebra.lit(new Double(7.0)))).simplify().prettyp());
        assertEquals("(5.0/7.0)", algebra.divd(algebra.divd(algebra.lit(new Double(5.0)), algebra.lit(new Double(7.0))), algebra.sub(algebra.lit(new Double(7.0)), algebra.mult(algebra.lit(new Double(2.0)), algebra.lit(new Double(3.0))))).simplify().prettyp());
        assertEquals(new Double(0.0), algebra.neg(algebra.lit(new Double(0.0))).simplify().eval());
        assertEquals(new Double(5.0), algebra.add(algebra.lit(new Double(5.0)), algebra.lit(new Double(0.0))).simplify().eval());
        assertEquals(new Double(7.0), algebra.add(algebra.lit(new Double(0.0)), algebra.lit(new Double(7.0))).simplify().eval());
        assertEquals(new Double(13.0), algebra.mult(algebra.lit(new Double(13.0)), algebra.lit(new Double(1.0))).simplify().eval());
        assertEquals(new Double(12.0), algebra.mult(algebra.lit(new Double(1.0)), algebra.lit(new Double(12.0))).simplify().eval());
        assertEquals(new Double(0.0), algebra.sub(algebra.lit(new Double(7.0)), algebra.lit(new Double(7.0))).simplify().eval());
        assertEquals(new Double(-1.0), algebra.divd(algebra.lit(new Double(5.0)), algebra.lit(new Double(-5.0))).simplify().eval());
        assertEquals(new Double(1.0), algebra.divd(algebra.lit(new Double(-5.0)), algebra.lit(new Double(-5.0))).simplify().eval());
        assertEquals(new Double(0.0), algebra.divd(algebra.lit(new Double(0.0)), algebra.lit(new Double(-5.0))).simplify().eval());
    }
}
