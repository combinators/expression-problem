package oo;

import junit.framework.TestCase;

public class TestSuite8 extends TestCase {

    public void test() {
        assertEquals(new Double(5.0), new Sqrt(new Lit(new Double(25.0))).eval());
        assertEquals(new Integer(2), new Add(new Add(new Lit(new Double(1.0)), new Lit(new Double(2.0))), new Add(new Lit(new Double(1.0)), new Lit(new Double(2.0)))).find(new Double(1.0)));
    }
}
