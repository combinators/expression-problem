package trivially;

public interface PowerAstreeIdz extends ExpAstreeIdz, PowerCollectSimplify {

    ExpAstreeIdz getLeft();

    ExpAstreeIdz getRight();

    default tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getLeft().astree(), getRight().astree()), this.idz());
    }

    default Integer idz() {
        return 77306085;
    }
}
