package algebra;

interface DivdMultNegExpAlg<E> extends SubExpAlg<E> {

    E neg(final E inner);

    E mult(final E left, final E right);

    E divd(final E left, final E right);
}
