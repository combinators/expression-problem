package trivially;

public class Neg implements FinalI, NegCollect {

    public Neg(FinalI inner) {
        this.inner = inner;
    }

    public FinalI getInner() {
        return this.inner;
    }

    private FinalI inner;
}
