package oo;

public class Neg extends Exp {

    public Neg(Exp inner) {
        this.inner = inner;
    }

    private Exp inner;

    public Exp copy() {
        return new Neg(inner.copy());
    }

    public Integer find(Double target) {
        return inner.find(target);
    }

    public Boolean equals(Exp that) {
        return this.astree().same(that.astree());
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(inner.astree()), this.idz());
    }

    public Integer idz() {
        return 78192;
    }

    public Exp simplify() {
        if (inner.eval() == 0) {
            return new Lit(0.0);
        } else {
            return new Neg(inner.simplify());
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList2 = new java.util.ArrayList<>();
        tmpList2.addAll(inner.collect());
        return tmpList2;
    }

    public String prettyp() {
        return "-" + inner.prettyp();
    }

    public Double eval() {
        return -inner.eval();
    }
}
