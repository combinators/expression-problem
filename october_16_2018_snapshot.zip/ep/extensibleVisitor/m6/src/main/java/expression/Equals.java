package expression;

public class Equals implements VisitorDivdMultNeg<Boolean> {

    public Boolean visit(Neg e) {
        return e.astree().same(that.astree());
    }

    public Boolean visit(Mult e) {
        return e.astree().same(that.astree());
    }

    public Boolean visit(Divd e) {
        return e.astree().same(that.astree());
    }

    public Boolean visit(Sub e) {
        return e.astree().same(that.astree());
    }

    public Boolean visit(Lit e) {
        return e.astree().same(that.astree());
    }

    public Boolean visit(Add e) {
        return e.astree().same(that.astree());
    }

    public Equals(Exp that) {
        this.that = that;
    }

    Exp that;

    Equals makeEquals(Exp that) {
        return new Equals(that);
    }
}
