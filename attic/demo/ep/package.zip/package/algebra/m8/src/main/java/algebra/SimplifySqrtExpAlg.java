package algebra;

public class SimplifySqrtExpAlg extends SimplifyDivdMultNegExpAlg implements SqrtExpAlg<Simplify> {

    // Binary operations are passed in necessary algebra to work with
    CombinedExpAlg algebra;

    public SimplifySqrtExpAlg(CombinedExpAlg alg) {
        super(alg);
        this.algebra = alg;
    }

    public Simplify sqrt(final Simplify inner) {
        return () -> {
            return algebra.sqrt(inner.simplify());
        };
    }
}
