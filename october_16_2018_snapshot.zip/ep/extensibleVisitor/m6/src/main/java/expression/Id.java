package expression;

public class Id implements Visitor<Integer> {

    public Integer visit(Lit e) {
        return 76407;
    }

    public Integer visit(Add e) {
        return 65665;
    }

    Id makeId() {
        return new Id();
    }
}
