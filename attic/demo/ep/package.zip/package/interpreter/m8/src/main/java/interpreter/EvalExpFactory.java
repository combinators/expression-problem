package interpreter;

public class EvalExpFactory {

    public static EvalExp Power(EvalExp left, EvalExp right) {
        return new EvalPower(left, right);
    }

    public static EvalExp Sqrt(EvalExp inner) {
        return new EvalSqrt(inner);
    }

    public static EvalExp Neg(EvalExp inner) {
        return new EvalNeg(inner);
    }

    public static EvalExp Mult(EvalExp left, EvalExp right) {
        return new EvalMult(left, right);
    }

    public static EvalExp Divd(EvalExp left, EvalExp right) {
        return new EvalDivd(left, right);
    }

    public static EvalExp Sub(EvalExp left, EvalExp right) {
        return new EvalSub(left, right);
    }

    public static EvalExp Lit(Double value) {
        return new EvalLit(value);
    }

    public static EvalExp Add(EvalExp left, EvalExp right) {
        return new EvalAdd(left, right);
    }
}
