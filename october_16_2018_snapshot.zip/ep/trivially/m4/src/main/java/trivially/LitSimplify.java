package trivially;

public interface LitSimplify extends ExpSimplify, LitPrettyp {

    Double getValue();

    default ExpSimplify simplify() {
        return new Lit(getValue());
    }
}
