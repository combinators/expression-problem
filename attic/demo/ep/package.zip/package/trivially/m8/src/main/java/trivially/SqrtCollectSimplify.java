package trivially;

public interface SqrtCollectSimplify extends ExpCollectSimplify, SqrtPrettyp {

    ExpCollectSimplify getInner();

    default ExpCollectSimplify simplify() {
        return new Sqrt((FinalI) (getInner().simplify()));
    }

    default java.util.List<Double> collect() {
        java.util.List<Double> tmpList1 = new java.util.ArrayList<>();
        tmpList1.addAll(getInner().collect());
        return tmpList1;
    }
}
