package interpreter;

public class PrettypSqrt extends EvalSqrt implements PrettypExp {

    public PrettypSqrt(PrettypExp inner) {
        super(inner);
    }

    public PrettypExp getInner() {
        return (PrettypExp) this.inner;
    }

    public Double eval() {
        return Math.sqrt(getInner().eval());
    }

    public String prettyp() {
        return "Sqrt(" + getInner().prettyp() + ")";
    }
}
