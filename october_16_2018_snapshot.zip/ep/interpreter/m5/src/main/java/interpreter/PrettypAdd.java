package interpreter;

public class PrettypAdd extends EvalIdAdd implements PrettypExp {

    PrettypExp Sub(PrettypExp left, PrettypExp right) {
        return new PrettypSub(left, right);
    }

    PrettypExp Lit(Double value) {
        return new PrettypLit(value);
    }

    PrettypExp Add(PrettypExp left, PrettypExp right) {
        return new PrettypAdd(left, right);
    }

    public PrettypAdd(PrettypExp left, PrettypExp right) {
        super(left, right);
    }

    public PrettypExp getLeft() {
        return (PrettypExp) this.left;
    }

    public PrettypExp getRight() {
        return (PrettypExp) this.right;
    }

    public String prettyp() {
        return "(" + getLeft().prettyp() + "+" + getRight().prettyp() + ")";
    }
}
