package trivially;

public interface LitCollectSimplify extends ExpCollectSimplify, LitPrettyp {

    Double getValue();

    default ExpCollectSimplify simplify() {
        return new Lit(getValue());
    }

    default java.util.List<Double> collect() {
        java.util.List<Double> tmpList6 = new java.util.ArrayList<>();
        tmpList6.add(getValue());
        return tmpList6;
    }
}
