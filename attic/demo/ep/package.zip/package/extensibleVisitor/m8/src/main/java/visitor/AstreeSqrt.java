package visitor;

public class AstreeSqrt extends Astree implements VisitorSqrt<tree.Tree> {

    public tree.Tree visit(Sqrt e) {
        return new tree.Node(java.util.Arrays.asList(e.getInner().astree()), e.accept(makeIdz()));
    }

    AstreeSqrt makeAstree() {
        return new AstreeSqrt();
    }
}
