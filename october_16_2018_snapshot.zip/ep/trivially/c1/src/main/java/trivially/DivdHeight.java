package trivially;

public interface DivdHeight extends ExpHeight, DivdPrettyp {

    ExpHeight getLeft();

    ExpHeight getRight();

    default Integer height(Integer height) {
        return Math.max(getLeft().height(height + 1), getRight().height(height + 1));
    }
}
