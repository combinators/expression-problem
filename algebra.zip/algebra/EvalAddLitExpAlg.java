package algebra;

public class EvalAddLitExpAlg implements AddLitExpAlg<Eval> {

    public Eval lit(final Double value) {
        return new Eval() {

            public Double eval() {
                return value;
            }
        };
    }

    public Eval add(final Eval left, final Eval right) {
        return new Eval() {

            public Double eval() {
                return left.eval() + right.eval();
            }
        };
    }
}
