package interpreter;

public interface EqualsExp extends AstreeExp {

    public Boolean equals(EqualsExp that);
}
