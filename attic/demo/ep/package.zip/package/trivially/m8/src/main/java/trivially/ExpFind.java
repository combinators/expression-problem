package trivially;

public interface ExpFind extends ExpEquals {

    public Integer find(Double target);
}
