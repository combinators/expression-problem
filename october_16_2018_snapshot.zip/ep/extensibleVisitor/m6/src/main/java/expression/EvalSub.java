package expression;

public class EvalSub extends Eval implements VisitorSub<Double> {

    public Double visit(Sub e) {
        return e.getLeft().accept(makeEval()) - e.getRight().accept(makeEval());
    }

    Eval makeEval() {
        return new EvalSub();
    }
}
