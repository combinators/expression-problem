package expression;

public class Mult extends Exp {

    public Mult(Exp left, Exp right) {
        this.left = left;
        this.right = right;
    }

    private Exp left;

    private Exp right;

    public Exp getLeft() {
        return this.left;
    }

    public Exp getRight() {
        return this.right;
    }

    public <R> R accept(Visitor<R> v) {
        return v.visit(this);
    }
}
