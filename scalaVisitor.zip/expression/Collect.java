package expression;

public class Collect extends Visitor<java.util.List<Double>> {

    public java.util.List<Double> visit(Neg e) {
        java.util.List<Double> list = new java.util.ArrayList<Double>();
        list.addAll(e.getInner().accept(new Collect()));
        return list;
    }

    public java.util.List<Double> visit(Mult e) {
        java.util.List<Double> list = e.getLeft().accept(new Collect());
        list.addAll(e.getRight().accept(new Collect()));
        return list;
    }

    public java.util.List<Double> visit(Divd e) {
        java.util.List<Double> list = e.getLeft().accept(new Collect());
        list.addAll(e.getRight().accept(new Collect()));
        return list;
    }

    public java.util.List<Double> visit(Sub e) {
        java.util.List<Double> list = e.getLeft().accept(new Collect());
        list.addAll(e.getRight().accept(new Collect()));
        return list;
    }

    public java.util.List<Double> visit(Lit e) {
        java.util.List<Double> list = new java.util.ArrayList<Double>();
        list.add(e.getValue());
        return list;
    }

    public java.util.List<Double> visit(Add e) {
        java.util.List<Double> list = e.getLeft().accept(new Collect());
        list.addAll(e.getRight().accept(new Collect()));
        return list;
    }
}
