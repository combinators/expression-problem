package visitor;

public class Prettyp extends Visitor<String> {

    public String visit(Power e) {
        return "Power(" + e.getLeft().accept(new Prettyp()) + "," + e.getRight().accept(new Prettyp()) + ")";
    }

    public String visit(Sqrt e) {
        return "Sqrt(" + e.getInner().accept(new Prettyp()) + ")";
    }

    public String visit(Neg e) {
        return "-" + e.getInner().accept(new Prettyp());
    }

    public String visit(Mult e) {
        return "(" + e.getLeft().accept(new Prettyp()) + "*" + e.getRight().accept(new Prettyp()) + ")";
    }

    public String visit(Divd e) {
        return "(" + e.getLeft().accept(new Prettyp()) + "/" + e.getRight().accept(new Prettyp()) + ")";
    }

    public String visit(Sub e) {
        return "(" + e.getLeft().accept(new Prettyp()) + "-" + e.getRight().accept(new Prettyp()) + ")";
    }

    public String visit(Lit e) {
        return "" + e.getValue();
    }

    public String visit(Add e) {
        return "(" + e.getLeft().accept(new Prettyp()) + "+" + e.getRight().accept(new Prettyp()) + ")";
    }
}
