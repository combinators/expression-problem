package trivially;

public interface MultId extends ExpId {

    ExpId getLeft();

    ExpId getRight();

    default Integer id() {
        return 2409808;
    }
}
