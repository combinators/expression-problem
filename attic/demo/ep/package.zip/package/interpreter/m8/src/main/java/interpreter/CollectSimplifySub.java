package interpreter;

import static interpreter.CollectSimplifyExpFactory.*;

public class CollectSimplifySub extends PrettypSub implements CollectSimplifyExp {

    public CollectSimplifySub(CollectSimplifyExp left, CollectSimplifyExp right) {
        super(left, right);
    }

    public CollectSimplifyExp getLeft() {
        return (CollectSimplifyExp) this.left;
    }

    public CollectSimplifyExp getRight() {
        return (CollectSimplifyExp) this.right;
    }

    public CollectSimplifyExp simplify() {
        if (getLeft().eval() == getRight().eval()) {
            return Lit(0.0);
        } else {
            return Sub(getLeft().simplify(), getRight().simplify());
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList5 = new java.util.ArrayList<>();
        tmpList5.addAll(getLeft().collect());
        tmpList5.addAll(getRight().collect());
        return tmpList5;
    }

    @Override
    public <R> R accept(KnownDataTypes<R> from) {
        return from.convert(this);
    }
}
