package trivially;

public interface MultCopy extends ExpCopy, MultFind {

    ExpCopy getLeft();

    ExpCopy getRight();

    default ExpCopy copy() {
        return new Mult((FinalI) (getLeft().copy()), (FinalI) (getRight().copy()));
    }
}
