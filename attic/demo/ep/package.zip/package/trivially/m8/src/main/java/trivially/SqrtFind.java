package trivially;

public interface SqrtFind extends ExpFind, SqrtEquals {

    ExpFind getInner();

    default Integer find(Double target) {
        return getInner().find(target);
    }
}
