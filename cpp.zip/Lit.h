
#ifndef _Lit_
#define _Lit_

#include "visitor.h" 
#include "Exp.h" 
#include "ExpVisitor.h" 

class Lit : public Exp {
public:
  const double* getValue() const { return value_; }
  Lit (const double* value) : value_(value) {}
  void Accept(ExpVisitor* visitor) const;

private:
  const double* value_;
};
#endif /* _Lit_ */
       