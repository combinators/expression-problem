package trivially;

import junit.framework.TestCase;

public class TestSuite extends TestCase {

    public void test1() {
        assertEquals(3.0, new Add(new Lit(1.0), new Lit(2.0)).eval());
        assertEquals(5.0, new Lit(5.0).eval());
    }

    public void test2() {
        assertEquals(-1.0, new Sub(new Lit(1.0), new Lit(2.0)).eval());
    }

    public void test3() {
        assertEquals("(1.0-2.0)", new Sub(new Lit(1.0), new Lit(2.0)).print());
        assertEquals("((1.0-2.0)+(5.0+6.0))", new Add(new Sub(new Lit(1.0), new Lit(2.0)), new Add(new Lit(5.0), new Lit(6.0))).print());
    }

    public void test4() {
        assertEquals("-1.0", new Neg(new Lit(1.0)).print());
        assertEquals(-1.0, new Neg(new Lit(1.0)).eval());
        assertEquals("((5.0/2.0)*4.0)", new Mult(new Divd(new Lit(5.0), new Lit(2.0)), new Lit(4.0)).print());
        assertEquals("-5.0", new Neg(new Lit(5.0)).print());
        assertEquals("-(2.0*3.0)", new Neg(new Mult(new Lit(2.0), new Lit(3.0))).print());
    }

    public void test5() {
        // Handle collect checks
        java.util.List<Double> list1 = new Divd(new Divd(new Lit(5.0), new Lit(7.0)), new Sub(new Lit(7.0), new Mult(new Lit(2.0), new Lit(3.0)))).collect();
        java.util.List<Double> result = new java.util.ArrayList<Double>();
        result.add(5.0);
        result.add(7.0);
        result.add(7.0);
        result.add(2.0);
        result.add(3.0);
        assertEquals(list1, result);
    }
}
