package interpreter;

import static interpreter.CollectSimplifyExpFactory.*;

public class CollectSimplifyDivd extends PrettypDivd implements CollectSimplifyExp {

    public CollectSimplifyDivd(CollectSimplifyExp left, CollectSimplifyExp right) {
        super(left, right);
    }

    public CollectSimplifyExp getLeft() {
        return (CollectSimplifyExp) this.left;
    }

    public CollectSimplifyExp getRight() {
        return (CollectSimplifyExp) this.right;
    }

    public CollectSimplifyExp simplify() {
        double leftVal = getLeft().eval();
        double rightVal = getRight().eval();
        if (leftVal == 0) {
            return Lit(0.0);
        } else if (rightVal == 1) {
            return getLeft().simplify();
        } else if (leftVal == rightVal) {
            return Lit(1.0);
        } else if (leftVal == -rightVal) {
            return Lit(-1.0);
        } else {
            return Divd(getLeft().simplify(), getRight().simplify());
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList4 = new java.util.ArrayList<>();
        tmpList4.addAll(getLeft().collect());
        tmpList4.addAll(getRight().collect());
        return tmpList4;
    }

    @Override
    public <R> R accept(KnownDataTypes<R> from) {
        return from.convert(this);
    }
}
