package visitor;

public class Mult extends Exp {

    public Mult(Exp left, Exp right) {
        this.left = left;
        this.right = right;
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(left.astree(), right.astree()), 2409808);
    }

    private Exp left;

    private Exp right;

    public Exp getLeft() {
        return this.left;
    }

    public Exp getRight() {
        return this.right;
    }

    public <R> R accept(Visitor<R> v) {
        return v.visit(this);
    }
}
