package trivially;

public interface InvPrettyp extends ExpPrettyp, InvEval, InvId {

    ExpPrettyp getInner();

    default String prettyp() {
        return "(1.0/" + getInner().prettyp() + ")";
    }
}
