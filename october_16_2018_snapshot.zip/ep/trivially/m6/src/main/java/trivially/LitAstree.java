package trivially;

public interface LitAstree extends ExpAstree, LitSimplify, LitCollect {

    Double getValue();

    default tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(new tree.Leaf(getValue())), this.id());
    }
}
