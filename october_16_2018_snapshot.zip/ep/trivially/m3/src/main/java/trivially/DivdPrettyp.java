package trivially;

public interface DivdPrettyp extends ExpPrettyp, DivdEval, DivdId {

    ExpPrettyp getLeft();

    ExpPrettyp getRight();

    default String prettyp() {
        return "(" + getLeft().prettyp() + "/" + getRight().prettyp() + ")";
    }
}
