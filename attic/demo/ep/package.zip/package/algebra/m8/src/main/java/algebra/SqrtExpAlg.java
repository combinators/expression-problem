package algebra;

interface SqrtExpAlg<E> extends DivdMultNegExpAlg<E> {

    E sqrt(final E inner);
}
