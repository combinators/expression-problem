package interpreter;

import junit.framework.TestCase;

public class TestSuite7 extends TestCase {

    public void test() {
        assertFalse(new EqualsSub(new EqualsLit(1.0), new EqualsLit(2.0)).equals(new EqualsAdd(new EqualsSub(new EqualsLit(1.0), new EqualsLit(2.0)), new EqualsAdd(new EqualsLit(5.0), new EqualsLit(6.0)))));
        assertTrue(new EqualsSub(new EqualsLit(1.0), new EqualsLit(2.0)).equals(new EqualsSub(new EqualsLit(1.0), new EqualsLit(2.0))));
    }
}
