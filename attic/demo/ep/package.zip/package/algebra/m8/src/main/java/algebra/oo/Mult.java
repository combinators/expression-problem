package algebra.oo;

public class Mult extends Exp {

    public Mult(Exp left, Exp right) {
        this.left = left;
        this.right = right;
    }

    private Exp left;

    private Exp right;

    public algebra.CombinedExpAlg.Combined convert(algebra.CombinedExpAlg algebra) {
        return algebra.mult(left.convert(algebra), right.convert(algebra));
    }
}
