package algebra;

import junit.framework.TestCase;

public class TestSuite4 extends TestCase {

    EqualsPowerExpAlg algebraEquals = new EqualsPowerExpAlg();

    AstreePowerExpAlg algebraAstree = new AstreePowerExpAlg();

    FindPowerExpAlg algebraFind = new FindPowerExpAlg();

    CollectPowerExpAlg algebraCollect = new CollectPowerExpAlg();

    EvalPowerExpAlg algebraEval = new EvalPowerExpAlg();

    PrettypPowerExpAlg algebraPrettyp = new PrettypPowerExpAlg();

    IdzPowerExpAlg algebraIdz = new IdzPowerExpAlg();

    CombinedExpAlg algebra = new CombinedExpAlg(algebraAstree, algebraCollect, algebraEquals, algebraEval, algebraFind, algebraIdz, algebraPrettyp);

    public void test() {
        java.util.List<Double> tmpList8 = new java.util.ArrayList<>();
        tmpList8.add(new Double(5.0));
        tmpList8.add(new Double(7.0));
        tmpList8.add(new Double(7.0));
        tmpList8.add(new Double(2.0));
        tmpList8.add(new Double(3.0));
        assertEquals(tmpList8, algebra.divd(algebra.divd(algebra.lit(new Double(5.0)), algebra.lit(new Double(7.0))), algebra.sub(algebra.lit(new Double(7.0)), algebra.mult(algebra.lit(new Double(2.0)), algebra.lit(new Double(3.0))))).collect());
        java.util.List<Double> tmpList9 = new java.util.ArrayList<>();
        tmpList9.add(new Double(0.0));
        tmpList9.add(new Double(0.0));
        assertEquals(tmpList9, algebra.add(algebra.lit(new Double(0.0)), algebra.lit(new Double(0.0))).collect());
        java.util.List<Double> tmpList10 = new java.util.ArrayList<>();
        tmpList10.add(new Double(0.0));
        assertEquals(tmpList10, algebra.neg(algebra.lit(new Double(0.0))).collect());
        java.util.List<Double> tmpList11 = new java.util.ArrayList<>();
        tmpList11.add(new Double(1.0));
        tmpList11.add(new Double(12.0));
        assertEquals(tmpList11, algebra.mult(algebra.lit(new Double(1.0)), algebra.lit(new Double(12.0))).collect());
        java.util.List<Double> tmpList12 = new java.util.ArrayList<>();
        tmpList12.add(new Double(13.0));
        tmpList12.add(new Double(1.0));
        assertEquals(tmpList12, algebra.mult(algebra.lit(new Double(13.0)), algebra.lit(new Double(1.0))).collect());
        assertEquals("-1.0", algebra.neg(algebra.lit(new Double(1.0))).prettyp());
        assertEquals("((5.0/2.0)*4.0)", algebra.mult(algebra.divd(algebra.lit(new Double(5.0)), algebra.lit(new Double(2.0))), algebra.lit(new Double(4.0))).prettyp());
        assertEquals(new Double(10.0), algebra.mult(algebra.divd(algebra.lit(new Double(5.0)), algebra.lit(new Double(2.0))), algebra.lit(new Double(4.0))).eval());
    }
}
