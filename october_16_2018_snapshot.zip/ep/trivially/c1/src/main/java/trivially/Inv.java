package trivially;

public class Inv implements FinalI, InvHeight {

    public Inv(FinalI inner) {
        this.inner = inner;
    }

    public FinalI getInner() {
        return this.inner;
    }

    private FinalI inner;
}
