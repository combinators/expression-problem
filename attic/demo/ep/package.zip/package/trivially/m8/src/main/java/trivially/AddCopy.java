package trivially;

public interface AddCopy extends ExpCopy, AddFind {

    ExpCopy getLeft();

    ExpCopy getRight();

    default ExpCopy copy() {
        return new Add((FinalI) (getLeft().copy()), (FinalI) (getRight().copy()));
    }
}
