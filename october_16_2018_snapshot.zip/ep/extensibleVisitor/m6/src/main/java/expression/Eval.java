package expression;

public class Eval implements Visitor<Double> {

    public Double visit(Lit e) {
        return e.getValue();
    }

    public Double visit(Add e) {
        return e.getLeft().accept(makeEval()) + e.getRight().accept(makeEval());
    }

    Eval makeEval() {
        return new Eval();
    }
}
