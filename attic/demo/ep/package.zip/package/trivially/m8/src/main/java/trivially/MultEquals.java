package trivially;

public interface MultEquals extends ExpEquals, MultAstreeIdz {

    ExpEquals getLeft();

    ExpEquals getRight();

    default Boolean equals(ExpEquals that) {
        return this.astree().same(that.astree());
    }
}
