package trivially;

public interface NegFind extends ExpFind, NegEquals {

    ExpFind getInner();

    default Integer find(Double target) {
        return getInner().find(target);
    }
}
