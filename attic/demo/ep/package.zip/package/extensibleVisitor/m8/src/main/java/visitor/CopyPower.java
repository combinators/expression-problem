package visitor;

public class CopyPower implements VisitorPower<Exp> {

    public Exp visit(Sqrt e) {
        return new Sqrt(e.getInner().accept(makeCopy()));
    }

    public Exp visit(Neg e) {
        return new Neg(e.getInner().accept(makeCopy()));
    }

    public Exp visit(Mult e) {
        return new Mult(e.getLeft().accept(makeCopy()), e.getRight().accept(makeCopy()));
    }

    public Exp visit(Divd e) {
        return new Divd(e.getLeft().accept(makeCopy()), e.getRight().accept(makeCopy()));
    }

    public Exp visit(Sub e) {
        return new Sub(e.getLeft().accept(makeCopy()), e.getRight().accept(makeCopy()));
    }

    public Exp visit(Lit e) {
        return new Lit(e.getValue());
    }

    public Exp visit(Add e) {
        return new Add(e.getLeft().accept(makeCopy()), e.getRight().accept(makeCopy()));
    }

    public Exp visit(Power e) {
        return new Power(e.getLeft().accept(makeCopy()), e.getRight().accept(makeCopy()));
    }

    CopyPower makeCopy() {
        return new CopyPower();
    }
}
