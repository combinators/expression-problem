package algebra.oo;

public class Power extends Exp {

    public Power(Exp left, Exp right) {
        this.left = left;
        this.right = right;
    }

    private Exp left;

    private Exp right;

    public algebra.CombinedExpAlg.Combined convert(algebra.CombinedExpAlg algebra) {
        return algebra.power(left.convert(algebra), right.convert(algebra));
    }
}
