package visitor;

import junit.framework.TestCase;

public class TestSuite0 extends TestCase {

    public void test() {
        assertEquals(new Double(3.0), new Add(new Lit(new Double(1.0)), new Lit(new Double(2.0))).accept(new Eval()));
        assertEquals(new Double(5.0), new Lit(new Double(5.0)).accept(new Eval()));
        Exp cache0 = new Add(new Lit(new Double(1.0)), new Lit(new Double(2.0)));
        Exp cache1 = new Add(cache0, cache0);
        Exp cache2 = new Add(cache1, cache1);
        Exp cache3 = new Add(cache2, cache2);
        Exp cache4 = new Add(cache3, cache3);
        Exp cache5 = new Add(cache4, cache4);
        Exp cache6 = new Add(cache5, cache5);
        Exp cache7 = new Add(cache6, cache6);
        Exp cache8 = new Add(cache7, cache7);
        Exp cache9 = new Add(cache8, cache8);
        Exp cache10 = new Add(cache9, cache9);
        Exp cache11 = new Add(cache10, cache10);
        long now11 = System.nanoTime();
        cache11.accept(new Eval());
        long best11 = System.nanoTime() - now11;
        for (int i = 1; i < 8; i++) {
            now11 = System.nanoTime();
            cache11.accept(new Eval());
            long duration = System.nanoTime() - now11;
            if (duration < best11) {
                best11 = duration;
            }
        }
        System.out.println(11 + "," + best11);
        long now10 = System.nanoTime();
        cache10.accept(new Eval());
        long best10 = System.nanoTime() - now10;
        for (int i = 1; i < 8; i++) {
            now10 = System.nanoTime();
            cache10.accept(new Eval());
            long duration = System.nanoTime() - now10;
            if (duration < best10) {
                best10 = duration;
            }
        }
        System.out.println(10 + "," + best10);
        long now9 = System.nanoTime();
        cache9.accept(new Eval());
        long best9 = System.nanoTime() - now9;
        for (int i = 1; i < 8; i++) {
            now9 = System.nanoTime();
            cache9.accept(new Eval());
            long duration = System.nanoTime() - now9;
            if (duration < best9) {
                best9 = duration;
            }
        }
        System.out.println(9 + "," + best9);
        long now8 = System.nanoTime();
        cache8.accept(new Eval());
        long best8 = System.nanoTime() - now8;
        for (int i = 1; i < 8; i++) {
            now8 = System.nanoTime();
            cache8.accept(new Eval());
            long duration = System.nanoTime() - now8;
            if (duration < best8) {
                best8 = duration;
            }
        }
        System.out.println(8 + "," + best8);
        long now7 = System.nanoTime();
        cache7.accept(new Eval());
        long best7 = System.nanoTime() - now7;
        for (int i = 1; i < 8; i++) {
            now7 = System.nanoTime();
            cache7.accept(new Eval());
            long duration = System.nanoTime() - now7;
            if (duration < best7) {
                best7 = duration;
            }
        }
        System.out.println(7 + "," + best7);
        long now6 = System.nanoTime();
        cache6.accept(new Eval());
        long best6 = System.nanoTime() - now6;
        for (int i = 1; i < 8; i++) {
            now6 = System.nanoTime();
            cache6.accept(new Eval());
            long duration = System.nanoTime() - now6;
            if (duration < best6) {
                best6 = duration;
            }
        }
        System.out.println(6 + "," + best6);
        long now5 = System.nanoTime();
        cache5.accept(new Eval());
        long best5 = System.nanoTime() - now5;
        for (int i = 1; i < 8; i++) {
            now5 = System.nanoTime();
            cache5.accept(new Eval());
            long duration = System.nanoTime() - now5;
            if (duration < best5) {
                best5 = duration;
            }
        }
        System.out.println(5 + "," + best5);
        long now4 = System.nanoTime();
        cache4.accept(new Eval());
        long best4 = System.nanoTime() - now4;
        for (int i = 1; i < 8; i++) {
            now4 = System.nanoTime();
            cache4.accept(new Eval());
            long duration = System.nanoTime() - now4;
            if (duration < best4) {
                best4 = duration;
            }
        }
        System.out.println(4 + "," + best4);
        long now3 = System.nanoTime();
        cache3.accept(new Eval());
        long best3 = System.nanoTime() - now3;
        for (int i = 1; i < 8; i++) {
            now3 = System.nanoTime();
            cache3.accept(new Eval());
            long duration = System.nanoTime() - now3;
            if (duration < best3) {
                best3 = duration;
            }
        }
        System.out.println(3 + "," + best3);
        long now2 = System.nanoTime();
        cache2.accept(new Eval());
        long best2 = System.nanoTime() - now2;
        for (int i = 1; i < 8; i++) {
            now2 = System.nanoTime();
            cache2.accept(new Eval());
            long duration = System.nanoTime() - now2;
            if (duration < best2) {
                best2 = duration;
            }
        }
        System.out.println(2 + "," + best2);
        long now1 = System.nanoTime();
        cache1.accept(new Eval());
        long best1 = System.nanoTime() - now1;
        for (int i = 1; i < 8; i++) {
            now1 = System.nanoTime();
            cache1.accept(new Eval());
            long duration = System.nanoTime() - now1;
            if (duration < best1) {
                best1 = duration;
            }
        }
        System.out.println(1 + "," + best1);
        long now0 = System.nanoTime();
        cache0.accept(new Eval());
        long best0 = System.nanoTime() - now0;
        for (int i = 1; i < 8; i++) {
            now0 = System.nanoTime();
            cache0.accept(new Eval());
            long duration = System.nanoTime() - now0;
            if (duration < best0) {
                best0 = duration;
            }
        }
        System.out.println(0 + "," + best0);
    }
}
