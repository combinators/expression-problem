package interpreter;

public class FindExpFactory {

    public static FindExp Power(FindExp left, FindExp right) {
        return new FindPower(left, right);
    }

    public static FindExp Sqrt(FindExp inner) {
        return new FindSqrt(inner);
    }

    public static FindExp Neg(FindExp inner) {
        return new FindNeg(inner);
    }

    public static FindExp Mult(FindExp left, FindExp right) {
        return new FindMult(left, right);
    }

    public static FindExp Divd(FindExp left, FindExp right) {
        return new FindDivd(left, right);
    }

    public static FindExp Sub(FindExp left, FindExp right) {
        return new FindSub(left, right);
    }

    public static FindExp Lit(Double value) {
        return new FindLit(value);
    }

    public static FindExp Add(FindExp left, FindExp right) {
        return new FindAdd(left, right);
    }
}
