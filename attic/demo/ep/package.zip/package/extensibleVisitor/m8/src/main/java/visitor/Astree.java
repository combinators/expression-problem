package visitor;

public class Astree implements VisitorDivdMultNeg<tree.Tree> {

    public tree.Tree visit(Neg e) {
        return new tree.Node(java.util.Arrays.asList(e.getInner().astree()), e.accept(makeIdz()));
    }

    public tree.Tree visit(Mult e) {
        return new tree.Node(java.util.Arrays.asList(e.getLeft().astree(), e.getRight().astree()), e.accept(makeIdz()));
    }

    public tree.Tree visit(Divd e) {
        return new tree.Node(java.util.Arrays.asList(e.getLeft().astree(), e.getRight().astree()), e.accept(makeIdz()));
    }

    public tree.Tree visit(Sub e) {
        return new tree.Node(java.util.Arrays.asList(e.getLeft().astree(), e.getRight().astree()), e.accept(makeIdz()));
    }

    public tree.Tree visit(Lit e) {
        return new tree.Leaf(e.getValue());
    }

    public tree.Tree visit(Add e) {
        return new tree.Node(java.util.Arrays.asList(e.getLeft().astree(), e.getRight().astree()), e.accept(makeIdz()));
    }

    Astree makeAstree() {
        return new Astree();
    }

    Idz makeIdz() {
        return new Idz();
    }
}
