package expression;

public class Lit extends Exp {

    public Lit(Double value) {
        this.value = value;
    }

    private Double value;

    public Double getValue() {
        return this.value;
    }

    public <R> R accept(Visitor<R> v) {
        return v.visit(this);
    }
}
