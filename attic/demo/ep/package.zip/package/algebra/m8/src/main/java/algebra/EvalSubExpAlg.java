package algebra;

public class EvalSubExpAlg extends EvalAddLitExpAlg implements SubExpAlg<Eval> {

    public Eval sub(final Eval left, final Eval right) {
        return () -> {
            return left.eval() - right.eval();
        };
    }
}
