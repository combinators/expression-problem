package trivially;

import junit.framework.TestCase;

public class TestSuite2 extends TestCase {

    public void test() {
        assertEquals("(1.0-2.0)", new Sub((FinalI) (new Lit(new Double(1.0))), (FinalI) (new Lit(new Double(2.0)))).prettyp());
        assertEquals("((1.0-2.0)+(5.0+6.0))", new Add((FinalI) (new Sub((FinalI) (new Lit(new Double(1.0))), (FinalI) (new Lit(new Double(2.0))))), (FinalI) (new Add((FinalI) (new Lit(new Double(5.0))), (FinalI) (new Lit(new Double(6.0)))))).prettyp());
    }
}
