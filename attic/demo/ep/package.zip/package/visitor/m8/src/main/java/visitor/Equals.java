package visitor;

public class Equals extends Visitor<Boolean> {

    public Equals(Exp that) {
        this.that = that;
    }

    Exp that;

    public Boolean visit(Power e) {
        return e.accept(new Astree()).same(that.accept(new Astree()));
    }

    public Boolean visit(Sqrt e) {
        return e.accept(new Astree()).same(that.accept(new Astree()));
    }

    public Boolean visit(Neg e) {
        return e.accept(new Astree()).same(that.accept(new Astree()));
    }

    public Boolean visit(Mult e) {
        return e.accept(new Astree()).same(that.accept(new Astree()));
    }

    public Boolean visit(Divd e) {
        return e.accept(new Astree()).same(that.accept(new Astree()));
    }

    public Boolean visit(Sub e) {
        return e.accept(new Astree()).same(that.accept(new Astree()));
    }

    public Boolean visit(Lit e) {
        return e.accept(new Astree()).same(that.accept(new Astree()));
    }

    public Boolean visit(Add e) {
        return e.accept(new Astree()).same(that.accept(new Astree()));
    }
}
