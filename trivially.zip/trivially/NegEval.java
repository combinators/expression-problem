package trivially;

public interface NegEval extends ExpEval {

    ExpEval getInner();

    default Double eval() {
        return -getInner().eval();
    }
}
