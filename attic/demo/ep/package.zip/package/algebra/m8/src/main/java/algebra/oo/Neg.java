package algebra.oo;

public class Neg extends Exp {

    public Neg(Exp inner) {
        this.inner = inner;
    }

    private Exp inner;

    public algebra.CombinedExpAlg.Combined convert(algebra.CombinedExpAlg algebra) {
        return algebra.neg(inner.convert(algebra));
    }
}
