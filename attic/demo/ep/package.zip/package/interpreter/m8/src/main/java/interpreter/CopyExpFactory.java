package interpreter;

public class CopyExpFactory {

    public static CopyExp Power(CopyExp left, CopyExp right) {
        return new CopyPower(left, right);
    }

    public static CopyExp Sqrt(CopyExp inner) {
        return new CopySqrt(inner);
    }

    public static CopyExp Neg(CopyExp inner) {
        return new CopyNeg(inner);
    }

    public static CopyExp Mult(CopyExp left, CopyExp right) {
        return new CopyMult(left, right);
    }

    public static CopyExp Divd(CopyExp left, CopyExp right) {
        return new CopyDivd(left, right);
    }

    public static CopyExp Sub(CopyExp left, CopyExp right) {
        return new CopySub(left, right);
    }

    public static CopyExp Lit(Double value) {
        return new CopyLit(value);
    }

    public static CopyExp Add(CopyExp left, CopyExp right) {
        return new CopyAdd(left, right);
    }
}
