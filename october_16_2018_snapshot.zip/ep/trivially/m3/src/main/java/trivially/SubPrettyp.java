package trivially;

public interface SubPrettyp extends ExpPrettyp, SubEval, SubId {

    ExpPrettyp getLeft();

    ExpPrettyp getRight();

    default String prettyp() {
        return "(" + getLeft().prettyp() + "-" + getRight().prettyp() + ")";
    }
}
