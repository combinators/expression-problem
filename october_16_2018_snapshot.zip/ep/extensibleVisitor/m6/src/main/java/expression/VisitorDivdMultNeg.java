package expression;

/**
 * A concrete visitor describes a concrete operation on expressions. There is one visit
 * method per type in the class hierarchy.
 */
public interface VisitorDivdMultNeg<R> extends VisitorSub<R> {

    public R visit(Neg exp);

    public R visit(Mult exp);

    public R visit(Divd exp);
}
