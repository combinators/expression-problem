package visitor;

public class IdzSqrt extends Idz implements VisitorSqrt<Integer> {

    public Integer visit(Sqrt e) {
        return 2584896;
    }

    IdzSqrt makeIdz() {
        return new IdzSqrt();
    }
}
