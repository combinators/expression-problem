package trivially;

public interface MultCollect extends ExpCollect, MultPrettyp {

    ExpCollect getLeft();

    ExpCollect getRight();

    default java.util.List<Double> collect() {
        java.util.List<Double> list = getLeft().collect();
        list.addAll(getRight().collect());
        return list;
    }
}
