package visitor;

public interface VisitorPower<R> extends VisitorSqrt<R> {

    public R visit(Power exp);
}
