package interpreter;

public interface PrettypExp extends EvalIdExp {

    public String prettyp();
}
