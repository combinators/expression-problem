package trivially;

public interface ExpHeight extends ExpPrettyp {

    public Integer height(Integer height);
}
