package interpreter;

public interface AstreeIdzExp extends CollectSimplifyExp {

    public tree.Tree astree();

    public Integer idz();
}
