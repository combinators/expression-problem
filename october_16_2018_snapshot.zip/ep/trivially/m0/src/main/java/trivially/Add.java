package trivially;

public class Add implements FinalI, AddEval, AddId {

    public Add(FinalI left, FinalI right) {
        this.left = left;
        this.right = right;
    }

    public FinalI getLeft() {
        return this.left;
    }

    public FinalI getRight() {
        return this.right;
    }

    private FinalI left;

    private FinalI right;
}
