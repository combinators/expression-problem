package visitor;

public interface VisitorSub<R> extends Visitor<R> {

    public R visit(Sub exp);
}
