package algebra;

public class FindSqrtExpAlg implements SqrtExpAlg<Find> {

    public Find sqrt(final Find inner) {
        return (Double target) -> {
            return inner.find(target);
        };
    }

    public Find neg(final Find inner) {
        return (Double target) -> {
            return inner.find(target);
        };
    }

    public Find mult(final Find left, final Find right) {
        return (Double target) -> {
            return left.find(target) + right.find(target);
        };
    }

    public Find divd(final Find left, final Find right) {
        return (Double target) -> {
            return left.find(target) + right.find(target);
        };
    }

    public Find sub(final Find left, final Find right) {
        return (Double target) -> {
            return left.find(target) + right.find(target);
        };
    }

    public Find lit(final Double value) {
        return (Double target) -> {
            double _litEval = value;
            if (_litEval == target) {
                return 1;
            } else {
                return 0;
            }
        };
    }

    public Find add(final Find left, final Find right) {
        return (Double target) -> {
            return left.find(target) + right.find(target);
        };
    }
}
