package trivially;

public interface DivdCollectSimplify extends ExpCollectSimplify, DivdPrettyp {

    ExpCollectSimplify getLeft();

    ExpCollectSimplify getRight();

    default ExpCollectSimplify simplify() {
        double leftVal = getLeft().eval();
        double rightVal = getRight().eval();
        if (leftVal == 0) {
            return new Lit(0.0);
        } else if (rightVal == 1) {
            return getLeft().simplify();
        } else if (leftVal == rightVal) {
            return new Lit(1.0);
        } else if (leftVal == -rightVal) {
            return new Lit(-1.0);
        } else {
            return new Divd((FinalI) (getLeft().simplify()), (FinalI) (getRight().simplify()));
        }
    }

    default java.util.List<Double> collect() {
        java.util.List<Double> tmpList4 = new java.util.ArrayList<>();
        tmpList4.addAll(getLeft().collect());
        tmpList4.addAll(getRight().collect());
        return tmpList4;
    }
}
