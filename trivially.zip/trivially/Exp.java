package trivially;

public interface Exp {
}
