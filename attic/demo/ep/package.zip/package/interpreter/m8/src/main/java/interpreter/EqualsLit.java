package interpreter;

public class EqualsLit extends AstreeIdzLit implements EqualsExp {

    public EqualsLit(Double value) {
        super(value);
    }

    public Double getValue() {
        return this.value;
    }

    public Boolean equals(EqualsExp that) {
        return this.astree().same(that.astree());
    }
}
