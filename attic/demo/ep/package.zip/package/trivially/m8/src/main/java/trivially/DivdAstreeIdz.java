package trivially;

public interface DivdAstreeIdz extends ExpAstreeIdz, DivdCollectSimplify {

    ExpAstreeIdz getLeft();

    ExpAstreeIdz getRight();

    default tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getLeft().astree(), getRight().astree()), this.idz());
    }

    default Integer idz() {
        return 2130451;
    }
}
