package algebra;

public class IdzPowerExpAlg extends IdzSqrtExpAlg implements PowerExpAlg<Idz> {

    public Idz power(final Idz left, final Idz right) {
        return () -> {
            return 77306085;
        };
    }
}
