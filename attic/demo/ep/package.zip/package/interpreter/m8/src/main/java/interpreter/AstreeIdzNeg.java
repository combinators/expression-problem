package interpreter;

public class AstreeIdzNeg extends CollectSimplifyNeg implements AstreeIdzExp {

    public AstreeIdzNeg(AstreeIdzExp inner) {
        super(inner);
    }

    public AstreeIdzExp getInner() {
        return (AstreeIdzExp) this.inner;
    }

    public tree.Tree astree() {
        return new tree.Node(java.util.Arrays.asList(getInner().astree()), this.idz());
    }

    public Integer idz() {
        return 78192;
    }
}
