package visitor;

/*
 * A concrete visitor describes a concrete operation on expressions. There is one visit
 * method per type in the class hierarchy.
 */
public abstract class Visitor<R> {

    public abstract R visit(Power exp);

    public abstract R visit(Sqrt exp);

    public abstract R visit(Neg exp);

    public abstract R visit(Mult exp);

    public abstract R visit(Divd exp);

    public abstract R visit(Sub exp);

    public abstract R visit(Lit exp);

    public abstract R visit(Add exp);
}
