package trivially;

public interface SubId extends ExpId {

    ExpId getLeft();

    ExpId getRight();

    default Integer id() {
        return 83488;
    }
}
