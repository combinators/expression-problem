package visitor;

import junit.framework.TestCase;

public class TestSuite1 extends TestCase {

    public void test() {
        assertEquals(new Double(-1.0), new Sub(new Lit(new Double(1.0)), new Lit(new Double(2.0))).accept(new Eval()));
    }
}
