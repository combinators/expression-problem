package trivially;

public interface PowerFind extends ExpFind, PowerEquals {

    ExpFind getLeft();

    ExpFind getRight();

    default Integer find(Double target) {
        return getLeft().find(target) + getRight().find(target);
    }
}
