package trivially;

public interface MultPrettyp extends ExpPrettyp, MultEval {

    ExpPrettyp getLeft();

    ExpPrettyp getRight();

    default String prettyp() {
        return "(" + getLeft().prettyp() + "*" + getRight().prettyp() + ")";
    }
}
