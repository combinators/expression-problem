package trivially;

public interface ExpEquals extends ExpAstreeIdz {

    public Boolean equals(ExpEquals that);
}
