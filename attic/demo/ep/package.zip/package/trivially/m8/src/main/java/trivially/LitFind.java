package trivially;

public interface LitFind extends ExpFind, LitEquals {

    Double getValue();

    default Integer find(Double target) {
        double _litEval = getValue();
        if (_litEval == target) {
            return 1;
        } else {
            return 0;
        }
    }
}
