package trivially;

public interface NegCopy extends ExpCopy, NegFind {

    ExpCopy getInner();

    default ExpCopy copy() {
        return new Neg((FinalI) (getInner().copy()));
    }
}
