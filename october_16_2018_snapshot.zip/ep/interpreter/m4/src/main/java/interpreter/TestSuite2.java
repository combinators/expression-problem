package interpreter;

import junit.framework.TestCase;

public class TestSuite2 extends TestCase {

    public void test() {
        assertEquals(-1.0, new CollectSimplifySub(new CollectSimplifyLit(1.0), new CollectSimplifyLit(2.0)).eval());
    }
}
