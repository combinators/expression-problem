

#include "visitor.h"
#include "Exp.h"
#include "ExpVisitor.h"
#include "PrettyP.h"
#include "Eval.h"
         
int main() {
    double val0 = 0;
  double val1 = 1;
  double valn1 = -1;
  double valn2 = -2;
  double val2 = 2;
  double val3 = 3;
  Lit zer   = Lit(&val0);
  Lit one   = Lit(&val1);
  Lit two   = Lit(&val2);
  Lit three = Lit(&val3);
  Lit neg1 = Lit(&valn1);
  Lit neg2 = Lit(&valn2);

  Add four = Add(&one, &two);

  Add inner = Add(&neg1, &neg2);
  Add onlyAdd = Add(&three, &inner);

  Add combined = Add(new Add(new Lit(&valn1), new Lit(&val1)), new Lit(&val2));

  PrettyP pp;
  onlyAdd.Accept(&pp);
  std::cout << pp.getValue(onlyAdd) << std::endl;

  Eval e;
  onlyAdd.Accept(&e);
  std::cout << e.getValue(onlyAdd) << std::endl;

  return 0;

}