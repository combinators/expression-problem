package interpreter;

import static interpreter.CopyExpFactory.*;

public class CopyAdd extends FindAdd implements CopyExp {

    public CopyAdd(CopyExp left, CopyExp right) {
        super(left, right);
    }

    public CopyExp getLeft() {
        return (CopyExp) this.left;
    }

    public CopyExp getRight() {
        return (CopyExp) this.right;
    }

    public CopyExp copy() {
        return Add(getLeft().copy(), getRight().copy());
    }
}
