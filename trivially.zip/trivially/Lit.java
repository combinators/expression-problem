package trivially;

public class Lit implements FinalI, LitCollect {

    public Lit(Double value) {
        this.value = value;
    }

    public Double getValue() {
        return this.value;
    }

    private Double value;
}
