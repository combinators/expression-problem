package interpreter;

public class EvalLit implements EvalExp {

    EvalExp Lit(Double value) {
        return new EvalLit(value);
    }

    EvalExp Add(EvalExp left, EvalExp right) {
        return new EvalAdd(left, right);
    }

    public EvalLit(Double value) {
        this.value = value;
    }

    public Double getValue() {
        return this.value;
    }

    Double value;

    public Double eval() {
        return getValue();
    }
}
