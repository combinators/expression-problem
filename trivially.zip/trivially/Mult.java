package trivially;

public class Mult implements FinalI, MultCollect {

    public Mult(FinalI left, FinalI right) {
        this.left = left;
        this.right = right;
    }

    public FinalI getLeft() {
        return this.left;
    }

    public FinalI getRight() {
        return this.right;
    }

    private FinalI left;

    private FinalI right;
}
