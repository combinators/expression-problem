package interpreter;

public class CollectSimplifyMult extends PrettypMult implements CollectSimplifyExp {

    CollectSimplifyExp Neg(CollectSimplifyExp inner) {
        return new CollectSimplifyNeg(inner);
    }

    CollectSimplifyExp Mult(CollectSimplifyExp left, CollectSimplifyExp right) {
        return new CollectSimplifyMult(left, right);
    }

    CollectSimplifyExp Divd(CollectSimplifyExp left, CollectSimplifyExp right) {
        return new CollectSimplifyDivd(left, right);
    }

    CollectSimplifyExp Sub(CollectSimplifyExp left, CollectSimplifyExp right) {
        return new CollectSimplifySub(left, right);
    }

    CollectSimplifyExp Lit(Double value) {
        return new CollectSimplifyLit(value);
    }

    CollectSimplifyExp Add(CollectSimplifyExp left, CollectSimplifyExp right) {
        return new CollectSimplifyAdd(left, right);
    }

    public CollectSimplifyMult(CollectSimplifyExp left, CollectSimplifyExp right) {
        super(left, right);
    }

    public CollectSimplifyExp getLeft() {
        return (CollectSimplifyExp) this.left;
    }

    public CollectSimplifyExp getRight() {
        return (CollectSimplifyExp) this.right;
    }

    public CollectSimplifyExp simplify() {
        double leftVal = getLeft().eval();
        double rightVal = getRight().eval();
        if (leftVal == 0 || rightVal == 0) {
            return Lit(0.0);
        } else if (leftVal == 1) {
            return getRight().simplify();
        } else if (rightVal == 1) {
            return getLeft().simplify();
        } else {
            return Mult(getLeft().simplify(), getRight().simplify());
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> list = getLeft().collect();
        list.addAll(getRight().collect());
        return list;
    }
}
