package expression;

public class Neg extends Exp {

    public Neg(Exp inner) {
        this.inner = inner;
    }

    private Exp inner;

    public Exp getInner() {
        return this.inner;
    }

    public <R> R accept(Visitor<R> v) {
        return v.visit(this);
    }
}
