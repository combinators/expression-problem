package trivially;

public interface ExpId extends Exp {

    public Integer id();
}
