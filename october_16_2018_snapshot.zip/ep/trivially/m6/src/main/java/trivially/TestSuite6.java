package trivially;

import junit.framework.TestCase;

public class TestSuite6 extends TestCase {

    public void test() {
        assertFalse(new Sub(new Lit(1.0), new Lit(2.0)).astree().same(new Sub(new Lit(9.0), new Lit(112.0)).astree()));
        assertTrue(new Sub(new Lit(1.0), new Lit(2.0)).astree().same(new Sub(new Lit(1.0), new Lit(2.0)).astree()));
    }
}
