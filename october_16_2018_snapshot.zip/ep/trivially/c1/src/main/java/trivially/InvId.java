package trivially;

public interface InvId extends ExpId {

    ExpId getInner();

    default Integer id() {
        return 73681;
    }
}
