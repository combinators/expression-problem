package interpreter;

import static interpreter.CopyExpFactory.*;

public class CopyPower extends FindPower implements CopyExp {

    public CopyPower(CopyExp left, CopyExp right) {
        super(left, right);
    }

    public CopyExp getLeft() {
        return (CopyExp) this.left;
    }

    public CopyExp getRight() {
        return (CopyExp) this.right;
    }

    public CopyExp copy() {
        return Power(getLeft().copy(), getRight().copy());
    }
}
