package visitor;

public class Collect extends Visitor<java.util.List<Double>> {

    public java.util.List<Double> visit(Power e) {
        java.util.List<Double> tmpList0 = new java.util.ArrayList<>();
        tmpList0.addAll(e.getLeft().accept(new Collect()));
        tmpList0.addAll(e.getRight().accept(new Collect()));
        return tmpList0;
    }

    public java.util.List<Double> visit(Sqrt e) {
        java.util.List<Double> tmpList1 = new java.util.ArrayList<>();
        tmpList1.addAll(e.getInner().accept(new Collect()));
        return tmpList1;
    }

    public java.util.List<Double> visit(Neg e) {
        java.util.List<Double> tmpList2 = new java.util.ArrayList<>();
        tmpList2.addAll(e.getInner().accept(new Collect()));
        return tmpList2;
    }

    public java.util.List<Double> visit(Mult e) {
        java.util.List<Double> tmpList3 = new java.util.ArrayList<>();
        tmpList3.addAll(e.getLeft().accept(new Collect()));
        tmpList3.addAll(e.getRight().accept(new Collect()));
        return tmpList3;
    }

    public java.util.List<Double> visit(Divd e) {
        java.util.List<Double> tmpList4 = new java.util.ArrayList<>();
        tmpList4.addAll(e.getLeft().accept(new Collect()));
        tmpList4.addAll(e.getRight().accept(new Collect()));
        return tmpList4;
    }

    public java.util.List<Double> visit(Sub e) {
        java.util.List<Double> tmpList5 = new java.util.ArrayList<>();
        tmpList5.addAll(e.getLeft().accept(new Collect()));
        tmpList5.addAll(e.getRight().accept(new Collect()));
        return tmpList5;
    }

    public java.util.List<Double> visit(Lit e) {
        java.util.List<Double> tmpList6 = new java.util.ArrayList<>();
        tmpList6.add(e.getValue());
        return tmpList6;
    }

    public java.util.List<Double> visit(Add e) {
        java.util.List<Double> tmpList7 = new java.util.ArrayList<>();
        tmpList7.addAll(e.getLeft().accept(new Collect()));
        tmpList7.addAll(e.getRight().accept(new Collect()));
        return tmpList7;
    }
}
