package interpreter;

public class PrettypNeg extends EvalNeg implements PrettypExp {

    public PrettypNeg(PrettypExp inner) {
        super(inner);
    }

    public PrettypExp getInner() {
        return (PrettypExp) this.inner;
    }

    public Double eval() {
        return -getInner().eval();
    }

    public String prettyp() {
        return "-" + getInner().prettyp();
    }
}
