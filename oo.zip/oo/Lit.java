package oo;

public class Lit extends Exp {

    public Lit(Double value) {
        this.value = value;
    }

    private Double value;

    public Exp simplify() {
        return new Lit(value);
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> list = new java.util.ArrayList<Double>();
        list.add(value);
        return list;
    }

    public String print() {
        return "" + value + "";
    }

    public Double eval() {
        return value;
    }
}
