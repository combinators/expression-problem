package trivially;

public interface AddCollect extends ExpCollect, AddPrettyp {

    ExpCollect getLeft();

    ExpCollect getRight();

    default java.util.List<Double> collect() {
        java.util.List<Double> list = getLeft().collect();
        list.addAll(getRight().collect());
        return list;
    }
}
