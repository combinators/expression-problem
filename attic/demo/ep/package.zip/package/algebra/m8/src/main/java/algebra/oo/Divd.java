package algebra.oo;

public class Divd extends Exp {

    public Divd(Exp left, Exp right) {
        this.left = left;
        this.right = right;
    }

    private Exp left;

    private Exp right;

    public algebra.CombinedExpAlg.Combined convert(algebra.CombinedExpAlg algebra) {
        return algebra.divd(left.convert(algebra), right.convert(algebra));
    }
}
