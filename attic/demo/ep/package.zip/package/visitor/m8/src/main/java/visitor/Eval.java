package visitor;

public class Eval extends Visitor<Double> {

    public Double visit(Power e) {
        return Math.pow(e.getLeft().accept(new Eval()), e.getRight().accept(new Eval()));
    }

    public Double visit(Sqrt e) {
        return Math.sqrt(e.getInner().accept(new Eval()));
    }

    public Double visit(Neg e) {
        return -e.getInner().accept(new Eval());
    }

    public Double visit(Mult e) {
        return e.getLeft().accept(new Eval()) * e.getRight().accept(new Eval());
    }

    public Double visit(Divd e) {
        return e.getLeft().accept(new Eval()) / e.getRight().accept(new Eval());
    }

    public Double visit(Sub e) {
        return e.getLeft().accept(new Eval()) - e.getRight().accept(new Eval());
    }

    public Double visit(Lit e) {
        return e.getValue();
    }

    public Double visit(Add e) {
        return e.getLeft().accept(new Eval()) + e.getRight().accept(new Eval());
    }
}
