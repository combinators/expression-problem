package interpreter;

import static interpreter.CopyExpFactory.*;

public class CopyMult extends FindMult implements CopyExp {

    public CopyMult(CopyExp left, CopyExp right) {
        super(left, right);
    }

    public CopyExp getLeft() {
        return (CopyExp) this.left;
    }

    public CopyExp getRight() {
        return (CopyExp) this.right;
    }

    public CopyExp copy() {
        return Mult(getLeft().copy(), getRight().copy());
    }
}
