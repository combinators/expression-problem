package interpreter;

public class EqualsNeg extends AstreeIdzNeg implements EqualsExp {

    public EqualsNeg(EqualsExp inner) {
        super(inner);
    }

    public EqualsExp getInner() {
        return (EqualsExp) this.inner;
    }

    public Boolean equals(EqualsExp that) {
        return this.astree().same(that.astree());
    }
}
