package expression;

import junit.framework.TestCase;

public class TestSuite7 extends TestCase {

    public void test() {
        assertFalse(new Sub(new Lit(1.0), new Lit(2.0)).accept(makeEquals(new Add(new Sub(new Lit(1.0), new Lit(2.0)), new Add(new Lit(5.0), new Lit(6.0))))));
        assertTrue(new Sub(new Lit(1.0), new Lit(2.0)).accept(makeEquals(new Sub(new Lit(1.0), new Lit(2.0)))));
    }

    Equals makeEquals(Exp that) {
        return new Equals(that);
    }

    Astree makeAstree() {
        return new Astree();
    }

    Simplify makeSimplify() {
        return new Simplify();
    }

    Collect makeCollect() {
        return new Collect();
    }

    Prettyp makePrettyp() {
        return new PrettypDivdMultNeg();
    }

    Eval makeEval() {
        return new EvalDivdMultNeg();
    }

    Id makeId() {
        return new IdDivdMultNeg();
    }
}
