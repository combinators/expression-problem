package interpreter;

import junit.framework.TestCase;

public class TestSuite3 extends TestCase {

    public void test() {
        assertEquals("(1.0-2.0)", new PrettypSub(new PrettypLit(1.0), new PrettypLit(2.0)).prettyp());
        assertEquals("((1.0-2.0)+(5.0+6.0))", new PrettypAdd(new PrettypSub(new PrettypLit(1.0), new PrettypLit(2.0)), new PrettypAdd(new PrettypLit(5.0), new PrettypLit(6.0))).prettyp());
    }
}
