package trivially;

public interface SubCollectSimplify extends ExpCollectSimplify, SubPrettyp {

    ExpCollectSimplify getLeft();

    ExpCollectSimplify getRight();

    default ExpCollectSimplify simplify() {
        if (getLeft().eval() == getRight().eval()) {
            return new Lit(0.0);
        } else {
            return new Sub((FinalI) (getLeft().simplify()), (FinalI) (getRight().simplify()));
        }
    }

    default java.util.List<Double> collect() {
        java.util.List<Double> tmpList5 = new java.util.ArrayList<>();
        tmpList5.addAll(getLeft().collect());
        tmpList5.addAll(getRight().collect());
        return tmpList5;
    }
}
