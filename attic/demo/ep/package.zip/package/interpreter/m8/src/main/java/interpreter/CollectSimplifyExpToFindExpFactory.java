package interpreter;

public class CollectSimplifyExpToFindExpFactory implements FindExp.KnownDataTypes<FindExp> {

    @Override
    public FindSqrt convert(CollectSimplifySqrt from) {
        return new FindSqrt(from.getInner().accept(this));
    }

    @Override
    public FindNeg convert(CollectSimplifyNeg from) {
        return new FindNeg(from.getInner().accept(this));
    }

    @Override
    public FindMult convert(CollectSimplifyMult from) {
        return new FindMult(from.getLeft().accept(this), from.getRight().accept(this));
    }

    @Override
    public FindDivd convert(CollectSimplifyDivd from) {
        return new FindDivd(from.getLeft().accept(this), from.getRight().accept(this));
    }

    @Override
    public FindSub convert(CollectSimplifySub from) {
        return new FindSub(from.getLeft().accept(this), from.getRight().accept(this));
    }

    @Override
    public FindLit convert(CollectSimplifyLit from) {
        return new FindLit(from.getValue());
    }

    @Override
    public FindAdd convert(CollectSimplifyAdd from) {
        return new FindAdd(from.getLeft().accept(this), from.getRight().accept(this));
    }
}
