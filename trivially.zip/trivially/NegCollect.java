package trivially;

public interface NegCollect extends ExpCollect, NegPrint {

    ExpCollect getInner();

    default java.util.List<Double> collect() {
        java.util.List<Double> list = new java.util.ArrayList<Double>();
        list.addAll(getInner().collect());
        return list;
    }
}
