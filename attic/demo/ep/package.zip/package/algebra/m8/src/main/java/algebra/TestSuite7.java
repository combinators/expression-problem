package algebra;

import junit.framework.TestCase;

public class TestSuite7 extends TestCase {

    EqualsPowerExpAlg algebraEquals = new EqualsPowerExpAlg();

    AstreePowerExpAlg algebraAstree = new AstreePowerExpAlg();

    FindPowerExpAlg algebraFind = new FindPowerExpAlg();

    CollectPowerExpAlg algebraCollect = new CollectPowerExpAlg();

    EvalPowerExpAlg algebraEval = new EvalPowerExpAlg();

    PrettypPowerExpAlg algebraPrettyp = new PrettypPowerExpAlg();

    IdzPowerExpAlg algebraIdz = new IdzPowerExpAlg();

    CombinedExpAlg algebra = new CombinedExpAlg(algebraAstree, algebraCollect, algebraEquals, algebraEval, algebraFind, algebraIdz, algebraPrettyp);

    public void test() {
        assertTrue(algebra.sub(algebra.lit(new Double(1.0)), algebra.lit(new Double(73.0))).equals(algebra.sub(algebra.lit(new Double(1.0)), algebra.lit(new Double(73.0)))));
        assertFalse(algebra.mult(algebra.divd(algebra.lit(new Double(5.0)), algebra.lit(new Double(2.0))), algebra.lit(new Double(4.0))).equals(algebra.mult(algebra.divd(algebra.lit(new Double(5.0)), algebra.lit(new Double(2.0))), algebra.lit(new Double(3.0)))));
        assertTrue(algebra.mult(algebra.divd(algebra.lit(new Double(5.0)), algebra.lit(new Double(2.0))), algebra.lit(new Double(4.0))).equals(algebra.mult(algebra.divd(algebra.lit(new Double(5.0)), algebra.lit(new Double(2.0))), algebra.lit(new Double(4.0)))));
        assertTrue(algebra.neg(algebra.mult(algebra.divd(algebra.lit(new Double(5.0)), algebra.lit(new Double(2.0))), algebra.lit(new Double(4.0)))).equals(algebra.neg(algebra.mult(algebra.divd(algebra.lit(new Double(5.0)), algebra.lit(new Double(2.0))), algebra.lit(new Double(4.0))))));
        assertFalse(algebra.mult(algebra.divd(algebra.lit(new Double(5.0)), algebra.lit(new Double(2.0))), algebra.lit(new Double(4.0))).equals(algebra.neg(algebra.mult(algebra.divd(algebra.lit(new Double(5.0)), algebra.lit(new Double(2.0))), algebra.lit(new Double(4.0))))));
        assertFalse(algebra.divd(algebra.lit(new Double(6.0)), algebra.lit(new Double(2.0))).equals(algebra.divd(algebra.lit(new Double(8.0)), algebra.lit(new Double(2.0)))));
        assertTrue(algebra.divd(algebra.lit(new Double(6.0)), algebra.lit(new Double(2.0))).equals(algebra.divd(algebra.lit(new Double(6.0)), algebra.lit(new Double(2.0)))));
        assertTrue(algebra.add(algebra.lit(new Double(5.0)), algebra.lit(new Double(3.0))).equals(algebra.add(algebra.lit(new Double(5.0)), algebra.lit(new Double(3.0)))));
        assertFalse(algebra.add(algebra.lit(new Double(5.0)), algebra.lit(new Double(3.0))).equals(algebra.mult(algebra.divd(algebra.lit(new Double(5.0)), algebra.lit(new Double(2.0))), algebra.lit(new Double(3.0)))));
        CombinedExpAlg.Combined cache12 = algebra.add(algebra.lit(new Double(1.0)), algebra.lit(new Double(2.0)));
        CombinedExpAlg.Combined cache13 = algebra.add(algebra.lit(new Double(1.0)), algebra.lit(new Double(2.0)));
        CombinedExpAlg.Combined cache14 = algebra.add(cache12, cache12);
        CombinedExpAlg.Combined cache15 = algebra.add(cache13, cache13);
        CombinedExpAlg.Combined cache16 = algebra.add(cache14, cache14);
        CombinedExpAlg.Combined cache17 = algebra.add(cache15, cache15);
        CombinedExpAlg.Combined cache18 = algebra.add(cache16, cache16);
        CombinedExpAlg.Combined cache19 = algebra.add(cache17, cache17);
        CombinedExpAlg.Combined cache20 = algebra.add(cache18, cache18);
        CombinedExpAlg.Combined cache21 = algebra.add(cache19, cache19);
        CombinedExpAlg.Combined cache22 = algebra.add(cache20, cache20);
        CombinedExpAlg.Combined cache23 = algebra.add(cache21, cache21);
        CombinedExpAlg.Combined cache24 = algebra.add(cache22, cache22);
        CombinedExpAlg.Combined cache25 = algebra.add(cache23, cache23);
        CombinedExpAlg.Combined cache26 = algebra.add(cache24, cache24);
        CombinedExpAlg.Combined cache27 = algebra.add(cache25, cache25);
        CombinedExpAlg.Combined cache28 = algebra.add(cache26, cache26);
        CombinedExpAlg.Combined cache29 = algebra.add(cache27, cache27);
        CombinedExpAlg.Combined cache30 = algebra.add(cache28, cache28);
        CombinedExpAlg.Combined cache31 = algebra.add(cache29, cache29);
        CombinedExpAlg.Combined cache32 = algebra.add(cache30, cache30);
        CombinedExpAlg.Combined cache33 = algebra.add(cache31, cache31);
        CombinedExpAlg.Combined cache34 = algebra.add(cache32, cache32);
        CombinedExpAlg.Combined cache35 = algebra.add(cache33, cache33);
        long now23 = System.nanoTime();
        cache35.equals(cache34);
        long best23 = System.nanoTime() - now23;
        for (int i = 1; i < 8; i++) {
            now23 = System.nanoTime();
            cache35.equals(cache34);
            long duration = System.nanoTime() - now23;
            if (duration < best23) {
                best23 = duration;
            }
        }
        System.out.println(11 + "," + best23);
        long now22 = System.nanoTime();
        cache33.equals(cache32);
        long best22 = System.nanoTime() - now22;
        for (int i = 1; i < 8; i++) {
            now22 = System.nanoTime();
            cache33.equals(cache32);
            long duration = System.nanoTime() - now22;
            if (duration < best22) {
                best22 = duration;
            }
        }
        System.out.println(10 + "," + best22);
        long now21 = System.nanoTime();
        cache31.equals(cache30);
        long best21 = System.nanoTime() - now21;
        for (int i = 1; i < 8; i++) {
            now21 = System.nanoTime();
            cache31.equals(cache30);
            long duration = System.nanoTime() - now21;
            if (duration < best21) {
                best21 = duration;
            }
        }
        System.out.println(9 + "," + best21);
        long now20 = System.nanoTime();
        cache29.equals(cache28);
        long best20 = System.nanoTime() - now20;
        for (int i = 1; i < 8; i++) {
            now20 = System.nanoTime();
            cache29.equals(cache28);
            long duration = System.nanoTime() - now20;
            if (duration < best20) {
                best20 = duration;
            }
        }
        System.out.println(8 + "," + best20);
        long now19 = System.nanoTime();
        cache27.equals(cache26);
        long best19 = System.nanoTime() - now19;
        for (int i = 1; i < 8; i++) {
            now19 = System.nanoTime();
            cache27.equals(cache26);
            long duration = System.nanoTime() - now19;
            if (duration < best19) {
                best19 = duration;
            }
        }
        System.out.println(7 + "," + best19);
        long now18 = System.nanoTime();
        cache25.equals(cache24);
        long best18 = System.nanoTime() - now18;
        for (int i = 1; i < 8; i++) {
            now18 = System.nanoTime();
            cache25.equals(cache24);
            long duration = System.nanoTime() - now18;
            if (duration < best18) {
                best18 = duration;
            }
        }
        System.out.println(6 + "," + best18);
        long now17 = System.nanoTime();
        cache23.equals(cache22);
        long best17 = System.nanoTime() - now17;
        for (int i = 1; i < 8; i++) {
            now17 = System.nanoTime();
            cache23.equals(cache22);
            long duration = System.nanoTime() - now17;
            if (duration < best17) {
                best17 = duration;
            }
        }
        System.out.println(5 + "," + best17);
        long now16 = System.nanoTime();
        cache21.equals(cache20);
        long best16 = System.nanoTime() - now16;
        for (int i = 1; i < 8; i++) {
            now16 = System.nanoTime();
            cache21.equals(cache20);
            long duration = System.nanoTime() - now16;
            if (duration < best16) {
                best16 = duration;
            }
        }
        System.out.println(4 + "," + best16);
        long now15 = System.nanoTime();
        cache19.equals(cache18);
        long best15 = System.nanoTime() - now15;
        for (int i = 1; i < 8; i++) {
            now15 = System.nanoTime();
            cache19.equals(cache18);
            long duration = System.nanoTime() - now15;
            if (duration < best15) {
                best15 = duration;
            }
        }
        System.out.println(3 + "," + best15);
        long now14 = System.nanoTime();
        cache17.equals(cache16);
        long best14 = System.nanoTime() - now14;
        for (int i = 1; i < 8; i++) {
            now14 = System.nanoTime();
            cache17.equals(cache16);
            long duration = System.nanoTime() - now14;
            if (duration < best14) {
                best14 = duration;
            }
        }
        System.out.println(2 + "," + best14);
        long now13 = System.nanoTime();
        cache15.equals(cache14);
        long best13 = System.nanoTime() - now13;
        for (int i = 1; i < 8; i++) {
            now13 = System.nanoTime();
            cache15.equals(cache14);
            long duration = System.nanoTime() - now13;
            if (duration < best13) {
                best13 = duration;
            }
        }
        System.out.println(1 + "," + best13);
        long now12 = System.nanoTime();
        cache13.equals(cache12);
        long best12 = System.nanoTime() - now12;
        for (int i = 1; i < 8; i++) {
            now12 = System.nanoTime();
            cache13.equals(cache12);
            long duration = System.nanoTime() - now12;
            if (duration < best12) {
                best12 = duration;
            }
        }
        System.out.println(0 + "," + best12);
    }
}
