package trivially;

public interface AddEval extends ExpEval {

    ExpEval getLeft();

    ExpEval getRight();

    default Double eval() {
        return getLeft().eval() + getRight().eval();
    }
}
