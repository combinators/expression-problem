package visitor;

public class SimplifySqrt extends Simplify implements VisitorSqrt<Exp> {

    public Exp visit(Sqrt e) {
        return new Sqrt(e.getInner().accept(makeSimplify()));
    }

    SimplifySqrt makeSimplify() {
        return new SimplifySqrt();
    }
}
