package trivially;

import junit.framework.TestCase;

public class TestSuite5 extends TestCase {

    public void test() {
        assertEquals(0.5, new Inv(new Lit(2.0)).eval());
    }
}
