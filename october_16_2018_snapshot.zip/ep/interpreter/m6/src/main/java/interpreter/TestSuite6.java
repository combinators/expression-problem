package interpreter;

import junit.framework.TestCase;

public class TestSuite6 extends TestCase {

    public void test() {
        assertFalse(new EqualsSub(new EqualsLit(1.0), new EqualsLit(2.0)).astree().same(new EqualsSub(new EqualsLit(9.0), new EqualsLit(112.0)).astree()));
        assertTrue(new EqualsSub(new EqualsLit(1.0), new EqualsLit(2.0)).astree().same(new EqualsSub(new EqualsLit(1.0), new EqualsLit(2.0)).astree()));
    }
}
