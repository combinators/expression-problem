package algebra;

public class AstreePowerExpAlg extends AstreeSqrtExpAlg implements PowerExpAlg<Astree> {

    public Astree power(final Astree left, final Astree right) {
        return () -> {
            return new tree.Node(java.util.Arrays.asList(left.astree(), right.astree()), new IdzPowerExpAlg().power(null, null).idz());
        };
    }
}
