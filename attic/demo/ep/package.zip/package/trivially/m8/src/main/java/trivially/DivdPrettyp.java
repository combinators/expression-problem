package trivially;

public interface DivdPrettyp extends ExpPrettyp, DivdEval {

    ExpPrettyp getLeft();

    ExpPrettyp getRight();

    default String prettyp() {
        return "(" + getLeft().prettyp() + "/" + getRight().prettyp() + ")";
    }
}
