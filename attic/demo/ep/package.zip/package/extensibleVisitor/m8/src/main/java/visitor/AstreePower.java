package visitor;

public class AstreePower extends AstreeSqrt implements VisitorPower<tree.Tree> {

    public tree.Tree visit(Power e) {
        return new tree.Node(java.util.Arrays.asList(e.getLeft().astree(), e.getRight().astree()), e.accept(makeIdz()));
    }

    AstreePower makeAstree() {
        return new AstreePower();
    }
}
