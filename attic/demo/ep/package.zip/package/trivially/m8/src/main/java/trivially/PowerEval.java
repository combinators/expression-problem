package trivially;

public interface PowerEval extends ExpEval {

    ExpEval getLeft();

    ExpEval getRight();

    default Double eval() {
        return Math.pow(getLeft().eval(), getRight().eval());
    }
}
