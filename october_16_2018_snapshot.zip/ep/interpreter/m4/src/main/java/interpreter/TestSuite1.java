package interpreter;

import junit.framework.TestCase;

public class TestSuite1 extends TestCase {

    public void test() {
        assertEquals(3.0, new CollectSimplifyAdd(new CollectSimplifyLit(1.0), new CollectSimplifyLit(2.0)).eval());
        assertEquals(5.0, new CollectSimplifyLit(5.0).eval());
    }
}
