package interpreter;

public class FindNeg extends EqualsNeg implements FindExp {

    public FindNeg(FindExp inner) {
        super(inner);
    }

    public FindExp getInner() {
        return (FindExp) this.inner;
    }

    public Integer find(Double target) {
        return getInner().find(target);
    }
}
