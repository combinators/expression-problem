package interpreter;

public class FindMult extends EqualsMult implements FindExp {

    public FindMult(FindExp left, FindExp right) {
        super(left, right);
    }

    public FindExp getLeft() {
        return (FindExp) this.left;
    }

    public FindExp getRight() {
        return (FindExp) this.right;
    }

    public Integer find(Double target) {
        return getLeft().find(target) + getRight().find(target);
    }
}
