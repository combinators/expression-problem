package expression;

public class IdDivdMultNeg extends IdSub implements VisitorDivdMultNeg<Integer> {

    public Integer visit(Neg e) {
        return 78192;
    }

    public Integer visit(Mult e) {
        return 2409808;
    }

    public Integer visit(Divd e) {
        return 2130451;
    }

    Id makeId() {
        return new IdDivdMultNeg();
    }
}
