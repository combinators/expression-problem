package visitor;

public class CollectPower extends CollectSqrt implements VisitorPower<java.util.List<Double>> {

    public java.util.List<Double> visit(Power e) {
        java.util.List<Double> tmpList7 = new java.util.ArrayList<>();
        tmpList7.addAll(e.getLeft().accept(makeCollect()));
        tmpList7.addAll(e.getRight().accept(makeCollect()));
        return tmpList7;
    }

    CollectPower makeCollect() {
        return new CollectPower();
    }
}
