package trivially;

import junit.framework.TestCase;

public class TestSuite3 extends TestCase {

    public void test() {
        assertEquals(new Double(-1.0), new Neg((FinalI) (new Lit(new Double(1.0)))).eval());
        assertEquals("-1.0", new Neg((FinalI) (new Lit(new Double(1.0)))).prettyp());
        assertEquals("((5.0/2.0)*4.0)", new Mult((FinalI) (new Divd((FinalI) (new Lit(new Double(5.0))), (FinalI) (new Lit(new Double(2.0))))), (FinalI) (new Lit(new Double(4.0)))).prettyp());
        assertEquals(new Double(10.0), new Mult((FinalI) (new Divd((FinalI) (new Lit(new Double(5.0))), (FinalI) (new Lit(new Double(2.0))))), (FinalI) (new Lit(new Double(4.0)))).eval());
        assertEquals(new Double(-5.0), new Neg((FinalI) (new Lit(new Double(5.0)))).eval());
        assertEquals("-(2.0*3.0)", new Neg((FinalI) (new Mult((FinalI) (new Lit(new Double(2.0))), (FinalI) (new Lit(new Double(3.0)))))).prettyp());
    }
}
