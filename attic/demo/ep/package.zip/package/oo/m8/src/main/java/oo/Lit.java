package oo;

public class Lit extends Exp {

    public Lit(Double value) {
        this.value = value;
    }

    private Double value;

    public Exp copy() {
        return new Lit(value);
    }

    public Integer find(Double target) {
        double _litEval = value;
        if (_litEval == target) {
            return 1;
        } else {
            return 0;
        }
    }

    public Boolean equals(Exp that) {
        return this.astree().same(that.astree());
    }

    public tree.Tree astree() {
        return new tree.Leaf(value);
    }

    public Integer idz() {
        return 76407;
    }

    public Exp simplify() {
        return new Lit(value);
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList6 = new java.util.ArrayList<>();
        tmpList6.add(value);
        return tmpList6;
    }

    public String prettyp() {
        return "" + value;
    }

    public Double eval() {
        return value;
    }
}
