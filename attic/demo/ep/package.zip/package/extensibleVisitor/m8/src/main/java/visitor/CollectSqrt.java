package visitor;

public class CollectSqrt extends Collect implements VisitorSqrt<java.util.List<Double>> {

    public java.util.List<Double> visit(Sqrt e) {
        java.util.List<Double> tmpList6 = new java.util.ArrayList<>();
        tmpList6.addAll(e.getInner().accept(makeCollect()));
        return tmpList6;
    }

    CollectSqrt makeCollect() {
        return new CollectSqrt();
    }
}
