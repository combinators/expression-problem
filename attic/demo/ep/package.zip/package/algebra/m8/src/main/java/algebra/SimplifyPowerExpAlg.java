package algebra;

public class SimplifyPowerExpAlg extends SimplifySqrtExpAlg implements PowerExpAlg<Simplify> {

    // Binary operations are passed in necessary algebra to work with
    CombinedExpAlg algebra;

    public SimplifyPowerExpAlg(CombinedExpAlg alg) {
        super(alg);
        this.algebra = alg;
    }

    public Simplify power(final Simplify left, final Simplify right) {
        return () -> {
            double leftVal = left.simplify().eval();
            double rightVal = right.simplify().eval();
            if (leftVal == 0) {
                return algebra.lit(0.0);
            } else if (rightVal == 0) {
                return algebra.lit(1.0);
            } else if (rightVal == 1) {
                return left.simplify();
            } else {
                return algebra.power(left.simplify(), right.simplify());
            }
        };
    }
}
