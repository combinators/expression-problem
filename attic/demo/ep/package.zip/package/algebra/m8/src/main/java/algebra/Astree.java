package algebra;

interface Astree {

    tree.Tree astree();
}
