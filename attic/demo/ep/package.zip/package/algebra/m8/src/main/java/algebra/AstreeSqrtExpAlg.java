package algebra;

public class AstreeSqrtExpAlg extends AstreeDivdMultNegExpAlg implements SqrtExpAlg<Astree> {

    public Astree sqrt(final Astree inner) {
        return () -> {
            return new tree.Node(java.util.Arrays.asList(inner.astree()), new IdzPowerExpAlg().sqrt(null).idz());
        };
    }
}
