package expression;

public class Print extends Visitor<String> {

    public String visit(Neg e) {
        return "-" + e.getInner().accept(new Print());
    }

    public String visit(Mult e) {
        return "(" + e.getLeft().accept(new Print()) + "*" + e.getRight().accept(new Print()) + ")";
    }

    public String visit(Divd e) {
        return "(" + e.getLeft().accept(new Print()) + "/" + e.getRight().accept(new Print()) + ")";
    }

    public String visit(Sub e) {
        return "(" + e.getLeft().accept(new Print()) + "-" + e.getRight().accept(new Print()) + ")";
    }

    public String visit(Lit e) {
        return "" + e.getValue() + "";
    }

    public String visit(Add e) {
        return "(" + e.getLeft().accept(new Print()) + "+" + e.getRight().accept(new Print()) + ")";
    }
}
