package trivially;

public interface PowerCollectSimplify extends ExpCollectSimplify, PowerPrettyp {

    ExpCollectSimplify getLeft();

    ExpCollectSimplify getRight();

    default ExpCollectSimplify simplify() {
        double leftVal = getLeft().eval();
        double rightVal = getRight().eval();
        if (leftVal == 0) {
            return new Lit(0.0);
        } else if (rightVal == 0) {
            return new Lit(1.0);
        } else if (rightVal == 1) {
            return getLeft().simplify();
        } else {
            return new Power((FinalI) (getLeft().simplify()), (FinalI) (getRight().simplify()));
        }
    }

    default java.util.List<Double> collect() {
        java.util.List<Double> tmpList0 = new java.util.ArrayList<>();
        tmpList0.addAll(getLeft().collect());
        tmpList0.addAll(getRight().collect());
        return tmpList0;
    }
}
