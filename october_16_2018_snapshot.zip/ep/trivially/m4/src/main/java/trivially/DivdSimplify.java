package trivially;

public interface DivdSimplify extends ExpSimplify, DivdPrettyp {

    ExpSimplify getLeft();

    ExpSimplify getRight();

    default ExpSimplify simplify() {
        double leftVal = getLeft().eval();
        double rightVal = getRight().eval();
        if (leftVal == 0) {
            return new Lit(0.0);
        } else if (rightVal == 1) {
            return getLeft().simplify();
        } else if (leftVal == rightVal) {
            return new Lit(1.0);
        } else if (leftVal == -rightVal) {
            return new Lit(-1.0);
        } else {
            return new Divd((FinalI) (getLeft().simplify()), (FinalI) (getRight().simplify()));
        }
    }
}
