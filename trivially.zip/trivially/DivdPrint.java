package trivially;

public interface DivdPrint extends ExpPrint, DivdEval {

    ExpPrint getLeft();

    ExpPrint getRight();

    default String print() {
        return "(" + getLeft().print() + "/" + getRight().print() + ")";
    }
}
