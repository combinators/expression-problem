package expression;

public class PrettypDivdMultNeg extends Prettyp implements VisitorDivdMultNeg<String> {

    public String visit(Neg e) {
        return "-" + e.getInner().accept(makePrettyp());
    }

    public String visit(Mult e) {
        return "(" + e.getLeft().accept(makePrettyp()) + "*" + e.getRight().accept(makePrettyp()) + ")";
    }

    public String visit(Divd e) {
        return "(" + e.getLeft().accept(makePrettyp()) + "/" + e.getRight().accept(makePrettyp()) + ")";
    }

    Prettyp makePrettyp() {
        return new PrettypDivdMultNeg();
    }
}
