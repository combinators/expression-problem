package visitor;

import junit.framework.TestCase;

public class TestSuite2 extends TestCase {

    public void test() {
        assertEquals("(1.0-2.0)", new Sub(new Lit(new Double(1.0)), new Lit(new Double(2.0))).accept(makePrettyp()));
        assertEquals("((1.0-2.0)+(5.0+6.0))", new Add(new Sub(new Lit(new Double(1.0)), new Lit(new Double(2.0))), new Add(new Lit(new Double(5.0)), new Lit(new Double(6.0)))).accept(makePrettyp()));
    }

    CopyPower makeCopy() {
        return new CopyPower();
    }

    FindPower makeFind(Double target) {
        return new FindPower(target);
    }

    EqualsPower makeEquals(Exp that) {
        return new EqualsPower(that);
    }

    AstreePower makeAstree() {
        return new AstreePower();
    }

    IdzPower makeIdz() {
        return new IdzPower();
    }

    SimplifyPower makeSimplify() {
        return new SimplifyPower();
    }

    CollectPower makeCollect() {
        return new CollectPower();
    }

    PrettypPower makePrettyp() {
        return new PrettypPower();
    }

    EvalPower makeEval() {
        return new EvalPower();
    }
}
