package interpreter;

import static interpreter.CollectSimplifyExpFactory.*;

public class CollectSimplifyPower extends PrettypPower implements CollectSimplifyExp {

    public CollectSimplifyPower(CollectSimplifyExp left, CollectSimplifyExp right) {
        super(left, right);
    }

    public CollectSimplifyExp getLeft() {
        return (CollectSimplifyExp) this.left;
    }

    public CollectSimplifyExp getRight() {
        return (CollectSimplifyExp) this.right;
    }

    public String prettyp() {
        return "Power(" + getLeft().prettyp() + "," + getRight().prettyp() + ")";
    }

    public Double eval() {
        return Math.pow(getLeft().eval(), getRight().eval());
    }

    public CollectSimplifyExp simplify() {
        double leftVal = getLeft().eval();
        double rightVal = getRight().eval();
        if (leftVal == 0) {
            return Lit(0.0);
        } else if (rightVal == 0) {
            return Lit(1.0);
        } else if (rightVal == 1) {
            return getLeft().simplify();
        } else {
            return Power(getLeft().simplify(), getRight().simplify());
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList0 = new java.util.ArrayList<>();
        tmpList0.addAll(getLeft().collect());
        tmpList0.addAll(getRight().collect());
        return tmpList0;
    }

    @Override
    public <R> R accept(KnownDataTypes<R> from) {
        if (from instanceof CopyExp.KnownDataTypes) {
            return ((CopyExp.KnownDataTypes<R>) from).convert(this);
        }
        throw new IllegalArgumentException("unknown conversion.");
    }
}
