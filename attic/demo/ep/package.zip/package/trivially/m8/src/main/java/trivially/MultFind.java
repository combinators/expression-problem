package trivially;

public interface MultFind extends ExpFind, MultEquals {

    ExpFind getLeft();

    ExpFind getRight();

    default Integer find(Double target) {
        return getLeft().find(target) + getRight().find(target);
    }
}
