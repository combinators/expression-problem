package trivially;

public interface ExpCollect extends ExpPrettyp {

    public java.util.List<Double> collect();
}
