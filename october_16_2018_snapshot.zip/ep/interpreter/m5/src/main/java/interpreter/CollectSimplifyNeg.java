package interpreter;

public class CollectSimplifyNeg extends PrettypNeg implements CollectSimplifyExp {

    CollectSimplifyExp Neg(CollectSimplifyExp inner) {
        return new CollectSimplifyNeg(inner);
    }

    CollectSimplifyExp Mult(CollectSimplifyExp left, CollectSimplifyExp right) {
        return new CollectSimplifyMult(left, right);
    }

    CollectSimplifyExp Divd(CollectSimplifyExp left, CollectSimplifyExp right) {
        return new CollectSimplifyDivd(left, right);
    }

    CollectSimplifyExp Sub(CollectSimplifyExp left, CollectSimplifyExp right) {
        return new CollectSimplifySub(left, right);
    }

    CollectSimplifyExp Lit(Double value) {
        return new CollectSimplifyLit(value);
    }

    CollectSimplifyExp Add(CollectSimplifyExp left, CollectSimplifyExp right) {
        return new CollectSimplifyAdd(left, right);
    }

    public CollectSimplifyNeg(CollectSimplifyExp inner) {
        super(inner);
    }

    public CollectSimplifyExp getInner() {
        return (CollectSimplifyExp) this.inner;
    }

    public CollectSimplifyExp simplify() {
        if (getInner().eval() == 0) {
            return Lit(0.0);
        } else {
            return Neg(getInner().simplify());
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> list = new java.util.ArrayList<Double>();
        list.addAll(getInner().collect());
        return list;
    }
}
