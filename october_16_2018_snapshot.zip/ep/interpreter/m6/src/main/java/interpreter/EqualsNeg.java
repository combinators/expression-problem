package interpreter;

public class EqualsNeg extends AstreeNeg implements EqualsExp {

    EqualsExp Neg(EqualsExp inner) {
        return new EqualsNeg(inner);
    }

    EqualsExp Mult(EqualsExp left, EqualsExp right) {
        return new EqualsMult(left, right);
    }

    EqualsExp Divd(EqualsExp left, EqualsExp right) {
        return new EqualsDivd(left, right);
    }

    EqualsExp Sub(EqualsExp left, EqualsExp right) {
        return new EqualsSub(left, right);
    }

    EqualsExp Lit(Double value) {
        return new EqualsLit(value);
    }

    EqualsExp Add(EqualsExp left, EqualsExp right) {
        return new EqualsAdd(left, right);
    }

    public EqualsNeg(EqualsExp inner) {
        super(inner);
    }

    public EqualsExp getInner() {
        return (EqualsExp) this.inner;
    }

    public Boolean equals(EqualsExp that) {
        return astree().same(that.astree());
    }
}
