package algebra;

interface Equals extends Astree {

    Boolean equals(Equals that);
}
