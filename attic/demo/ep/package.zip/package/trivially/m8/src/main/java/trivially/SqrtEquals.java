package trivially;

public interface SqrtEquals extends ExpEquals, SqrtAstreeIdz {

    ExpEquals getInner();

    default Boolean equals(ExpEquals that) {
        return this.astree().same(that.astree());
    }
}
