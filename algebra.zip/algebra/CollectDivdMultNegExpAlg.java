package algebra;

public class CollectDivdMultNegExpAlg implements DivdMultNegExpAlg<Collect> {

    public Collect neg(final Collect inner) {
        return new Collect() {

            public java.util.List<Double> collect() {
                java.util.List<Double> list = new java.util.ArrayList<Double>();
                list.addAll(inner.collect());
                return list;
            }
        };
    }

    public Collect mult(final Collect left, final Collect right) {
        return new Collect() {

            public java.util.List<Double> collect() {
                java.util.List<Double> list = left.collect();
                list.addAll(right.collect());
                return list;
            }
        };
    }

    public Collect divd(final Collect left, final Collect right) {
        return new Collect() {

            public java.util.List<Double> collect() {
                java.util.List<Double> list = left.collect();
                list.addAll(right.collect());
                return list;
            }
        };
    }

    public Collect sub(final Collect left, final Collect right) {
        return new Collect() {

            public java.util.List<Double> collect() {
                java.util.List<Double> list = left.collect();
                list.addAll(right.collect());
                return list;
            }
        };
    }

    public Collect lit(final Double value) {
        return new Collect() {

            public java.util.List<Double> collect() {
                java.util.List<Double> list = new java.util.ArrayList<Double>();
                list.add(value);
                return list;
            }
        };
    }

    public Collect add(final Collect left, final Collect right) {
        return new Collect() {

            public java.util.List<Double> collect() {
                java.util.List<Double> list = left.collect();
                list.addAll(right.collect());
                return list;
            }
        };
    }
}
