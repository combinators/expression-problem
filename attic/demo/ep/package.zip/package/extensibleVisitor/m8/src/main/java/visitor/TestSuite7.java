package visitor;

import junit.framework.TestCase;

public class TestSuite7 extends TestCase {

    public void test() {
        assertTrue(new Sub(new Lit(new Double(1.0)), new Lit(new Double(73.0))).accept(makeEquals(new Sub(new Lit(new Double(1.0)), new Lit(new Double(73.0))))));
        assertFalse(new Mult(new Divd(new Lit(new Double(5.0)), new Lit(new Double(2.0))), new Lit(new Double(4.0))).accept(makeEquals(new Mult(new Divd(new Lit(new Double(5.0)), new Lit(new Double(2.0))), new Lit(new Double(3.0))))));
        assertTrue(new Mult(new Divd(new Lit(new Double(5.0)), new Lit(new Double(2.0))), new Lit(new Double(4.0))).accept(makeEquals(new Mult(new Divd(new Lit(new Double(5.0)), new Lit(new Double(2.0))), new Lit(new Double(4.0))))));
        assertTrue(new Neg(new Mult(new Divd(new Lit(new Double(5.0)), new Lit(new Double(2.0))), new Lit(new Double(4.0)))).accept(makeEquals(new Neg(new Mult(new Divd(new Lit(new Double(5.0)), new Lit(new Double(2.0))), new Lit(new Double(4.0)))))));
        assertFalse(new Mult(new Divd(new Lit(new Double(5.0)), new Lit(new Double(2.0))), new Lit(new Double(4.0))).accept(makeEquals(new Neg(new Mult(new Divd(new Lit(new Double(5.0)), new Lit(new Double(2.0))), new Lit(new Double(4.0)))))));
        assertFalse(new Divd(new Lit(new Double(6.0)), new Lit(new Double(2.0))).accept(makeEquals(new Divd(new Lit(new Double(8.0)), new Lit(new Double(2.0))))));
        assertTrue(new Divd(new Lit(new Double(6.0)), new Lit(new Double(2.0))).accept(makeEquals(new Divd(new Lit(new Double(6.0)), new Lit(new Double(2.0))))));
        assertTrue(new Add(new Lit(new Double(5.0)), new Lit(new Double(3.0))).accept(makeEquals(new Add(new Lit(new Double(5.0)), new Lit(new Double(3.0))))));
        assertFalse(new Add(new Lit(new Double(5.0)), new Lit(new Double(3.0))).accept(makeEquals(new Mult(new Divd(new Lit(new Double(5.0)), new Lit(new Double(2.0))), new Lit(new Double(3.0))))));
        Exp cache12 = new Add(new Lit(new Double(1.0)), new Lit(new Double(2.0)));
        Exp cache13 = new Add(new Lit(new Double(1.0)), new Lit(new Double(2.0)));
        Exp cache14 = new Add(cache12, cache12);
        Exp cache15 = new Add(cache13, cache13);
        Exp cache16 = new Add(cache14, cache14);
        Exp cache17 = new Add(cache15, cache15);
        Exp cache18 = new Add(cache16, cache16);
        Exp cache19 = new Add(cache17, cache17);
        Exp cache20 = new Add(cache18, cache18);
        Exp cache21 = new Add(cache19, cache19);
        Exp cache22 = new Add(cache20, cache20);
        Exp cache23 = new Add(cache21, cache21);
        Exp cache24 = new Add(cache22, cache22);
        Exp cache25 = new Add(cache23, cache23);
        Exp cache26 = new Add(cache24, cache24);
        Exp cache27 = new Add(cache25, cache25);
        Exp cache28 = new Add(cache26, cache26);
        Exp cache29 = new Add(cache27, cache27);
        Exp cache30 = new Add(cache28, cache28);
        Exp cache31 = new Add(cache29, cache29);
        Exp cache32 = new Add(cache30, cache30);
        Exp cache33 = new Add(cache31, cache31);
        Exp cache34 = new Add(cache32, cache32);
        Exp cache35 = new Add(cache33, cache33);
        long now23 = System.nanoTime();
        cache35.accept(makeEquals(cache34));
        long best23 = System.nanoTime() - now23;
        for (int i = 1; i < 8; i++) {
            now23 = System.nanoTime();
            cache35.accept(makeEquals(cache34));
            long duration = System.nanoTime() - now23;
            if (duration < best23) {
                best23 = duration;
            }
        }
        System.out.println(11 + "," + best23);
        long now22 = System.nanoTime();
        cache33.accept(makeEquals(cache32));
        long best22 = System.nanoTime() - now22;
        for (int i = 1; i < 8; i++) {
            now22 = System.nanoTime();
            cache33.accept(makeEquals(cache32));
            long duration = System.nanoTime() - now22;
            if (duration < best22) {
                best22 = duration;
            }
        }
        System.out.println(10 + "," + best22);
        long now21 = System.nanoTime();
        cache31.accept(makeEquals(cache30));
        long best21 = System.nanoTime() - now21;
        for (int i = 1; i < 8; i++) {
            now21 = System.nanoTime();
            cache31.accept(makeEquals(cache30));
            long duration = System.nanoTime() - now21;
            if (duration < best21) {
                best21 = duration;
            }
        }
        System.out.println(9 + "," + best21);
        long now20 = System.nanoTime();
        cache29.accept(makeEquals(cache28));
        long best20 = System.nanoTime() - now20;
        for (int i = 1; i < 8; i++) {
            now20 = System.nanoTime();
            cache29.accept(makeEquals(cache28));
            long duration = System.nanoTime() - now20;
            if (duration < best20) {
                best20 = duration;
            }
        }
        System.out.println(8 + "," + best20);
        long now19 = System.nanoTime();
        cache27.accept(makeEquals(cache26));
        long best19 = System.nanoTime() - now19;
        for (int i = 1; i < 8; i++) {
            now19 = System.nanoTime();
            cache27.accept(makeEquals(cache26));
            long duration = System.nanoTime() - now19;
            if (duration < best19) {
                best19 = duration;
            }
        }
        System.out.println(7 + "," + best19);
        long now18 = System.nanoTime();
        cache25.accept(makeEquals(cache24));
        long best18 = System.nanoTime() - now18;
        for (int i = 1; i < 8; i++) {
            now18 = System.nanoTime();
            cache25.accept(makeEquals(cache24));
            long duration = System.nanoTime() - now18;
            if (duration < best18) {
                best18 = duration;
            }
        }
        System.out.println(6 + "," + best18);
        long now17 = System.nanoTime();
        cache23.accept(makeEquals(cache22));
        long best17 = System.nanoTime() - now17;
        for (int i = 1; i < 8; i++) {
            now17 = System.nanoTime();
            cache23.accept(makeEquals(cache22));
            long duration = System.nanoTime() - now17;
            if (duration < best17) {
                best17 = duration;
            }
        }
        System.out.println(5 + "," + best17);
        long now16 = System.nanoTime();
        cache21.accept(makeEquals(cache20));
        long best16 = System.nanoTime() - now16;
        for (int i = 1; i < 8; i++) {
            now16 = System.nanoTime();
            cache21.accept(makeEquals(cache20));
            long duration = System.nanoTime() - now16;
            if (duration < best16) {
                best16 = duration;
            }
        }
        System.out.println(4 + "," + best16);
        long now15 = System.nanoTime();
        cache19.accept(makeEquals(cache18));
        long best15 = System.nanoTime() - now15;
        for (int i = 1; i < 8; i++) {
            now15 = System.nanoTime();
            cache19.accept(makeEquals(cache18));
            long duration = System.nanoTime() - now15;
            if (duration < best15) {
                best15 = duration;
            }
        }
        System.out.println(3 + "," + best15);
        long now14 = System.nanoTime();
        cache17.accept(makeEquals(cache16));
        long best14 = System.nanoTime() - now14;
        for (int i = 1; i < 8; i++) {
            now14 = System.nanoTime();
            cache17.accept(makeEquals(cache16));
            long duration = System.nanoTime() - now14;
            if (duration < best14) {
                best14 = duration;
            }
        }
        System.out.println(2 + "," + best14);
        long now13 = System.nanoTime();
        cache15.accept(makeEquals(cache14));
        long best13 = System.nanoTime() - now13;
        for (int i = 1; i < 8; i++) {
            now13 = System.nanoTime();
            cache15.accept(makeEquals(cache14));
            long duration = System.nanoTime() - now13;
            if (duration < best13) {
                best13 = duration;
            }
        }
        System.out.println(1 + "," + best13);
        long now12 = System.nanoTime();
        cache13.accept(makeEquals(cache12));
        long best12 = System.nanoTime() - now12;
        for (int i = 1; i < 8; i++) {
            now12 = System.nanoTime();
            cache13.accept(makeEquals(cache12));
            long duration = System.nanoTime() - now12;
            if (duration < best12) {
                best12 = duration;
            }
        }
        System.out.println(0 + "," + best12);
    }

    CopyPower makeCopy() {
        return new CopyPower();
    }

    FindPower makeFind(Double target) {
        return new FindPower(target);
    }

    EqualsPower makeEquals(Exp that) {
        return new EqualsPower(that);
    }

    AstreePower makeAstree() {
        return new AstreePower();
    }

    IdzPower makeIdz() {
        return new IdzPower();
    }

    SimplifyPower makeSimplify() {
        return new SimplifyPower();
    }

    CollectPower makeCollect() {
        return new CollectPower();
    }

    PrettypPower makePrettyp() {
        return new PrettypPower();
    }

    EvalPower makeEval() {
        return new EvalPower();
    }
}
