package trivially;

public interface ExpAstree extends ExpSimplify, ExpCollect {

    public tree.Tree astree();
}
