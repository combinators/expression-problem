package interpreter;

import static interpreter.CollectSimplifyExpFactory.*;

public class CollectSimplifyAdd extends PrettypAdd implements CollectSimplifyExp {

    public CollectSimplifyAdd(CollectSimplifyExp left, CollectSimplifyExp right) {
        super(left, right);
    }

    public CollectSimplifyExp getLeft() {
        return (CollectSimplifyExp) this.left;
    }

    public CollectSimplifyExp getRight() {
        return (CollectSimplifyExp) this.right;
    }

    public CollectSimplifyExp simplify() {
        double leftVal = getLeft().eval();
        double rightVal = getRight().eval();
        if ((leftVal == 0 && rightVal == 0) || (leftVal + rightVal == 0)) {
            return Lit(0.0);
        } else if (leftVal == 0) {
            return getRight().simplify();
        } else if (rightVal == 0) {
            return getLeft().simplify();
        } else {
            return Add(getLeft().simplify(), getRight().simplify());
        }
    }

    public java.util.List<Double> collect() {
        java.util.List<Double> tmpList7 = new java.util.ArrayList<>();
        tmpList7.addAll(getLeft().collect());
        tmpList7.addAll(getRight().collect());
        return tmpList7;
    }

    @Override
    public <R> R accept(KnownDataTypes<R> from) {
        return from.convert(this);
    }
}
