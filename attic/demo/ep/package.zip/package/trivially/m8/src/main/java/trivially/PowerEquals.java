package trivially;

public interface PowerEquals extends ExpEquals, PowerAstreeIdz {

    ExpEquals getLeft();

    ExpEquals getRight();

    default Boolean equals(ExpEquals that) {
        return this.astree().same(that.astree());
    }
}
