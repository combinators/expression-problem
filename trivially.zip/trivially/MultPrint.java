package trivially;

public interface MultPrint extends ExpPrint, MultEval {

    ExpPrint getLeft();

    ExpPrint getRight();

    default String print() {
        return "(" + getLeft().print() + "*" + getRight().print() + ")";
    }
}
