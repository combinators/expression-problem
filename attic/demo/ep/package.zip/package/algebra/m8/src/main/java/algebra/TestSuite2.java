package algebra;

import junit.framework.TestCase;

public class TestSuite2 extends TestCase {

    EqualsPowerExpAlg algebraEquals = new EqualsPowerExpAlg();

    AstreePowerExpAlg algebraAstree = new AstreePowerExpAlg();

    FindPowerExpAlg algebraFind = new FindPowerExpAlg();

    CollectPowerExpAlg algebraCollect = new CollectPowerExpAlg();

    EvalPowerExpAlg algebraEval = new EvalPowerExpAlg();

    PrettypPowerExpAlg algebraPrettyp = new PrettypPowerExpAlg();

    IdzPowerExpAlg algebraIdz = new IdzPowerExpAlg();

    CombinedExpAlg algebra = new CombinedExpAlg(algebraAstree, algebraCollect, algebraEquals, algebraEval, algebraFind, algebraIdz, algebraPrettyp);

    public void test() {
        assertEquals("(1.0-2.0)", algebra.sub(algebra.lit(new Double(1.0)), algebra.lit(new Double(2.0))).prettyp());
        assertEquals("((1.0-2.0)+(5.0+6.0))", algebra.add(algebra.sub(algebra.lit(new Double(1.0)), algebra.lit(new Double(2.0))), algebra.add(algebra.lit(new Double(5.0)), algebra.lit(new Double(6.0)))).prettyp());
    }
}
