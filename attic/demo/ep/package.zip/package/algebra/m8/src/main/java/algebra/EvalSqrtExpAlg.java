package algebra;

public class EvalSqrtExpAlg extends EvalDivdMultNegExpAlg implements SqrtExpAlg<Eval> {

    public Eval sqrt(final Eval inner) {
        return () -> {
            return Math.sqrt(inner.eval());
        };
    }
}
