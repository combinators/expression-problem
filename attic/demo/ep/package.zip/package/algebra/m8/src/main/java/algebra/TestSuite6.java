package algebra;

import junit.framework.TestCase;

public class TestSuite6 extends TestCase {

    EqualsPowerExpAlg algebraEquals = new EqualsPowerExpAlg();

    AstreePowerExpAlg algebraAstree = new AstreePowerExpAlg();

    FindPowerExpAlg algebraFind = new FindPowerExpAlg();

    CollectPowerExpAlg algebraCollect = new CollectPowerExpAlg();

    EvalPowerExpAlg algebraEval = new EvalPowerExpAlg();

    PrettypPowerExpAlg algebraPrettyp = new PrettypPowerExpAlg();

    IdzPowerExpAlg algebraIdz = new IdzPowerExpAlg();

    CombinedExpAlg algebra = new CombinedExpAlg(algebraAstree, algebraCollect, algebraEquals, algebraEval, algebraFind, algebraIdz, algebraPrettyp);

    public void test() {
        assertFalse(algebra.sub(algebra.lit(new Double(1.0)), algebra.lit(new Double(976.0))).astree().same(algebra.add(algebra.lit(new Double(1.0)), algebra.lit(new Double(976.0))).astree()));
        assertTrue(algebra.sub(algebra.lit(new Double(1.0)), algebra.lit(new Double(976.0))).astree().same(algebra.sub(algebra.lit(new Double(1.0)), algebra.lit(new Double(976.0))).astree()));
        assertTrue(algebra.sub(algebra.neg(algebra.lit(new Double(2.0))), algebra.mult(algebra.sub(algebra.lit(new Double(1.0)), algebra.lit(new Double(976.0))), algebra.add(algebra.mult(algebra.lit(new Double(1.0)), algebra.lit(new Double(976.0))), algebra.divd(algebra.lit(new Double(1.0)), algebra.lit(new Double(3.0)))))).astree().same(algebra.sub(algebra.neg(algebra.lit(new Double(2.0))), algebra.mult(algebra.sub(algebra.lit(new Double(1.0)), algebra.lit(new Double(976.0))), algebra.add(algebra.mult(algebra.lit(new Double(1.0)), algebra.lit(new Double(976.0))), algebra.divd(algebra.lit(new Double(1.0)), algebra.lit(new Double(3.0)))))).astree()));
        java.util.ArrayList<tree.Tree> list0 = new java.util.ArrayList<>();
        java.util.ArrayList<tree.Tree> list2 = new java.util.ArrayList<>();
        tree.Tree leaf4 = new tree.Leaf(2.0);
        list2.add(leaf4);
        tree.Node node3 = new tree.Node(list2, 78192);
        list0.add(node3);
        java.util.ArrayList<tree.Tree> list5 = new java.util.ArrayList<>();
        java.util.ArrayList<tree.Tree> list7 = new java.util.ArrayList<>();
        tree.Tree leaf9 = new tree.Leaf(1.0);
        list7.add(leaf9);
        tree.Tree leaf10 = new tree.Leaf(976.0);
        list7.add(leaf10);
        tree.Node node8 = new tree.Node(list7, 83488);
        list5.add(node8);
        java.util.ArrayList<tree.Tree> list11 = new java.util.ArrayList<>();
        java.util.ArrayList<tree.Tree> list13 = new java.util.ArrayList<>();
        tree.Tree leaf15 = new tree.Leaf(1.0);
        list13.add(leaf15);
        tree.Tree leaf16 = new tree.Leaf(976.0);
        list13.add(leaf16);
        tree.Node node14 = new tree.Node(list13, 2409808);
        list11.add(node14);
        java.util.ArrayList<tree.Tree> list17 = new java.util.ArrayList<>();
        tree.Tree leaf19 = new tree.Leaf(1.0);
        list17.add(leaf19);
        tree.Tree leaf20 = new tree.Leaf(3.0);
        list17.add(leaf20);
        tree.Node node18 = new tree.Node(list17, 2130451);
        list11.add(node18);
        tree.Node node12 = new tree.Node(list11, 65665);
        list5.add(node12);
        tree.Node node6 = new tree.Node(list5, 2409808);
        list0.add(node6);
        tree.Node node1 = new tree.Node(list0, 83488);
        assertEquals(node1, algebra.sub(algebra.neg(algebra.lit(new Double(2.0))), algebra.mult(algebra.sub(algebra.lit(new Double(1.0)), algebra.lit(new Double(976.0))), algebra.add(algebra.mult(algebra.lit(new Double(1.0)), algebra.lit(new Double(976.0))), algebra.divd(algebra.lit(new Double(1.0)), algebra.lit(new Double(3.0)))))).astree());
        assertEquals("(-2.0-((1.0-976.0)*((1.0*976.0)+(1.0/3.0))))", algebra.sub(algebra.neg(algebra.lit(new Double(2.0))), algebra.mult(algebra.sub(algebra.lit(new Double(1.0)), algebra.lit(new Double(976.0))), algebra.add(algebra.mult(algebra.lit(new Double(1.0)), algebra.lit(new Double(976.0))), algebra.divd(algebra.lit(new Double(1.0)), algebra.lit(new Double(3.0)))))).prettyp());
        java.util.ArrayList<tree.Tree> list21 = new java.util.ArrayList<>();
        tree.Tree leaf23 = new tree.Leaf(2.0);
        list21.add(leaf23);
        tree.Tree leaf24 = new tree.Leaf(7.0);
        list21.add(leaf24);
        tree.Node node22 = new tree.Node(list21, 2409808);
        assertEquals(node22, algebra.mult(algebra.mult(algebra.lit(new Double(2.0)), algebra.lit(new Double(1.0))), algebra.add(algebra.lit(new Double(0.0)), algebra.lit(new Double(7.0)))).simplify().astree());
    }
}
