package trivially;

import junit.framework.TestCase;

public class TestSuite7 extends TestCase {

    public void test() {
        assertFalse(new Sub(new Lit(1.0), new Lit(2.0)).equals(new Add(new Sub(new Lit(1.0), new Lit(2.0)), new Add(new Lit(5.0), new Lit(6.0)))));
        assertTrue(new Sub(new Lit(1.0), new Lit(2.0)).equals(new Sub(new Lit(1.0), new Lit(2.0))));
    }
}
