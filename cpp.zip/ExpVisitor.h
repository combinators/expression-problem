
#ifndef _ExpVisitor_
#define _ExpVisitor_

#include "visitor.h" 
#include "Neg.h" 
#include "Mult.h" 
#include "Divd.h" 
#include "Sub.h" 
#include "Lit.h" 
#include "Add.h" 

class ExpVisitor  {
public:
  virtual void VisitNeg(const Neg* e) = 0;
  virtual void VisitMult(const Mult* e) = 0;
  virtual void VisitDivd(const Divd* e) = 0;
  virtual void VisitSub(const Sub* e) = 0;
  virtual void VisitLit(const Lit* e) = 0;
  virtual void VisitAdd(const Add* e) = 0;

private:

};
#endif /* _ExpVisitor_ */
       