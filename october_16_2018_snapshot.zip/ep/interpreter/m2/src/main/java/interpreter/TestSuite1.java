package interpreter;

import junit.framework.TestCase;

public class TestSuite1 extends TestCase {

    public void test() {
        assertEquals(3.0, new PrettypAdd(new PrettypLit(1.0), new PrettypLit(2.0)).eval());
        assertEquals(5.0, new PrettypLit(5.0).eval());
    }
}
