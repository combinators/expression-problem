
#ifndef _Neg_
#define _Neg_

#include "visitor.h" 
#include "Exp.h" 
#include "ExpVisitor.h" 

class Neg : public Exp {
public:
  const Exp* getExp() const { return exp_; }
  Neg (const Exp* exp) : exp_(exp) {}
  void Accept(ExpVisitor* visitor) const;

private:
  const Exp* exp_;
};
#endif /* _Neg_ */
       