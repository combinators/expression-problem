package trivially;

public interface SubEquals extends ExpEquals, SubAstree {

    ExpEquals getLeft();

    ExpEquals getRight();

    default Boolean equals(Exp that) {
        return astree().same(that.astree());
    }
}
