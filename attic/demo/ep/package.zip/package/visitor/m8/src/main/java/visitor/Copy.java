package visitor;

public class Copy extends Visitor<Exp> {

    public Exp visit(Power e) {
        return new Power(e.getLeft().accept(new Copy()), e.getRight().accept(new Copy()));
    }

    public Exp visit(Sqrt e) {
        return new Sqrt(e.getInner().accept(new Copy()));
    }

    public Exp visit(Neg e) {
        return new Neg(e.getInner().accept(new Copy()));
    }

    public Exp visit(Mult e) {
        return new Mult(e.getLeft().accept(new Copy()), e.getRight().accept(new Copy()));
    }

    public Exp visit(Divd e) {
        return new Divd(e.getLeft().accept(new Copy()), e.getRight().accept(new Copy()));
    }

    public Exp visit(Sub e) {
        return new Sub(e.getLeft().accept(new Copy()), e.getRight().accept(new Copy()));
    }

    public Exp visit(Lit e) {
        return new Lit(e.getValue());
    }

    public Exp visit(Add e) {
        return new Add(e.getLeft().accept(new Copy()), e.getRight().accept(new Copy()));
    }
}
