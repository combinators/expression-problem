package trivially;

public interface LitId extends ExpId {

    Double getValue();

    default Integer id() {
        return 76407;
    }
}
