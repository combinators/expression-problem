package trivially;

public interface SubHeight extends ExpHeight, SubPrettyp {

    ExpHeight getLeft();

    ExpHeight getRight();

    default Integer height(Integer height) {
        return Math.max(getLeft().height(height + 1), getRight().height(height + 1));
    }
}
