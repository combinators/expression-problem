package visitor;

public class Simplify implements VisitorDivdMultNeg<Exp> {

    public Exp visit(Neg e) {
        if (e.getInner().accept(makeEval()) == 0) {
            return new Lit(0.0);
        } else {
            return new Neg(e.getInner().accept(makeSimplify()));
        }
    }

    public Exp visit(Mult e) {
        double leftVal = e.getLeft().accept(makeEval());
        double rightVal = e.getRight().accept(makeEval());
        if (leftVal == 0 || rightVal == 0) {
            return new Lit(0.0);
        } else if (leftVal == 1) {
            return e.getRight().accept(makeSimplify());
        } else if (rightVal == 1) {
            return e.getLeft().accept(makeSimplify());
        } else {
            return new Mult(e.getLeft().accept(makeSimplify()), e.getRight().accept(makeSimplify()));
        }
    }

    public Exp visit(Divd e) {
        double leftVal = e.getLeft().accept(makeEval());
        double rightVal = e.getRight().accept(makeEval());
        if (leftVal == 0) {
            return new Lit(0.0);
        } else if (rightVal == 1) {
            return e.getLeft().accept(makeSimplify());
        } else if (leftVal == rightVal) {
            return new Lit(1.0);
        } else if (leftVal == -rightVal) {
            return new Lit(-1.0);
        } else {
            return new Divd(e.getLeft().accept(makeSimplify()), e.getRight().accept(makeSimplify()));
        }
    }

    public Exp visit(Sub e) {
        if (e.getLeft().accept(makeEval()) == e.getRight().accept(makeEval())) {
            return new Lit(0.0);
        } else {
            return new Sub(e.getLeft().accept(makeSimplify()), e.getRight().accept(makeSimplify()));
        }
    }

    public Exp visit(Lit e) {
        return new Lit(e.getValue());
    }

    public Exp visit(Add e) {
        double leftVal = e.getLeft().accept(makeEval());
        double rightVal = e.getRight().accept(makeEval());
        if ((leftVal == 0 && rightVal == 0) || (leftVal + rightVal == 0)) {
            return new Lit(0.0);
        } else if (leftVal == 0) {
            return e.getRight().accept(makeSimplify());
        } else if (rightVal == 0) {
            return e.getLeft().accept(makeSimplify());
        } else {
            return new Add(e.getLeft().accept(makeSimplify()), e.getRight().accept(makeSimplify()));
        }
    }

    Simplify makeSimplify() {
        return new Simplify();
    }

    EvalDivdMultNeg makeEval() {
        return new EvalDivdMultNeg();
    }
}
